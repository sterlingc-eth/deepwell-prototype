import Anthropic from "@anthropic-ai/sdk";
import {
  withTenant, linkDocumentToCustomer, linkDocumentToEntity, linkedByForMatchBasis, findCustomerByReminderName,
} from "./recordsStore.js";
import { REMINDER_ELIGIBLE_DOCUMENT_TYPES } from "./reminders.js";
import { getApiKey, MODEL_TIMEOUT_MS, withBackoff } from "./claude.js";
import {
  buildExtractPrompt, buildExtractToolForPack, normalizeFields, selectPages,
  groupFieldsByUnit, collapseDuplicateValues,
} from "./extractFields.js";
import { packForTenant } from "./industry/index.js";
import { IngestError, isValidDocumentId } from "./readDocument.js";
import { assertModelBudget } from "./rateLimit.js";
import { deriveWarranty } from "./warrantyRules.js";
import { withCache, modelCallLogLine } from "./promptCache.js";
import { recordModelCall } from "./usage.js";
import { updateDossierForDocument } from "./search/dossier.js";
import {
  normalizeDocumentType,
  resolveDocumentType,
  isLabelValue,
  isVoidMarked,
  isLegacyOrUnknownType,
  completenessFor,
  isShopInternalDocument,
  mayVerifyWithoutLink,
  moneyAmountsConfident,
  AI_VERIFY_MIN_CONFIDENCE,
} from "./documentTypes.js";
import { integrityFixDocument } from "./routes/integrity.js";
import { isFragmentName } from "./integrity.js";
import { applyBodyNameLinks } from "./bodyNameLink.js";
import { completeIntake } from "./intake/autofill.js";
import { classifyDocumentAudience } from "./audience/store.js";
// R32 (model avoidance): a plain labelled form is a lookup, not reasoning — see modelAvoidance/textExtract.js.
import { extractFromText } from "./modelAvoidance/textExtract.js";
import { isDeterministicExtractEnabled, isGenericExtractEnabled } from "./modelAvoidance/switches.js";
// R33: a REQUIRED field the extraction left empty is looked up on the page by its printed label — see labelFill.js.
import { planLabelFill, corroborateFields } from "./modelAvoidance/labelFill.js";
import { loadOwnNames, applyOwnCompanyGuard, isOwnName, issuerNotCustomer } from "./modelAvoidance/ownCompany.js";
import { planStoredTextRead, NOTHING_READ_ACTION, readableChars, setNothingReadMarker, clearNothingReadMarker } from "./modelAvoidance/storedTextReread.js";
export { reextractFromStoredText, NOTHING_READ_ACTION } from "./modelAvoidance/storedTextReread.js";

/**
 * buildExtractPrompt() (extractFields.js — not owned by this change, left
 * untouched) returns one flat string: a per-document intro sentence + the
 * page text, followed by a field guide + rules block that is IDENTICAL on
 * every single call, for every document, forever (until extractFields.js's
 * wording changes). That second part is the cacheable "extraction system
 * prompt" the caching task calls for; the first part (the actual document
 * text) obviously is not, since it's different on every document by design.
 *
 * Splitting on that fixed sentence — rather than copying the field guide and
 * rules text a second time into this file — keeps there from ever being two
 * copies of the same guidance to drift apart. If extractFields.js's wording
 * ever changes, the marker just stops matching and this falls back to
 * sending the whole prompt as one uncached user message (still correct,
 * exactly today's behavior — just not cached), never to two different
 * copies of the instructions reaching the model at once.
 */
const EXTRACT_STATIC_MARKER = "Read the pages and return every field the text actually states";

/** Pure. @returns {{dynamic: string, stable: string}} */
export function splitExtractPrompt(fullPrompt) {
  const text = String(fullPrompt ?? "");
  const idx = text.indexOf(EXTRACT_STATIC_MARKER);
  if (idx === -1) return { dynamic: text, stable: "" };
  return { dynamic: text.slice(0, idx).trimEnd(), stable: text.slice(idx).trimEnd() };
}

/**
 * Structured extraction with no HTTP in it, for the same reason as
 * readDocument.js: the route and the queue worker must run the same code.
 *
 * Reads STORED page text, not the original file. read-document already paid for
 * OCR; this is a cheap second pass over its output, which is why the default
 * model is Haiku.
 */

export const EXTRACT_MODEL = process.env.EXTRACT_MODEL || "claude-haiku-4-5";

/**
 * @param {{tenantKey: string, tenantName?: string}} ctx
 * @param {{userId?: string, documentType?: string, modelAttempts?: number}} [opts]
 *   `modelAttempts` (H2, 2026-09-19 adversarial audit): withBackoff's own
 *   retry count for the Anthropic call below. Left undefined (withBackoff's
 *   default of 3) on the inline/sync path — a synchronous request has no
 *   other retry mechanism backing it up. The Inngest `extract-fields`
 *   function (queue.js) passes 1: under the queue, retrying the WHOLE step
 *   already re-runs this call, so nesting withBackoff's own 3 attempts inside
 *   that step's 3 Inngest retries could multiply one document's spend up to
 *   9x under a sustained 429/529 — bounded, but never checked against the
 *   daily budget below or against itself. One layer of retry should own a
 *   429, not two.
 * @returns {Promise<{documentId: string, entityId: string|null, customerId: string|null,
 *                    fields: object[], dropped: object[], truncated: boolean, model: string,
 *                    pagesRead: number, pagesTotal: number}>}
 */
export async function extractDocumentFields(ctx, documentId, { userId, documentType, modelAttempts } = {}) {
  // Every documents.id is a uuid; a malformed value survives a bare
  // typeof/truthiness check and only fails once bound against that column,
  // as "invalid input syntax for type uuid" — a raw 500, not a clean 400.
  // Guarded here (not just at the HTTP route) so the Inngest queue worker,
  // which calls this directly with no route in front of it, is covered too.
  if (!isValidDocumentId(documentId)) {
    throw new IngestError("documentId must be a uuid", 400);
  }

  // B1 (2026-09-19 adversarial audit): the daily model-spend cap is enforced before every billed call. R32: the check
  // now sits right before the ONE model call below (assertModelBudget(ctx)), not at the top, because a document the
  // deterministic text extractor accepts makes no model call at all and must not be refused for a spent model budget.
  // Covers BOTH callers of this function (the Inngest extract-fields worker and /api/extract's stored-document path).

  // Short transaction: the model call below must not hold a pool connection.
  const loaded = await withTenant(ctx, async (db) => {
    const doc = await db.getDocument(documentId);
    if (!doc) return null;
    // Team G (industry packs): the same read that already opens this
    // transaction resolves the tenant's pack too, so a plumbing/electrical/
    // property tenant's own document types and field vocabulary drive
    // classification and extraction below instead of the hard-coded HVAC
    // ones. packForTenant is itself cached per tenant, so this is not a
    // second query on the hot path for a tenant it has already resolved.
    const pack = await packForTenant(db);
    // F1: who "we" are (tenants.name / settings / outreach shop name), so our own name is never read as the other party.
    const ownNames = await loadOwnNames(db, ctx);
    return { doc, pages: await db.listPages(documentId), pack, ownNames };
  });

  if (!loaded) throw new IngestError("Document not found", 404);

  const { doc, pages, pack, ownNames } = loaded;
  if (!pages.length || !pages.some((p) => (p.text ?? "").trim())) {
    // Two different situations, not one: a document read carries its own
    // extract_error (see readDocument.js's hasReadableText/NO_READABLE_TEXT_MESSAGE)
    // when the read genuinely ran and found nothing — surface THAT message
    // rather than telling someone to go run a step that already ran. Only a
    // document that has never had extract_error set at all gets the "not
    // read yet" 409.
    if (doc.extract_error) throw new IngestError(doc.extract_error, 422);
    throw new IngestError("This document has no page text yet. Run /api/read-document first.", 409);
  }

  const { pages: selected, truncated } = selectPages(pages);

  // R32: deterministic extraction FIRST (EXTRACT_DETERMINISTIC=0 disables). extractFromText accepts a document only
  // when its title names a template type, every line is explained, every validator passes and every field the type
  // requires was found; anything else returns {accepted:false} and the model runs exactly as it always did. The
  // validated-label path (labelledExtract.js, any industry pack, EXTRACT_GENERIC=0 switches it off) widens that to
  // receipts, statements, POs, agreements ... read only from confidently labelled lines. An explicit `documentType`
  // override or a truncated document never takes this path.
  const det = !documentType && !truncated && isDeterministicExtractEnabled()
    ? extractFromText(selected, { pack, ownNames, generic: isGenericExtractEnabled() })
    : null;
  let extractMethod = "model";
  let extractModelLabel = EXTRACT_MODEL;
  let toolUse;
  if (det?.accepted) {
    extractMethod = "text";
    extractModelLabel = "deterministic-text";
    toolUse = { type: "tool_use", input: det.toolInput };
    console.log(JSON.stringify({ route: "extract", method: "text", type: det.type, fields: det.toolInput.fields.length }));
  } else {
  await assertModelBudget(ctx);
  const client = new Anthropic({ apiKey: getApiKey(), timeout: MODEL_TIMEOUT_MS, maxRetries: 0 });

  // See splitExtractPrompt()'s doc comment above for why this is split
  // rather than sent as the one flat string it used to be. withCache()
  // (api/_lib/promptCache.js) only attaches cache_control when `stable` is
  // actually long enough to be cached (Haiku: 2048 tokens, ~8192 chars) —
  // extractFields.js's FIELD_GUIDE now carries a worked example per field
  // specifically so this clears that bar (see handoffs/COST_REPORT_2026-09-20.md
  // for the measured before/after). 1h TTL: a bulk import runs this same
  // stable prefix across hundreds of documents over hours, well past the
  // default 5-minute cache window.
  // Team G (industry packs): a hvac tenant's `pack` is the hvac pack itself,
  // so buildExtractPrompt/buildExtractToolForPack return exactly EXTRACT_TOOL
  // and today's prompt text, unchanged — see extractFields.js's packFieldMeta.
  const extractTool = buildExtractToolForPack(pack);
  // R34: `documentType` is a caller-supplied string (POST /api/extract) and doc.document_type was, until R34, whatever a member
  // typed; either was interpolated into the prompt text verbatim. Only a plain type-id shape reaches the prompt.
  const promptType = [documentType, doc.document_type].find((t) => typeof t === 'string' && /^[a-z][a-z0-9_-]{0,39}$/i.test(t.trim()))?.trim();
  const fullPrompt = buildExtractPrompt(selected, promptType, pack, { ownNames });
  const { dynamic: dynamicPrompt, stable: stablePrompt } = splitExtractPrompt(fullPrompt);

  const startedAt = Date.now();
  const deadlineAt = startedAt + MODEL_TIMEOUT_MS;
  const response = await withBackoff(() => client.messages.create({
    model: EXTRACT_MODEL,
    max_tokens: 4000,
    ...(stablePrompt ? { system: [withCache({ type: "text", text: stablePrompt }, EXTRACT_MODEL, { ttl: "1h" })] } : {}),
    tools: [withCache(extractTool, EXTRACT_MODEL)],
    tool_choice: { type: "tool", name: extractTool.name },
    messages: [{ role: "user", content: dynamicPrompt }],
  }, { timeout: Math.max(1000, deadlineAt - Date.now()) }), { deadlineAt, attempts: modelAttempts });
  const latencyMs = Date.now() - startedAt;

  // One structured line per call, no PII (page text/field values never
  // appear here) — so Vercel logs show cache hit rates.
  console.log(
    JSON.stringify(
      modelCallLogLine({
        route: "extract",
        model: EXTRACT_MODEL,
        inputTokens: response.usage?.input_tokens,
        cacheReadInputTokens: response.usage?.cache_read_input_tokens,
        cacheCreationInputTokens: response.usage?.cache_creation_input_tokens,
        outputTokens: response.usage?.output_tokens,
        latencyMs,
      })
    )
  );

  // Cost accounting, best-effort — see api/ask.js's identical comment.
  // recordModelCall already swallows its own errors (usage.js), and this is
  // wrapped again so a change there can never turn a successful extraction
  // into a 500.
  try {
    await recordModelCall(ctx, {
      inputTokens: response.usage?.input_tokens,
      outputTokens: response.usage?.output_tokens,
      cacheReadInputTokens: response.usage?.cache_read_input_tokens,
      cacheCreationInputTokens: response.usage?.cache_creation_input_tokens,
    });
  } catch (err) {
    console.error("Failed to record extract usage:", err?.message);
  }

  toolUse = response.content.find((b) => b.type === "tool_use");
  }
  const highestPage = pages.reduce((n, p) => Math.max(n, Number(p.page_no) || 0), 0);
  let { fields, dropped } = normalizeFields(toolUse?.input?.fields, { pageCount: highestPage, pack });

  // A customer_name that is only a business suffix ("Management", "Inc.",
  // "Group") is a parse fragment, not a name: never store it as an identity.
  fields = fields.filter((f) => !(f.field_key === 'customer_name' && isFragmentName(f.value)));
  // Inbox round (2026-10-21): a label read as a name ("DELIVERED TO", "Bill To", "N/A", "Walk-in") is never a party.
  fields = fields.filter((f) => !((f.field_key === 'customer_name' || f.field_key === 'vendor') && isLabelValue(f.value)));
  // Inbox round: the business on the letterhead issued the paper; it is never also its customer.
  try { fields = issuerNotCustomer(fields, selected, ownNames).fields; } catch (err) { console.error("issuer check skipped:", err?.message); }

  // F1: our own company is never the customer (a bill addressed TO us used to create us as a customer) and never the vendor.
  const ownGuard = applyOwnCompanyGuard(fields, ownNames);
  fields = ownGuard.fields;
  const ownRemoved = ownGuard.removed;

  // F1: NEVER SILENTLY ACCEPT AN EMPTY EXTRACTION. A readable page that yielded zero fields gets the labelled scan on the stored
  // page text ($0); if that is still empty a machine-readable "nothing read" marker is written (audit_log
  // action 'document.nothing_read', see modelAvoidance/storedTextReread.js) instead of passing as a real answer.
  let storedTextFilled = [];
  let nothingRead = null;
  if (!fields.length) {
    try {
      const rr = planStoredTextRead({ documentType, storedType: doc.document_type, filename: doc.original_filename, pages: selected, ownNames, pack, pageCount: highestPage });
      if (rr.add.length) { fields = rr.add; storedTextFilled = rr.add; }
      else if (rr.readable) nothingRead = { chars: rr.chars, pages: selected.length, type: rr.type };
    } catch (err) {
      console.error("stored-text re-read failed (extraction kept as is):", err?.message);
      nothingRead = readableChars(selected) >= 20 ? { chars: readableChars(selected), pages: selected.length, type: null } : null;
    }
  }

  // A document that states nothing extractable is a real answer, not a failure.
  // The write still happens, so an empty result replaces stale rows from an
  // earlier run rather than leaving them there to look current.
  let facts = Object.fromEntries(fields.map((f) => [f.field_key, f.value]));

  // Which technician installed a unit is exactly the kind of fact
  // findOrCreateEquipment's fill-once merge exists for (the first install
  // document to state it wins; a later service ticket cannot overwrite it) —
  // it is simply missing from that function's own field list today. See
  // HANDOFF.md for the one-line addition recordsStore.js still needs
  // ('installed_by' alongside 'serial_number', 'model', etc.); until that
  // lands, findOrCreateEquipment silently drops this key from `incoming` the
  // same way it already drops any key not on its list, so passing it early
  // is inert rather than wrong, and starts working the moment that list grows.
  // Round 4 (2026-09-21): a document whose only facts are its own shop_*
  // letterhead fields plus notes/status names no customer, unit or job — it
  // can never be linked to one, so it must not be left waiting in the human
  // queue for a link that will never come. Checked ahead of the model's own
  // guess (like the `documentType` explicit-override case above it) because
  // this is a stronger, purely factual signal than anything the model can
  // infer from prose alone, but still below an explicit override — a human
  // or a prior AI pass that already decided this document's type still wins,
  // via `existingIsDecided` below.
  const classification = documentType
    ? { documentType: normalizeDocumentType(documentType, facts, pack), confidence: 1, source: 'explicit' }
    : isShopInternalDocument(fields)
      ? { documentType: 'internal', confidence: 1, source: 'shop-internal' }
      : resolveDocumentType(toolUse?.input, facts, doc.original_filename, pack);

  // A human (via review.classifyDocument) or an earlier pass already decided
  // this document's type; a routine re-extraction must not quietly relabel
  // it. An explicit `documentType` argument is the one thing allowed to
  // override that decision.
  const existingIsDecided = classification.source !== 'explicit'
    && doc.document_type && !isLegacyOrUnknownType(doc.document_type);
  const resolvedType = existingIsDecided ? doc.document_type : classification.documentType;

  // R33 (Sonoran Comfort Air, 2026-09-30): "Date of Service: 10/19/2028" printed on the page, "Missing information —
  // Service date" in the Inbox. Whatever the extractor (model or text) left EMPTY for a field this type requires is
  // looked up by its printed label on the same page text, $0, no model; every value goes through normalizeFields
  // again, so a far-future date is kept as service_date_unconfirmed (flagged), never dropped and never fed to the
  // warranty clock. Precision first: filled only when every labelled candidate agrees (labelFill.js). HVAC
  // vocabulary only; never throws (a scan failure leaves the extraction exactly as it was).
  let labelFilled = [];
  let labelFillAmbiguous = [];
  let corroborated = [];
  if (!pack || pack.id === 'hvac') {
    try {
      const plan = planLabelFill({ type: resolvedType, fields, pages: selected, method: 'label-fill', pageCount: highestPage, ownNames, filename: doc.original_filename ?? null });
      labelFillAmbiguous = plan.ambiguous;
      if (plan.add.length) {
        labelFilled = plan.add;
        fields = [...fields, ...plan.add];
        facts = Object.fromEntries(fields.map((f) => [f.field_key, f.value]));
      }
    } catch (err) {
      console.error("label-fill failed (extraction kept as is):", err?.message);
    }
  }
  // F1: CORROBORATION. A value the model gave that the page's own labels print identically (same normalized date, amount within a
  // cent, fuzzy-equal name, same number) is confirmed by two independent readers: confidence >= 0.9. No global bar is lowered.
  try {
    const co = corroborateFields({ type: resolvedType, fields, pages: selected, ownNames });
    fields = co.fields;
    corroborated = co.corroborated;
    if (corroborated.length) facts = Object.fromEntries(fields.map((f) => [f.field_key, f.value]));
  } catch (err) {
    console.error("corroboration failed (extraction kept as is):", err?.message);
  }
  fields = applyOwnCompanyGuard(fields, ownNames).fields;
  facts = Object.fromEntries(fields.map((f) => [f.field_key, f.value]));

  // CUSTOMER REMINDERS (2026-09-22): reminder_text/reminder_customer_name/
  // reminder_trigger only mean anything on a memo-like document — see
  // reminders.js's own doc comment. Filtered by the RESOLVED type, not the
  // model's raw guess, so a work order the model briefly mis-tagged never
  // keeps a stale reminder fact once its real type is known.
  if (!REMINDER_ELIGIBLE_DOCUMENT_TYPES.has(resolvedType)) {
    fields = fields.filter((f) => !f.field_key.startsWith('reminder_'));
  }

  const isInstallShaped = resolvedType === 'startup-sheet'
    || (resolvedType === 'invoice' && !!facts.installation_date);
  const equipmentFacts = isInstallShaped && facts.technician
    ? { ...facts, installed_by: facts.technician }
    : facts;
  // Same technician-attribution overlay, applied per unit for a multi-unit
  // document — a startup sheet's "installed_by" applies to every unit it
  // installed, not only the one whose facts happen to include a serial first.
  const withInstalledBy = (unitFacts) =>
    isInstallShaped && facts.technician ? { ...unitFacts, installed_by: facts.technician } : unitFacts;

  // Multi-unit documents (2026-09-19 live finding): a maintenance agreement
  // or install invoice can cover more than one physical unit, each with its
  // own serial/model/install date under a shared customer_name/service_address/
  // warranty_term. groupFieldsByUnit() (extractFields.js) has already sorted
  // that out from unit_index tags the model attached, if any.
  //
  // Gated on >=2 DISTINCT serial numbers, not merely units.length > 1: a
  // model that tags unit_index on some fields but only ever names one real
  // serial is not a multi-unit document, and treating it as one would create
  // a second, serial-less equipment entity findOrCreateEquipment would
  // immediately reject anyway (it returns null with no serial) — this check
  // just skips the pointless extra work and log noise for that case.
  const { units } = groupFieldsByUnit(fields, pack);
  const distinctSerials = new Set(
    fields
      .filter((f) => f.field_key === 'serial_number' && f.value)
      .map((f) => f.value.trim().toLowerCase())
  );
  const isMultiUnit = distinctSerials.size >= 2 && units.length >= 2;

  let warranty = null;

  const written = await withTenant(ctx, async (db) => {
    // `entity`/`warranty` end up holding the FIRST unit's — extractions.entity_id
    // stays single-valued for backward compatibility with everything that
    // reads "the" entity off a document. Every unit still gets its own
    // findOrCreateEquipment (so none of the fill-once merge or the B2
    // advisory-lock race protection is skipped) and its own derived
    // warranty; units after the first get an additional document_entity_links
    // row below instead of the primary entity_id.
    let entity;
    const unitResults = [];
    if (isMultiUnit) {
      for (const unit of units) {
        const unitEquipmentFacts = withInstalledBy(unit.facts);
        const unitEntity = await db.findOrCreateEquipment(unitEquipmentFacts);
        // Same fill-only-merge-then-derive as the single-unit path below,
        // just scoped to this unit's own facts + its own entity row.
        const unitKnown = { ...unit.facts, ...(unitEntity?.data ?? {}) };
        const unitWarranty = deriveWarranty(unitKnown, null, pack);
        if (unitEntity?.id) await db.setEquipmentWarranty(unitEntity.id, unitWarranty);
        unitResults.push({ index: unit.index, entity: unitEntity, warranty: unitWarranty });
      }
      entity = unitResults[0]?.entity ?? null;
      warranty = unitResults[0]?.warranty ?? null;
    } else {
      entity = await db.findOrCreateEquipment(equipmentFacts);

      // Derived from the ENTITY's accumulated facts, not this document's alone.
      //
      // A unit's manufacturer and install date are stated once, on the install
      // invoice. Every later document about that same serial — a service ticket,
      // a filter change, a callback — says neither. Deriving from `facts` by
      // itself therefore produced an empty warranty for those documents, and
      // setEquipmentWarranty's jsonb merge replaces the whole `warranty` key, so
      // the second document silently erased the correct deadline computed from
      // the first. The unit then vanished from the expiring-warranty list with
      // nothing recorded as wrong, and which answer you got depended on which
      // document happened to be extracted last.
      //
      // The entity's own values win over this document's: the entity merge is
      // fill-only, so what is on the row is the first — and by convention the
      // most authoritative — reading of that field.
      const known = { ...facts, ...(entity?.data ?? {}) };

      // Still derived WITHOUT a clock: only the stable parts — the registration
      // deadline, the term, the expiry, and whether that expiry was printed or
      // calculated — get stored. Day counts are computed when the list is read,
      // because "19 days left" is true for exactly one day.
      warranty = deriveWarranty(known, null, pack);
      if (entity?.id) await db.setEquipmentWarranty(entity.id, warranty);
    }

    // Customer resolution runs regardless of whether an equipment entity was
    // found: a document with no serial (a dispatch note, a proposal, a
    // letter) still names a customer, and that customer is how such a
    // document reaches stage 'linked' below. findOrCreateCustomer returns
    // null rather than a fabricated customer when the document names nobody
    // — see its doc comment in recordsStore.js for the matching key and its
    // known limitations.
    const customer = await db.findOrCreateCustomer(facts);
    // Bug C fix (2026-09-20): every unit's equipment gets the customer, not
    // just the first — a multi-unit document used to leave RTU-2/RTU-3
    // ownerless even though the customer was resolved correctly.
    const linkedEquipmentIds = [];
    if (customer?.id) {
      const targets = isMultiUnit ? unitResults.map((u) => u.entity) : [entity];
      for (const target of targets) {
        if (target?.id && (await db.setEquipmentCustomer(target.id, customer.id)) > 0) {
          linkedEquipmentIds.push(target.id);
        }
      }
    }
    const linked = linkedEquipmentIds.length;

    // Two units sharing an identical printed value (the same model number on
    // RTU-1 and RTU-2, most often) is a real, legitimate case that
    // groupFieldsByUnit() above needs to see as two rows — but
    // replaceDocumentFields throws on an exact (field_key, value) duplicate,
    // since its write CTE joins each new extraction back to its facet on
    // that pair. Collapsed only for this write; `fields` itself (returned to
    // the caller, and what groupFieldsByUnit already read) keeps every row.
    const fieldsForWrite = collapseDuplicateValues(fields);
    const counts = await db.replaceDocumentFields(documentId, fieldsForWrite, {
      entityId: entity?.id ?? null,
    });

    // Record what this document turned out to be. Nothing wrote document_type
    // before, so it was null on every row forever — and the review screen gates
    // its whole extracted-fields section on that column being set, which meant a
    // document that HAD been fully extracted rendered as a blank slate and a
    // technician was invited to key it all in again.
    // resolvedType is computed above, before the transaction, from the same
    // classification/override precedence equipmentFacts already used.
    if (resolvedType && resolvedType !== doc.document_type) {
      await db.updateDocument(documentId, { document_type: resolvedType });
    }

    // This extraction succeeded, so any error left over from a previous attempt
    // is now a lie. Nothing cleared it before: extract_error was set by a failed
    // extraction but only ever cleared by a successful READ, so a document that
    // failed once and then extracted perfectly on retry stayed marked failed
    // forever — and the browser treats extract_error as terminal, so the user
    // was told to give up on a row that held all of its data.
    await db.clearExtractError(documentId);

    // The pipeline just attached this document to an entity. Say so in the
    // stage, so the client's "is this document linked" question has an honest
    // answer without a human having to click anything. A document with no
    // equipment entity (no serial) but a resolved customer links straight to
    // that customer instead — see linkDocumentToCustomer's doc comment.
    let documentCustomerLinked = false;
    if (entity?.id) {
      await db.markLinked(documentId);
      // Units after the first don't get extractions.entity_id (that stays
      // single-valued, see the multi-unit comment above) but the document
      // still covers their equipment, so each gets its own
      // document_entity_links row — otherwise RTU-2's own entity screen
      // would never show this document at all.
      if (isMultiUnit) {
        for (const ur of unitResults.slice(1)) {
          if (ur.entity?.id) {
            await linkDocumentToEntity(db, { documentId, entityId: ur.entity.id, confidence: 0.6 });
          }
        }
      }
    }
    // Bug B fix (2026-09-20): a resolved customer gets its OWN
    // document_entity_links row unconditionally — not only when there was no
    // equipment entity. Before this, a document that linked to equipment
    // never got a customer link at all (only entities.customer_id, via
    // setEquipmentCustomer above), so the review/customer screens had
    // nothing to read "this document is linked to its customer" from — the
    // Margaret Henderson production defect (equipment linked, customer
    // shown as "not linked to a customer yet"). Idempotent with the above:
    // ON CONFLICT DO NOTHING in linkDocumentToCustomer.
    if (customer?.id) {
      const customerFields = fields.filter((f) => f.field_key === 'customer_name' || f.field_key === 'service_address');
      const customerConfidence = customerFields.length ? Math.max(...customerFields.map((f) => f.confidence)) : 0.6;
      documentCustomerLinked = await linkDocumentToCustomer(db, {
        documentId, customerId: customer.id, confidence: customerConfidence,
        linkedBy: linkedByForMatchBasis(customer.matchBasis),
      });
    }

    // CUSTOMER REMINDERS (2026-09-22): a memo naming nobody in customer_name
    // at all can still name someone in its reminder text — "Reminder logged
    // for Karen Abernathy's account". Tried only when the ordinary resolution
    // above found no customer, and only on reminder-eligible types (the
    // `fields` filter above already dropped reminder_* facts on any other
    // type, so `facts.reminder_customer_name` is simply absent there). Same
    // exact/fuzzy-surname match contactLookup.js uses; never creates a
    // customer — an unmatched name stays unlinked and surfaces in Needs
    // linking, where Fix this document offers a one-click create.
    let documentReminderLinked = false;
    if (!customer?.id && facts.reminder_customer_name) {
      const reminderCustomer = await findCustomerByReminderName(db, facts.reminder_customer_name);
      if (reminderCustomer?.id) {
        documentReminderLinked = await linkDocumentToCustomer(db, {
          documentId, customerId: reminderCustomer.id, confidence: 0.6, linkedBy: 'ai:reminder',
        });
      }
    }

    // AI self-verification: every required field for this type is present at
    // AI_VERIFY_MIN_CONFIDENCE or better, and the document is actually linked
    // to a record. verifyByAi (recordsStore.js) re-checks the link itself in
    // SQL, forward-only — this is a cheap pre-check, not the source of truth.
    const completeness = completenessFor(resolvedType, fields, pack, { filename: doc.original_filename ?? null });
    let aiVerified = false;
    // F1: a document that had NO fields and was typed only by a re-read of its own page text is not auto-verified as an untyped
    // ("other") document: nothing about it was ever required, so "complete" proves nothing.
    const untypedReread = storedTextFilled.length > 0 && (!resolvedType || resolvedType === 'other');
    // Money guard (documentTypes.js moneyAmountsConfident): an amount below the bar that the page does not corroborate
    // blocks the automatic check on the linked path too, not only on the unlinked one.
    const pageHasText = pages.some((p) => String(p.text ?? '').trim() !== '');
    // Inbox round: a VOID paper is kept on file and never checked (so never counted).
    const voidPaper = isVoidMarked({ filename: doc.original_filename, text: pages.map((p) => String(p.text ?? '')).join('\n').slice(0, 20000) });
    if (!untypedReread && !voidPaper && completeness.complete && completeness.minConfidence >= AI_VERIFY_MIN_CONFIDENCE && moneyAmountsConfident(fields)) {
      aiVerified = (await db.verifyByAi(documentId, { allowUnlinked: mayVerifyWithoutLink(resolvedType, fields, { hasText: pageHasText, filename: doc.original_filename }) })) > 0;
    }

    await db.logAction({
      action: "document.fields_extracted",
      resource_type: "document",
      resource_id: documentId,
      clerk_user_id: userId,
      changes: {
        fields: counts.extractions,
        replaced: counts.replaced,
        dropped: dropped.length,
        truncated,
        model: extractModelLabel,
        method: extractMethod,
        entity_id: entity?.id ?? null,
        entity_created: entity?.created ?? false,
        warranty_basis: warranty.expiresBasis,
        registration_deadline: warranty.registrationDeadline,
        unit_count: isMultiUnit ? unitResults.length : 1,
        additional_entity_ids: isMultiUnit
          ? unitResults.slice(1).map((u) => u.entity?.id).filter(Boolean)
          : [],
        customer_id: customer?.id ?? null,
        customer_created: customer?.created ?? false,
        // False when the equipment was already linked to a DIFFERENT customer
        // (setEquipmentCustomer's fill-only guard) as much as when there was
        // no customer to link — the two are distinguishable via customer_id
        // above being non-null with customer_linked false.
        customer_linked: linked > 0,
        document_customer_linked: documentCustomerLinked,
        reminder_text: facts.reminder_text ?? null,
        reminder_customer_linked: documentReminderLinked,
        document_type: resolvedType,
        document_type_confidence: classification.confidence,
        document_type_source: classification.source,
        completeness_missing: completeness.missing,
        ai_verified: aiVerified,
        // Round 4 (2026-09-21): fields kept despite a future date (scheduled
        // work, within extractFields.js's per-field window) — stored here,
        // the existing document-action JSON, so Review can read "dated in
        // the future" for these keys instead of inferring "missing" just
        // because completenessFor doesn't know the difference. No DDL: reuses
        // audit_log.changes, already written on every extraction.
        future_dated_fields: fields.filter((f) => f.flags?.includes('future')).map((f) => f.field_key),
        // R33: printed dates beyond the field's window, kept as <key>_unconfirmed for a person to confirm (never
        // dropped any more); fields supplied by the label scan; and what the validator still refused, with its
        // reason, so a later re-check (api/_lib/recheck.js) or a person can see exactly what was printed.
        unconfirmed_dates: fields.filter((f) => f.flags?.includes('far_future')).map((f) => ({ field_key: f.unconfirmed_of, value: f.value })),
        label_filled: labelFilled.map((f) => ({ field_key: f.field_key, value: f.value, page_no: f.page_no, method: 'label-fill' })),
        ...(labelFillAmbiguous.length ? { label_fill_ambiguous: labelFillAmbiguous.slice(0, 10) } : {}),
        ...(nothingRead ? { nothing_read: true } : {}),
        ...(storedTextFilled.length ? { stored_text_filled: storedTextFilled.map((f) => ({ field_key: f.field_key, value: f.value, page_no: f.page_no, method: 'text-reread' })) } : {}),
        ...(corroborated.length ? { corroborated } : {}),
        ...(ownRemoved.length ? { own_company_removed: ownRemoved } : {}),
        dropped_fields: dropped.slice(0, 20).map((d) => ({ key: String(d.key ?? '').slice(0, 60), reason: String(d.reason ?? '').slice(0, 160) })),
        // Round 4: shop-internal documents (see isShopInternalDocument) carry
        // no customer at all, by design — recorded here (again, no DDL) so
        // that fact is on file wherever this action is audited, distinct from
        // "a customer should be here but resolution failed".
        ...(classification.source === 'shop-internal' ? { no_customer: true } : {}),
      },
    });

    // F1: the machine-readable "nothing read" marker (existing storage: audit_log). Cleared implicitly by any later
    // document.fields_extracted / fields_reread / fields_rechecked row for the document that carries fields.
    // Also an `_nothing_read` extraction row (like '_audience') so the client entity graph, which only sees extraction
    // rows, can tell; removed again as soon as a read finds fields.
    if (nothingRead) await setNothingReadMarker(db, documentId);
    else await clearNothingReadMarker(db, documentId);
    if (nothingRead) {
      await db.logAction({
        action: NOTHING_READ_ACTION, resource_type: "document", resource_id: documentId, clerk_user_id: userId,
        changes: { reason: "no_fields_after_text_scan", chars: nothingRead.chars, pages: nothingRead.pages, type: nothingRead.type ?? resolvedType ?? null, source: "ingest", model: extractModelLabel },
      });
    }

    // AUDIENCE (round 18, part 2, owner ask (a)): right after the type and fields this pass
    // resolved are persisted, and deliberately AFTER every customer/equipment link above rather
    // than gating them — "classify before linking and skip linking" and "undo the links in the
    // same step" are the two ordering options the contract allows, and undoing here is the
    // lower-risk one against this function's own dense, heavily-tested linking logic. Same
    // transaction as everything above: an internal document is never externally observable as
    // customer-linked even for an instant. classifyDocumentAudience is itself idempotent — a
    // retried extraction (same or updated fields) just re-classifies and re-writes; the
    // notification step underneath (notify.js's markNotifiedOnce) is what actually de-dupes, so a
    // retry never sends a second one. Works before M3-config/57 is pasted (the extractions
    // fallback probes below).
    await classifyDocumentAudience({ query: (sql, p) => db.raw(sql, p) }, documentId, {
      documentType: resolvedType, text: pages.map((p) => p.text || '').join('\n\n'),
      fields: facts, orgId: ctx.tenantName,
    });

    return {
      counts,
      documentType: resolvedType ?? null,
      entityId: entity?.id ?? null,
      customerId: customer?.id ?? null,
      completeness,
      aiVerified,
    };
  });

  // Deterministic, cheap, no model call: catches a customer link this pass
  // still missed (e.g. the matching customer was created a moment later by a
  // concurrent document) so a new document never sits unlinked waiting for
  // the nightly sweep (handoffs/DATA_INTEGRITY_2026-09-20.md). Best-effort —
  // integrityFixDocument never throws.
  await integrityFixDocument(ctx, documentId);
  // Memo/correspondence whose BODY names exactly one existing customer: link it (deterministic, no model; ambiguous or
  // partial matches are left for review). Never throws. See bodyNameLink.js.
  await applyBodyNameLinks(ctx, { documentId });

  // DOSSIER HOOK (TEAM T2, 2026-09-25): this document is now linked to whatever customer/unit it
  // names, so THIS is the earliest point their rolling summary can incorporate it — updateDossierForDocument
  // never throws (the document is already fully ingested either way) and is inert without an API key or
  // before migration 33 is pasted; the nightly catch-up (cron-sweep.js) picks up anything this misses.
  await updateDossierForDocument(ctx, documentId).catch(() => {});

  // STRAIGHT-THROUGH INTAKE (TEAM G4, Round 12): fills missing required fields from sibling
  // documents already linked to the same unit/customer, raises one precise needs-info question
  // when a fill is genuinely ambiguous, auto-verifies once the fills clear completenessFor's bar,
  // and wires the naming/graph/rollup post-ingest hooks. Deterministic, no model call; never
  // throws (see intake/autofill.js's own doc comment) — a failure here can never fail ingest,
  // which has already fully succeeded by this point.
  await completeIntake(ctx, documentId, {
    facts, fields, resolvedType, pack, entityId: written.entityId, customerId: written.customerId,
  }).catch(() => {});

  return {
    documentId,
    documentType: written.documentType,
    entityId: written.entityId,
    customerId: written.customerId,
    completeness: written.completeness,
    aiVerified: written.aiVerified,
    fields,
    dropped,
    truncated,
    model: extractModelLabel,
    method: extractMethod,
    pagesRead: selected.length,
    pagesTotal: pages.length,
    warranty,
  };
}
