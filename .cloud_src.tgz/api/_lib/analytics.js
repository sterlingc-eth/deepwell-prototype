/**
 * Donovan analytics: aggregate/counting/grouping questions that today have no
 * path in /api/ask ("how many customers in Arizona", "how many in Maricopa
 * County", "list customers in Gilbert", "which customers have Trane units").
 * See handoffs/DONOVAN_ANALYTICS_BRIEF_2026-09-21.md and
 * handoffs/DONOVAN_ANALYTICS_A_2026-09-21.md.
 *
 * Everything in THIS file is pure (no `db`, no Anthropic client, no I/O) so
 * it is directly testable with no database or network — see
 * scripts/verify-analytics.mjs. api/_lib/routes/analytics.js does the actual
 * Haiku call and the database reads, and calls back into the builders here.
 *
 * THE ONE RULE THAT MATTERS (same rule fastPath.js states for itself): the
 * model NEVER writes SQL and never freely answers. It fills one strict,
 * closed-vocabulary JSON plan (tool use); everything after that — which
 * columns are read, how they're filtered, how the answer is worded — is code,
 * not the model. `validatePlan` rejects anything the model returns that
 * doesn't fit the vocabulary below, and a rejected plan means the whole
 * question falls through to the existing retrieval+model pipeline, exactly
 * like a fast-path miss does.
 */
import { notPrivateSql, notPrivateIdSql } from './privacy/privateDocs.js';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { createHash } from 'node:crypto';
import { deriveCity } from './routes/customers.js';
import { alertTier, normalizeBrand, isPlausibleToday, isValidYmd, daysBetween } from './warrantyRules.js';
import { DOCUMENT_TYPE_IDS, docTypeFromWord, docTypeSynonymAlternation, documentTypeLabel } from './documentTypes.js';
// Team A (2026-09-24): "added/uploaded" -> created_at vs "serviced/visited" -> service_date, decided from the wording.
import { dateBasisPhrase } from './scope.js';
// R17 (G4, consolidation): canonical street-suffix list — see geo/streetSuffix.js. Pure data (no
// imports of its own), so this never risks the analytics.js -> scope.js -> fastPath.js ->
// nlNormalize.js -> analytics.js cycle documented at fastPath.js's own fastPathWithinEditDistance1.
import { STREET_SUFFIX_ALTERNATION } from './geo/streetSuffix.js';

// Plain readFileSync + JSON.parse rather than an import attribute (`with {
// type: 'json' }`) — same idiom claude.js already uses for .env.local, and it
// avoids depending on every downstream bundler/typechecker (Vercel, tsc,
// tsx-run verify scripts) supporting import-attribute syntax for a file that
// only ever needs to be read once, synchronously, at module load.
const __dirname = dirname(fileURLToPath(import.meta.url));
const zipCounty = JSON.parse(readFileSync(join(__dirname, 'geo', 'zip-county.json'), 'utf8'));

// R17 (G4, consolidation): this file had FIVE separate inline copies of the same regex-metachar
// escape (a word going into a `new RegExp(...)` template must have its own regex metacharacters
// escaped first, or a synonym/city/brand name containing one — "5,000 BTU" style content is rare
// here but a literal "." in a name is not — would silently change what the built pattern matches).
// contactLookup.js and cache/semanticCache.js each also had their own copy of the exact same one-
// liner; both already import from/are safe to import from this file (no cycle — see this file's
// own STREET_SUFFIX_ALTERNATION import comment above for the cycle this codebase does have to
// watch for, which doesn't apply here since this helper touches no other module).
import { resolveCalendarSpan, findInvalidDate } from './timeSpans.js';
export { findInvalidDate };
export function escapeRegExp(s) {
  return String(s ?? '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/** Brand/county name tables, moved above the classifier (they used to live
 *  down in the "honest fallback" section, below preClassifyAnalytics) so the
 *  classifier's own GEO_WORD_RE/BRAND_RE (see WE_YES_NO_RE's doc comment)
 *  can be built from them at module load without a temporal-dead-zone
 *  ordering problem — both are still exported/used exactly as before by
 *  detectedConditions further down. */
// Round 14 (K3): beyond the brands actually present in this tenant's data
// (trane..mitsubishi), a handful more common real-world HVAC manufacturer
// names are included so a question naming one of THEM ("do we have any Ruud
// units?") still recognizes it as a brand condition and builds a real
// (zero-row-matching) filter, rather than falling through with no filter
// recognized at all and confidently reporting the TOTAL unfiltered equipment
// count as if it answered the brand question (see suspiciousUnfilteredCustomerPlan's
// own doc comment for why an unrecognized-but-real condition must never be
// silently dropped like this).
export const BRAND_WORDS = [
  'trane', 'carrier', 'goodman', 'lennox', 'rheem', 'york', 'daikin', 'mitsubishi',
  'ruud', 'bryant', 'amana', 'american standard', 'heil', 'payne', 'coleman', 'maytag',
];
/** True when `v` is, whole, one of the manufacturer names the planner itself knows (a real brand that simply may not be on file). */
export const isSystemBrandWord = (v) => BRAND_WORDS.includes(String(v ?? '').trim().toLowerCase());
const KNOWN_COUNTY_NAMES = [
  ...new Set(
    [...Object.values(zipCounty.azZip3Default), ...Object.values(zipCounty.azZipExceptions)]
      .filter(Boolean)
      .map((c) => String(c).toLowerCase())
  ),
];
// Exported (item 1, 2026-09-22): docLookup.js's own "must not hijack a
// geo-scoped analytics question" guard (e.g. "list invoices for Gilbert")
// reuses this SAME city-name vocabulary rather than hand-duplicating it.
export const KNOWN_AZ_CITY_NAMES = Object.keys(zipCounty.azCityCounty ?? {});
// HVAC persona bank (2026-09-21): "Who are our customers in Las Vegas?" —
// this corpus's own header names Phoenix/Tucson AND Nevada dispatchers, but
// GEO_WORD_RE (below) only ever knew AZ city names, missing every NV one
// (usCityCounty's keys are "city|state" — nlNormalize.js's own VOCAB builder
// already reads this same map for typo-correction; this is the
// classification side of the same data).
export const KNOWN_US_CITY_NAMES = Object.keys(zipCounty.usCityCounty ?? {}).map((k) => k.split('|')[0]);

/* ============================================================ plan vocabulary */

export const ENTITIES = ['customers', 'equipment', 'documents', 'serviceVisits', 'warranties'];
export const OPS = ['count', 'list', 'groupBy', 'sum'];
// R18 P4 (h074): 'year' — "how many different years do we have customers on file for" — a
// distinct-year count derived from a serviceVisits row's own `month` string (YYYY-MM), never a
// real stored column; see detPlan.js's detectDistinctYearsCount and routes/analytics.js's keyOf.
export const GROUP_BY_FIELDS = ['city', 'county', 'state', 'zip', 'brand', 'documentType', 'month', 'year', 'technician', 'warrantyStatus'];
/** Closed field vocabulary a filter's `field` must be one of — see the brief. */
export const FILTER_FIELDS = [
  'state', 'county', 'city', 'zip', 'brand', 'model', 'equipmentType', 'tonnage',
  'refrigerant', 'installYear', 'installDate', 'warrantyStatus', 'documentType', 'technician', 'customerName',
  'hasEmail', 'hasPhone', 'hasDocType', 'lacksDocType',
  // Round 15 (A, data-quality): "missing field"/"not linked" shapes — see
  // DATA_QUALITY_FIELD_ENTITY's own doc comment just below for the per-field
  // entity restriction and DATA_QUALITY_ROW_KEY (further down) for how each
  // one is actually matched against an already-shaped row.
  'hasAnyDocument', 'hasServiceAddress', 'hasZip', 'hasCustomerLink',
  'hasSerial', 'hasInstallDate', 'hasModel', 'hasTonnage',
  'installDateInFuture', 'hasServiceDate',
  // R16 D2 audit item 9: "which units are missing a refrigerant on file" —
  // same shape as hasTonnage right above (a nameplate/startup-sheet/
  // warranty-registration-only field, ~53% coverage in this corpus by
  // design), just the one boolean field that pattern didn't cover yet.
  'hasRefrigerant',
  // R18 (H1, breadth-data-quality-017/018/019/023): the self-join "does this row duplicate
  // another row" shapes ("duplicate customers", "share an address", "used by more than one
  // unit") — see DATA_QUALITY_FIELD_ENTITY's own doc comment on isDuplicateName/sharesAddress/
  // isDuplicateSerial for how these are actually computed (a cross-row frequency map, not a
  // single column's presence, unlike every other data-quality field above).
  'isDuplicateName', 'sharesAddress', 'isDuplicateSerial',
  // R18 P4 (blind generalization round 18 part 2, C2/C4): "customers who needed a repair
  // visit"/"have had a repair call"/"had only preventive maintenance, never a repair" — a
  // cross-document EVENT condition (extractions.service_type), the same "has X but no Y" shape
  // hasDocType/lacksDocType already cover for a document TYPE, just keyed to a service_type
  // VALUE instead — see SERVICE_TYPE_FILTER_FIELDS' own doc comment just below.
  'hasServiceType', 'lacksServiceType',
  // R18 P4 (C3, time-window drop): a raw date-range test directly on a unit's OWN warranty expiry
  // date (data.warranty.expires) — "warranties expire by end of year"/"expired in the past
  // year"/"expiring in the next 90 days" name a real calendar WINDOW the existing warrantyStatus
  // bucket (active/expiring/expired/unknown) can't express (that's a fixed <=365-day bucket, not
  // an arbitrary caller-given window) — see detPlan.js's detectWarrantyExpiryWindow.
  'warrantyExpires',
  // R18 P4 (C3): "how many units are actually registered for warranty" — whether the
  // registration PAPERWORK is on file (data.warranty.registrationState === 'on_file'), a
  // different question from warrantyStatus (coverage expiry) or hasWarrantyInfo (deliberately
  // absent — see DATA_QUALITY_FIELD_ENTITY's own doc comment). Listed in DATA_QUALITY_BOOLEAN_FIELDS
  // below, same boolean-only/op-eq-only shape as hasSerial/hasModel/etc.
  'warrantyRegistered',
  // R18 P4 (C4, negation): "how many customers have zero equipment on file" — the customers-side
  // mirror of hasAnyDocument, computed the same correlated-EXISTS way (buildAnalyticsSQL's
  // customers branch).
  'hasAnyEquipment',
  // R20 (J3, i011): "how many properties do we have more than one unit installed at" — a
  // per-customer equipment count > 1, same correlated-EXISTS idiom as hasAnyEquipment just above,
  // just a ">1" test (see DATA_QUALITY_FIELD_ENTITY's own doc comment).
  'hasMultipleUnits',
  // R20 (J3, i020/i021): "how many purchase orders have we cut to Baker Distributing" — a plain
  // string field on `documents` (the extractions.field_key='vendor_name' value, correlated the same
  // way documents' own service_date already is — see buildAnalyticsSQL's documents branch), matched
  // via matchesFilter's generic string eq/contains path like any other unindexed field.
  'vendor',
  // R20 (J3, i094): "how many warranty registrations took longer than N days after install" — a
  // plain numeric field on `equipment` (shapeEquipmentRow, routes/analytics.js): the day gap between
  // a unit's warranty.registrationOnFile and its own install date, null when either is missing
  // (matchesFilter's ordinary "actual == null -> never matches" rule already excludes those).
  'warrantyRegistrationDays',
  // R21 (M2, g103): "how many trane jobs have we done total" — a documents-only field: any
  // document linked (document_entity_links) to an equipment entity of the named manufacturer —
  // see routes/analytics.js's queryDocumentsByEquipmentBrand for the dedicated join query this
  // needs (buildAnalyticsSQL's documents branch has no notion of an equipment join).
  'linkedEquipmentBrand',
  // D4: a maintenance agreement's END date (the last date of its "Agreement Period: start - end" term) — a forward-looking record field that
  // legitimately names a future year ("which agreements expire in 2027"); documents only, see detPlan.js's detectAgreementEnd.
  'agreementEnd',
  // D8: a permit's scope ('commercial' | 'residential', read from its "Scope of Work" line) and the city that issued it ("CITY OF TUCSON"); documents only,
  // see detPlan.js's detectPermitFilters. Both need the permit's page text (buildAnalyticsSQL's documents branch selects it when one is in the plan).
  'permitScope', 'permitCity',
];
/** hasEmail/hasPhone (item 2, 2026-09-21 live miss): "how many customers have
 *  an email on file" returned the plain customer count — there was no filter
 *  field for "has contact info" at all, so the model's plan silently dropped
 *  the condition. Boolean-only (true/false), customers-only — see
 *  buildAnalyticsSQL/matchesFilter below for the two places that read them. */
export const BOOLEAN_FILTER_FIELDS = ['hasEmail', 'hasPhone'];
/** hasDocType/lacksDocType (100-question persona sample, 2026-09-22, item 7
 *  "customers with a maintenance agreement but no invoice"): customers-only,
 *  value a canonical DOCUMENT_TYPE_IDS string, op 'eq' only — see
 *  parseCrossDocCondition/validatePlan below and routes/analytics.js's
 *  queryCustomersByDocTypeCondition. The model never fills these itself
 *  today (no few-shot teaches it to); parseCrossDocCondition builds the plan
 *  deterministically instead, the same "code decides, not the model" rule
 *  resolveServiceVisitsOverride already follows for entity/op. Listed here
 *  anyway (rather than validated ad hoc) so the closed-vocabulary contract —
 *  "the model never contributes anything outside FILTER_FIELDS" — still
 *  holds for a plan built by this file's own code, not just the model's.*/
export const DOC_TYPE_FILTER_FIELDS = ['hasDocType', 'lacksDocType'];
/**
 * R18 P4 (blind generalization round 18 part 2, clusters C2/C4): "how many trane customers
 * needed a repair visit"/"have had a repair call", "how many customers have never had a
 * preventive maintenance visit", "customers who have had only preventive maintenance, never a
 * repair" — a cross-document EVENT condition keyed to extractions.field_key='service_type'
 * (see extractFields.js FIELD_SPECS' own service_type description), the exact same "has X but no
 * Y" shape as hasDocType/lacksDocType just keyed to a service_type VALUE instead of a document
 * TYPE — customers-only, op 'eq' only, value one of SERVICE_TYPE_VALUES below. Both a hasServiceType
 * and a lacksServiceType filter can appear in the SAME plan (routes/analytics.js's
 * queryCustomersByServiceTypeCondition resolves both, same as queryCustomersByDocTypeCondition
 * already does for hasDocType/lacksDocType).
 */
export const SERVICE_TYPE_FILTER_FIELDS = ['hasServiceType', 'lacksServiceType'];
/** Canonical extractions.field_key='service_type' values this corpus stores (extractFields.js's
 *  own field description) — the closed vocabulary a hasServiceType/lacksServiceType filter's
 *  value must be one of. Only 'Repair' and 'Preventive Maintenance' have a detector today
 *  (detPlan.js's detectCustomersHasServiceType); the rest are listed so a plan naming one some
 *  future detector builds is never rejected by validatePlan for a reason unrelated to that
 *  detector's own confidence. */
export const SERVICE_TYPE_VALUES = ['Preventive Maintenance', 'Repair', 'Emergency', 'Installation', 'Inspection', 'Startup'];
/**
 * Round 15 (A, data-quality cluster — "how many documents aren't linked to
 * any customer", "units missing a serial number", "customers with no service
 * address on file", ...): a MISSING-FIELD condition, closed-vocabulary and
 * boolean-only exactly like hasEmail/hasPhone above, but never restricted to
 * customers — each field here is only ever meaningful for the ONE entity a
 * dispatcher would actually ask it about (a document's own customer link, a
 * unit's own serial/install-date/model/tonnage/warranty, a customer's own
 * address/zip/any-document-at-all). validatePlan (below) enforces this
 * per-field entity restriction; matchesFilter reads each one off the row
 * field DATA_QUALITY_ROW_KEY (further down) already carries, computed once
 * at shape time (routes/analytics.js's shapeCustomerRow/shapeEquipmentRow/
 * shapeDocumentRow) rather than re-derived per filter check.
 */
export const DATA_QUALITY_FIELD_ENTITY = {
  hasAnyDocument: 'customers',
  hasServiceAddress: 'customers',
  hasZip: 'customers',
  hasCustomerLink: ['documents', 'equipment'],
  hasSerial: 'equipment',
  hasInstallDate: 'equipment',
  hasModel: 'equipment',
  hasTonnage: 'equipment',
  hasRefrigerant: 'equipment',
  // Round 15 (A): deliberately no hasWarrantyInfo — deriveWarranty
  // (warrantyRules.js) always writes a non-empty "stable" object onto every
  // unit's data.warranty, even one with no real warranty data at all, so
  // "the column is a non-empty object" can never distinguish real data from
  // none — see detPlan.js's MISSING_FIELD_RULES doc comment for why "no
  // warranty information at all" maps to warrantyStatus 'unknown' instead
  // (already correct, already tested, no new field needed).
  installDateInFuture: 'equipment',
  hasServiceDate: 'documents',
  // R18 (H1, breadth-data-quality-017/018/019/023): unlike every field above (a single column's
  // own presence on ITS OWN row), these three are true only relative to every OTHER row for the
  // same entity — "does another customer share this name/address", "does another unit share this
  // serial number". detectDuplicateCondition (detPlan.js) maps the self-join question family
  // SELF_DUPLICATE_RE names (that regex's own doc comment) to these; routes/analytics.js's
  // attachDuplicateFlag computes the actual boolean (a case-insensitive, trimmed frequency count
  // over ALL of the tenant's rows for the entity, right after fetching them and before any filter
  // narrows the set down) and stores it on the row under this same field name, so matchesFilter's
  // existing DATA_QUALITY_ROW_KEY lookup (below) reads it exactly like any other boolean field —
  // no special case needed there.
  isDuplicateName: 'customers',
  sharesAddress: 'customers',
  isDuplicateSerial: 'equipment',
  // R18 P4 (C4): "how many customers have zero equipment on file" — customers-side mirror of
  // hasAnyDocument (buildAnalyticsSQL's customers branch adds the matching correlated EXISTS).
  hasAnyEquipment: 'customers',
  // R20 (J3, i011): "how many properties do we have more than one unit installed at" — a
  // per-customer equipment count > 1 (a GROUP BY ... HAVING shape), computed the same
  // correlated-subquery way as hasAnyEquipment just above, just a ">1" test instead of ">0".
  hasMultipleUnits: 'customers',
  // R18 P4 (C3): "actually registered for warranty" — data.warranty.registrationState === 'on_file',
  // computed in shapeEquipmentRow (routes/analytics.js) directly from the same `warranty` JSON
  // column warrantyStatusOf already reads; deliberately its own field, never folded into
  // warrantyStatus (a coverage-expiry bucket) or a hasWarrantyInfo boolean (see this map's own
  // doc comment on why that one stays absent).
  warrantyRegistered: 'equipment',
};
export const DATA_QUALITY_BOOLEAN_FIELDS = Object.keys(DATA_QUALITY_FIELD_ENTITY);
export const FILTER_OPS = ['eq', 'neq', 'contains', 'gt', 'gte', 'lt', 'lte', 'in'];
// R35 (owner decision 2026-10-01): 'covered' = NOT EXPIRED (end date on or after today) = active OR expiring — the plain meaning of
// "still under warranty" / "active" / "current" / "valid" / "covered". It is a filter value only (never a row's own status, never a
// groupBy bucket); matchesFilter expands it. 'active' alone stays the strict "more than a year left" bucket.
export const WARRANTY_STATUSES = ['active', 'expiring', 'expired', 'unknown', 'covered'];
export const WARRANTY_COVERED_STATUSES = new Set(['active', 'expiring']);
export const MAX_LIMIT = 500;
/**
 * R39 (the "500" bug). MAX_LIMIT is the cap on a LIST a person is shown (and on plan.limit). It was ALSO the LIMIT on the SQL that fetches the rows the executor
 * (routes/analytics.js) then filters and counts in JS, and the stated total was `filtered.length` - so every count over more than 500 records came back as
 * exactly 500 ("You have 500 documents."). The fetch now reads up to SCAN_LIMIT rows (bounded memory), and a result that fills it is TRUNCATED: the executor
 * then declines instead of printing a number (never a count of a capped list). A bare unfiltered count never needs the rows at all: buildAnalyticsCountSQL
 * gives its exact COUNT(*). */
export const SCAN_LIMIT = Math.max(MAX_LIMIT + 1, Math.trunc(Number(process.env.ANALYTICS_SCAN_LIMIT)) || 20000);
export const DEFAULT_LIMIT = 500;
/** "who's our biggest customer" (round 4, item 1) — customers RANKED by a
 *  size measure, not filtered/counted. Only meaningful for entity
 *  'customers' + op 'list'; see queryTopCustomers, routes/analytics.js. */
export const SORT_FIELDS = ['equipmentCount', 'documentCount'];
export const TOP_CUSTOMERS_LIMIT = 10;
/** Field-phrasing g133/g138 ("whats the oldest unit we have on file" /
 *  "whats our newest install") — equipment RANKED by installation_date, not
 *  filtered/counted, the equipment-entity sibling of SORT_FIELDS above. Only
 *  meaningful for entity 'equipment' + op 'list' — see
 *  queryInstallDateExtreme/formatInstallDateExtremeAnswer, routes/analytics.js. */
export const INSTALL_DATE_SORT_FIELDS = ['installDateAsc', 'installDateDesc'];
/** Ties (several units sharing the exact same printed install date) are
 *  never silently dropped, but a cap keeps one pathological tie from
 *  producing an unbounded answer/citation list. */
export const INSTALL_DATE_EXTREME_LIMIT = 50;
/** R20 (J3, i115/i116): "what's the earliest/most recent warranty registration date we have on
 *  file" — equipment RANKED by data.warranty.registrationOnFile, the warranty-registration
 *  sibling of INSTALL_DATE_SORT_FIELDS just above. Only meaningful for entity 'equipment' + op
 *  'list' — see queryWarrantyRegDateExtreme/formatWarrantyRegDateExtremeAnswer, routes/analytics.js. */
export const WARRANTY_REG_DATE_SORT_FIELDS = ['warrantyRegDateAsc', 'warrantyRegDateDesc'];

/* ================================================================ classifier
 *
 * Cheap, deterministic pre-check — regex only, no model call — that decides
 * whether a question is WORTH spending the one Haiku call on. False positives
 * here cost one wasted (cheap, cached-schema) model call that then gets
 * rejected by validatePlan and falls through; false negatives cost nothing
 * (the question just goes to retrieval, same as today). So this errs toward
 * catching real aggregate questions and explicitly excludes phrasings that
 * belong to a SINGLE record (already fastPath's or retrieval's job) — see
 * EXCLUDE below, which mirrors ask.js's own comment about "how many documents
 * does Plaza Dental have" needing retrieval, not a meta/aggregate answer.
 */
/**
 * Reviewer NO-GO (2026-09-21, round 4, item 1): "how many clients do we
 * have" answered "Nothing in your records answers that" — a plain-English
 * owner phrasing that never reaches a document at all, so retrieval had
 * nothing to cite. Two separate gaps caused it: (1) "clients" WAS already
 * accepted, but a bare "do we have" question names no location/time/brand
 * word, and CONTEXT (below, since removed as a gate — see
 * preClassifyAnalytics's own doc comment) required one; (2) most of the
 * plain-English synonyms an owner actually says out loud ("accounts",
 * "homeowners", "properties", "jobs", "rooftop units", "paperwork", ...)
 * were never in the noun list at all.
 *
 * ONE table, used by BOTH consumers: this classifier's AGGREGATE_NOUN regex,
 * and the planner's ANALYTICS_SYSTEM_PROMPT (buildEntitySynonymPromptLine,
 * below) — so a synonym added here is recognized by both without hand-
 * duplicating the list into the prompt text. Keys are the canonical
 * ENTITIES/groupBy-dimension names; `technicians` is not itself a plan
 * entity (there's no "how many technicians" op) but feeds GROUP_SHAPE_RE's
 * "by tech/by crew" dimension-word recognition below.
 */
export const ENTITY_SYNONYMS = {
  customers: [
    'customer', 'customers', 'client', 'clients', 'account', 'accounts',
    'homeowner', 'homeowners', 'household', 'households', 'property', 'properties',
    'site', 'sites', 'house', 'houses', 'business', 'businesses', 'people we service',
  ],
  equipment: [
    'equipment', 'unit', 'units', 'system', 'systems', 'ac', 'acs', 'air conditioner', 'air conditioners',
    'furnace', 'furnaces', 'heat pump', 'heat pumps', 'condenser', 'condensers', 'rtu', 'rtus',
    'rooftop unit', 'rooftop units', 'piece of equipment', 'pieces of equipment',
    // R4 loop: more field names for the same equipment count (kill switch DONOVAN_EQUIP_TYPE_SYNONYMS=0).
    ...(process.env.DONOVAN_EQUIP_TYPE_SYNONYMS === '0' ? [] : [
      'mini split', 'mini splits', 'mini-split', 'mini-splits', 'minisplit', 'minisplits', 'ductless', 'air handler', 'air handlers',
      'package unit', 'package units', 'packaged unit', 'packaged units', 'boiler', 'boilers',
    ]),
    // HVAC persona bank (2026-09-21, hvac-personas.mjs): "how many Trane
    // installs have we done since 2020" — "install"/"installs" is a plain,
    // common owner synonym for "installed unit", same shape as "unit"/
    // "system" above, not a new noun category.
    'install', 'installs',
  ],
  documents: [
    'document', 'documents', 'doc', 'docs', 'file', 'files', 'paperwork', 'record', 'records',
    'invoice', 'invoices', 'ticket', 'tickets', 'work order', 'work orders',
    // Day 1 training-plan question bank (2026-09-21, gen-question-bank.mjs)
    // measured a real classifier gap here: "how many permits do we have" /
    // "how many proposal quotes are there" / etc. never matched AGGREGATE_NOUN
    // at all — these are just more of the same per-document-type nouns as
    // "invoice"/"ticket"/"work order" above, not a new shape.
    'permit', 'permits', 'quote', 'quotes', 'proposal', 'proposals', 'agreement', 'agreements',
    'photo', 'photos', 'correspondence', 'startup sheet', 'startup sheets',
    'dispatch note', 'dispatch notes', 'inspection report', 'inspection reports',
    'purchase order', 'purchase orders',
    // HVAC persona bank: "how many maintenance plans do we have running" —
    // the owner's own name for a maintenance-agreement document.
    'maintenance plan', 'maintenance plans',
  ],
  serviceVisits: [
    'service visit', 'service visits', 'job', 'jobs', 'visit', 'visits', 'call', 'calls',
    'service call', 'service calls', 'ticket', 'tickets',
  ],
  warranties: ['warranty', 'warranties'],
  technicians: ['technician', 'technicians', 'tech', 'techs', 'guy', 'guys', 'crew'],
};

/** Longest phrase first, so a multi-word synonym ("rooftop units") matches
 *  before a shorter one that happens to be its own suffix ("units") could —
 *  harmless for `test()` (order never changes whether SOME alternative
 *  matches) but keeps the built pattern readable/debuggable in that order. */
function synonymAlternation(words) {
  return [...new Set(words)]
    .sort((a, b) => b.length - a.length)
    .map((w) => escapeRegExp(w))
    .join('|');
}

/**
 * Tier 2 "Donovan learns nightly" (handoffs/DONOVAN_TRAINING_PLAN_2026-09-21.md),
 * Part A: every regex below that is built FROM ENTITY_SYNONYMS is produced by
 * this one factory, so a runtime-learned overlay (a newly-approved synonym
 * word for an existing entity) can rebuild exactly the same regexes from a
 * WIDENED synonym table with no risk of the two ever drifting apart. Called
 * once at module load with the base ENTITY_SYNONYMS (BASE_CLASSIFIER_REGEXES,
 * below — every existing top-level const just aliases a field of it, so
 * nothing downstream changes), and again, on demand, by withLearnedOverlay
 * for a specific overlay object.
 */
function buildClassifierRegexes(entitySynonyms) {
  const aggregateNoun = new RegExp(
    `\\b(${synonymAlternation([
      ...entitySynonyms.customers,
      ...entitySynonyms.equipment,
      ...entitySynonyms.documents,
      ...entitySynonyms.serviceVisits,
      ...entitySynonyms.warranties,
      // R21 (M2, i198): "how many distinct technicians have we ever dispatched" names ONLY a
      // technician noun (no customer/equipment/document/serviceVisit synonym at all) — technicians
      // was missing from this list entirely, so a bare "how many <technician synonym>" question
      // failed the QUANTIFIER+aggregateNoun admit test and never reached the analytics planner
      // (which already has a real distinct-count answer for it — detectDistinctDimensionCount,
      // detPlan.js — once given the chance).
      ...entitySynonyms.technicians,
    ])})\\b`,
    'i'
  );
  const groupShape = new RegExp(
    `\\b(group(?:ed)?\\b[\\s\\S]*\\bby\\b|breakdown\\b[\\s\\S]*\\bby\\b|\\bby\\b\\s+(city|county|state|zip|brand|month|warranty status|${synonymAlternation(entitySynonyms.technicians)})\\b)`,
    'i'
  );
  const customersWhose = new RegExp(`\\b(${synonymAlternation(entitySynonyms.customers)})\\s+whose\\b`, 'i');
  const biggestCustomer = new RegExp(`\\b(biggest|largest|top)\\s+(\\d+\\s+)?(${synonymAlternation(entitySynonyms.customers)})\\b`, 'i');
  const weYesNoNoun = new RegExp(
    `\\b(${synonymAlternation([
      ...entitySynonyms.customers,
      ...entitySynonyms.equipment,
      ...entitySynonyms.documents,
      ...entitySynonyms.serviceVisits.filter((w) => w !== 'call' && w !== 'calls'),
      ...entitySynonyms.warranties,
    ])})\\b`,
    'i'
  );
  const pluralEntityWords = [
    ...new Set([
      ...entitySynonyms.customers, ...entitySynonyms.equipment,
      ...entitySynonyms.documents, ...entitySynonyms.serviceVisits,
      ...entitySynonyms.warranties,
    ]),
  ].filter((w) => /s$/i.test(w) || w === 'equipment');
  const whatPlural = new RegExp(`\\bwhat\\s+(${synonymAlternation(pluralEntityWords)})\\b`, 'i');
  const whatDidWe = new RegExp(
    `\\bwhat\\s+(${synonymAlternation(pluralEntityWords)})\\b[\\s\\S]{0,40}\\bdid we\\b|\\bwhat\\s+did we\\s+(service|install|repair|replace|fix|visit)\\b`,
    'i'
  );
  return { aggregateNoun, groupShape, customersWhose, biggestCustomer, weYesNoNoun, pluralEntityWords, whatPlural, whatDidWe };
}

const BASE_CLASSIFIER_REGEXES = buildClassifierRegexes(ENTITY_SYNONYMS);
const AGGREGATE_NOUN = BASE_CLASSIFIER_REGEXES.aggregateNoun;
const QUANTIFIER = /\b(how many|count|list|which|show me|total)\b/i;
// "group X by Y" / "breakdown by Y" / "grouped by Y" — an aggregate-request
// shape regardless of which noun is being broken down, so a groupBy
// dimension word alone (technician, brand, month) is enough even without one
// of AGGREGATE_NOUN's fixed nouns ("show me a breakdown by technician").
// Read as cr.groupShape (preClassifyAnalytics, below) — never through a
// top-level alias, since it must reflect whatever overlay is active for a
// given call (withLearnedOverlay).
const WHO_SERVICED_RE = /\bwho did we (service|work for)\b/i;
const WHICH_CUSTOMERS_RE = /\bwhich customers\b/i;
// HVAC persona bank (2026-09-21): "Customers whose warranty expires in the
// next 90 days?" — the same "a customer-noun filtered by a relative clause"
// shape WHICH_CUSTOMERS_RE already bypasses QUANTIFIER for, just opening
// with the bare noun ("Customers whose...") instead of "which customers".
// Built from the same customer synonym list so it matches as readily as
// "clients whose"/"accounts whose". Read as cr.customersWhose, same reason
// as GROUP_SHAPE_RE above.
// "who's/who is our biggest client" / "top 10 customers" / "our largest
// accounts" — asks for customers RANKED by some size measure (equipment or
// document count), not filtered/counted — a distinct op from every other
// bypass trigger (see routes/analytics.js's queryTopCustomers). Built from
// the SAME customer synonym list, so "biggest account"/"largest client"
// match exactly as readily as "biggest customer". Read as cr.biggestCustomer.
/**
 * Reviewer NO-GO (2026-09-21, round 2, gap 1): "who has Trane units" and
 * "customers with expired warranties" / "units older than 10 years" named a
 * real aggregate question but matched none of the bypass triggers above and
 * failed the generic QUANTIFIER check (no how-many/count/list/which/show-me/
 * total word present at all) — so they fell through to retrieval and got a
 * partial, unfiltered model answer instead of a real analytics one. These
 * three triggers bypass QUANTIFIER the same way WHICH_CUSTOMERS_RE already
 * does, for the same reason: the SHAPE of the sentence already says "many",
 * regardless of which specific quantifier word (if any) it used.
 */
const WHO_HAS_RE = /\bwho (?:has|have)\b/i;
/** "customers with X" / "units that have X" / "equipment who have X" — a
 *  noun followed by a possessive-filter preposition, never a single named
 *  record's own question (that's POSSESSIVE_SINGLE_RE's "does/did X have"
 *  shape, checked first and unaffected by this). */
const NOUN_WITH_RE = /\b(customers?|clients?|units?|equipment)\s+(with|that have|which have|who have|having)\b/i;
/** "units older than N years" / "installed before/after 2020" — an age/date
 *  filter shape on its own aggregate noun, with no quantifier word needed. */
const AGE_FILTER_RE = /\b(older than|newer than|installed (?:before|after|in))\b/i;
// HVAC persona bank (2026-09-21): "What's the oldest unit we're still
// servicing?" — a superlative-ranked ask on its own aggregate noun, the same
// "no quantifier word needed" shape AGE_FILTER_RE/BIGGEST_CUSTOMER_RE already
// bypass QUANTIFIER for; this covers oldest/newest/latest/earliest, which
// BIGGEST_CUSTOMER_RE's own biggest/largest/top list doesn't.
// R21 M2 (Cluster 3, j147 "whose unit did we most recently install"): a genuine synonym of
// "newest"/"latest" with neither word present — see detPlan.js's own MOST_RECENTLY_INSTALLED_RE.
const SUPERLATIVE_RE = /\b(oldest|newest|latest|earliest)\b|\bmost\s+recently\s+install(?:ed)?\b/i;
/**
 * Item 2 (2026-09-21 live miss): "customers missing a phone number" is a real
 * aggregate/filter question (the hasEmail/hasPhone shape below) but names no
 * QUANTIFIER word ("how many customers have an email on file" already passes
 * via QUANTIFIER + AGGREGATE_NOUN alone, same as any other filtered count) —
 * only the QUANTIFIER-less phrasings need this bypass, mirroring AGE_FILTER_RE
 * just above. Paired with AGGREGATE_NOUN the same way AGE_FILTER_RE is.
 */
const CONTACT_FILTER_RE = /\b(have|has|with|no|missing|without)\s+(an?\s+)?(email|phone)\b/i;

/**
 * HVAC persona bank (2026-09-21): a whole cluster of real yes/no owner
 * questions — "Do we have any commercial accounts?", "Do we have any
 * Goodman customers in Tucson?", "Have we ever installed a Daikin?", "Do we
 * service anything in Nevada?" — name no QUANTIFIER word at all and often no
 * fixed AGGREGATE_NOUN word either (a bare brand or state name is the only
 * noun present). The subject here is always the generic "we" — never a named
 * customer record, which POSSESSIVE_SINGLE_RE already excludes via its own
 * we/you/they/company/shop negative lookahead — so a "do/does/have/has we"
 * yes/no shape is safe to trust broadly once paired with SOME domain signal
 * (an entity noun, a known brand, a known AZ/NV city/county/state name, or a
 * bare zip-code mention). Deliberately excludes "did we" (the money live-miss
 * cluster's own "did we invoice/bill last month" phrasings must stay OFF
 * analytics and reach the money gate instead — see isMoneyQuestion, which is
 * checked before this classifier ever runs in api/ask.js).
 */
// HVAC persona bank (2026-09-21): "Do we have more invoices or more service
// tickets on file?" -> gen-question-bank.mjs's own voice-style transform
// rewrites "do we have" to "we got" ("we got more invoices or more service
// tickets on file"), the same plain dispatcher phrasing toVoiceStyle already
// applies everywhere else in this bank — "we got" added as its own
// alternative rather than widening the "do/does/have/has we" shape itself.
const WE_YES_NO_RE = /\b(?:do|does|have|has)\s+we\b|\bwe\s+got\b/i;
/** Same noun list AGGREGATE_NOUN uses, minus the bare 'call'/'calls' words —
 *  those two, alone, collide with an ordinary "...so I can call them" /
 *  "before end of day" callback-pleasantry tail (a sloppiness variant this
 *  bank generates, and plausible real dispatcher chatter too) which has
 *  nothing to do with a service call. "service call(s)" itself is unaffected
 *  (still present via ENTITY_SYNONYMS.serviceVisits' own two-word phrases).
 *  Read as cr.weYesNoNoun (preClassifyAnalytics, below), same reason as
 *  GROUP_SHAPE_RE's own comment above. */
const BRAND_RE = new RegExp(`\\b(${synonymAlternation(BRAND_WORDS)})\\b`, 'i');
const GEO_WORD_RE = new RegExp(
  `\\b(arizona|nevada|az|nv|${synonymAlternation(KNOWN_AZ_CITY_NAMES)}|${synonymAlternation(KNOWN_US_CITY_NAMES)}|${synonymAlternation(KNOWN_COUNTY_NAMES)})\\b`,
  'i'
);
const ZIP_CODE_WORD_RE = /\bzip\s*codes?\b/i;
// HVAC persona bank (2026-09-21): "customers in 85201" — a bare 5-digit ZIP
// value with no word "zip" at all, the same geo-filter shape GEO_WORD_RE
// already covers for a city/county name. Safe to combine with AGGREGATE_NOUN
// the same way GEO_WORD_RE is: a genuine single-record reference (a street
// address, an "at 123 Main St, 85201" full address, a serial number that
// happens to be 5 digits) is caught by looksLikeSingleRecordReference
// upstream and short-circuits preClassifyAnalytics before this ever runs.
const ZIP_VALUE_RE = /\b\d{5}\b/;

/**
 * "Which brand do we have the most of?" / "Who did the most jobs in August?"
 * — a ranking-by-count question, the same "SHAPE already says many" idea
 * BIGGEST_CUSTOMER_RE/WHO_SERVICED_RE already bypass QUANTIFIER for, just for
 * a non-customer entity (brand, technician) BIGGEST_CUSTOMER_RE's own
 * customer-only synonym list doesn't cover. Stands alone (no AGGREGATE_NOUN
 * required) the same way those two do — "the most" is on its own a strong
 * enough ranking signal in this domain, and any single-record phrasing that
 * happened to also say "the most" would already have been excluded above by
 * looksLikeSingleRecordReference (an address/serial/named-record question).
 */
const THE_MOST_RE = /\bthe\s+most\b/i;
/**
 * R21 (M2, h109): "who's our busiest technician" — the same "ranking-by-count question, the SHAPE
 * already says many" idea THE_MOST_RE/BIGGEST_CUSTOMER_RE bypass QUANTIFIER for, just phrased with
 * "busiest"/"most active" instead of a literal "the most" — a real, common everyday synonym for it
 * (a busy technician IS the one with the most jobs), not this exam's own wording. Stands alone for
 * the same reason THE_MOST_RE does: on its own, in this domain, it is an unambiguous ranking signal.
 */
const BUSIEST_RE = /\bbusiest\b|\bmost\s+active\b/i;
/** "Who's due for fall maintenance?" — no aggregate noun at all ("fall
 *  maintenance" names neither a customer/equipment/document synonym), but
 *  "who's/who is/who needs due" is the same "which customers are overdue"
 *  aggregate ask in a different, equally common phrasing. */
// "whos due" (no apostrophe) is this bank's own voice-style transform of
// "who's due" (toVoiceStyle strips every apostrophe) — "whos" added as its
// own alternative alongside "who's" rather than making the apostrophe
// optional inside "who's", which would also start matching an unrelated
// "whose" ("customers whose warranty...", a different shape entirely).
const WHO_DUE_RE = /\bwho(?:'s|s\b|\s+is|\s+needs)\s+(?:due|overdue)\b/i;
/** "Who's still under warranty?" / "who's out of warranty" — same bare "who's" shape as WHO_DUE_RE
 *  above (no customer/equipment noun at all), for warranty instead of maintenance-due. Live gap
 *  (2026-09-25 owner report): "how many clients are under warranty" already reaches analytics via
 *  QUANTIFIER+aggregateNoun, but a "who's ..." phrasing of the exact same question named no
 *  quantifier and no noun, so it fell through every gate here into the slow agent path instead. */
const WHO_WARRANTY_RE = /\bwho(?:'s|s\b|\s+is|\s+are|\s+has|\s+have)\b[^?]*\bwarrant/i;
/**
 * "Expired warranties -- what about just the Mesa ones?" / "Casa Grande
 * customers -- now just the ones with Goodman units" — a follow-up question
 * that narrows a PRIOR aggregate answer, phrased as a dash + "what about"/
 * "now" rather than repeating a quantifier word. Paired with AGGREGATE_NOUN
 * (never stands alone) since the dash-prefix shape alone isn't a strong
 * enough signal on its own.
 */
const FOLLOWUP_NARROW_RE = /--\s*(?:what about|now)\b/i;
/** "What zip codes do we serve?" / "How many different zip codes do we
 *  cover?" — zip/county/city/state are GROUP_BY_FIELDS dimension words, not
 *  entity nouns, so AGGREGATE_NOUN itself never covers them; this is the
 *  parallel noun list for exactly the "coverage" style questions that ask
 *  about the dimension itself ("what zip codes", "what counties") rather
 *  than a filtered count of customers/equipment/documents. */
const COVERAGE_NOUN_RE = /\b(zip\s*codes?|counties|cities|states)\b/i;

/**
 * Live miss (2026-09-21, "which units had service this month" cluster),
 * item 3: "what units were serviced this month" / "what equipment got
 * serviced this month" name no QUANTIFIER word at all ("which"/"how many"/
 * "list"/"show me"/"total") — plain English "what" is exactly as much a
 * quantifier as "which" is when it's immediately followed by a PLURAL entity
 * noun ("what units", "what customers") or when the question is a "what ...
 * did we" clause about US doing something to many ("what did we service in
 * September"). Bare "what" is ALSO how a genuine single-record lookup starts
 * ("what's the serial number at 1234 Elm St", "what's the phone number for
 * Sandra Wyckoff") — those never reach this far: looksLikeSingleRecordReference
 * is checked first and short-circuits preClassifyAnalytics entirely (see its
 * own doc comment), and a real single-record "what's ..." contraction never
 * matches "what\s+" in the first place (no space between "what" and "'s").
 * buildClassifierRegexes' own pluralEntityWords is every ENTITY_SYNONYMS word
 * that is actually plural (ends in "s"), plus "equipment" itself (a mass noun
 * with no distinct plural form) — never a bare singular ("what unit", "what
 * customer") on its own, which stays exactly as excludable as it already was.
 * Read as cr.whatPlural (preClassifyAnalytics, below) — never through a
 * top-level alias, same reason as GROUP_SHAPE_RE's own comment above.
 *
 * "what <plural entity noun> did we <verb>" (cr.whatDidWe) only — a bare
 * "what did we do for Ramirez" is a single customer's history and must stay
 * on retrieval.
 */

/** "how many documents does Plaza Dental have" / "does X have a warranty" —
 *  a single, named record's own attribute, not an aggregate across many. */
/**
 * Reviewer NO-GO (2026-09-21, round 4, item 1): "how many visits did we have
 * this week" (a real aggregate question, "we" as subject) matched this
 * regex's "did ... have" shape exactly like "does Henderson have a
 * warranty" (a real single-record one, a NAMED subject) and was wrongly
 * excluded. The negative lookahead excludes the common generic-subject
 * pronouns ("we"/"you"/"they"/"the company"/"the shop") right after
 * does/did — those are never a single customer RECORD, so "does/did <pronoun>
 * have" is never this pattern's intended shape; a genuinely named subject
 * ("Henderson", "the unit at 3247 Elm", "Plaza Dental") still matches.
 */
const POSSESSIVE_SINGLE_RE = /\b(does|did)\s+(?!we\b|you\b|they\b|the company\b|the shop\b)[\s\S]+\b(have|has|need)\b/i;

/**
 * R20 (J3, i200/F1 sibling — the ask.js "analytics-candidate gate miss" for "does X have more Y
 * than Z"/"is A more common than B"): "does Chandler have more customers on the books than Tempe"
 * matches POSSESSIVE_SINGLE_RE just above ("does <name> ... have") exactly like a genuine
 * single-record lookup ("does Henderson have a warranty") would, wrongly routing a two-entity
 * COMPARISON to fastPath/retrieval instead of analytics/comparison.js's own detectCountComparison
 * (which already resolves this exact shape once it's allowed through). A "more/fewer/less/higher/
 * busier ... than" construction can never be about one record's own attribute — it always names TWO
 * things being sized against each other — so it is excluded from the single-record read here, before
 * POSSESSIVE_SINGLE_RE ever gets a chance to claim it.
 */
// R20 (coordinator follow-up, 2026-09-27): the exact same two-sided comparison ("more/fewer/...")
// can also be worded with "compared to"/"compare(d) with"/"vs"/"versus" instead of "than" ("did we
// install more units this year compared to last year", "... higher this year vs last year") — same
// shape COMPARISON_THAN_RE already exists for (its own doc comment above), just a different
// connector word. Widened here (not by adding a new regex) so every existing caller — this file's
// own preClassifyAnalytics/looksLikeSingleRecordReference — picks up the wider connector for free.
const COMPARISON_THAN_RE =
  /\b(?:more|fewer|less|greater|higher|busier)\b[\s\S]*\b(?:than|vs\.?|versus|compared?\s+(?:to|with))\b/i;

// R20 (J3): a bare yes/no comparison ("is Daikin more common than Goodman", "did we install more
// units last year than this year") never puts "we"/"there"/"you"/"our shop" right after the lead
// verb the way EXISTENCE_QUESTION_RE requires — the subject is whatever is being compared (a brand,
// a year, a city). Scoped to the same yes/no verb family as comparison.js's own YESNO_LEAD_RE so an
// unrelated declarative sentence containing "than" is never mistaken for a question.
const COMPARISON_YESNO_LEAD_RE = /^\s*(?:do|does|did|is|are|was|were|has|have)\b/i;

// R21 M2 (deferred list, i095): "do most of our warranty registrations happen within 30 days of
// the install" — see analytics/comparison.js's detectWarrantyRegDaysMajority (same regex shape,
// duplicated here rather than imported to avoid a circular import between the two files).
const WARRANTY_REG_DAYS_MAJORITY_ADMIT_RE =
  /\bmost\b[\s\S]{0,40}\bwarranty\s+registrations?\b[\s\S]{0,25}\bwithin\s+\d{1,3}\s*days?\s+of\s+(?:the\s+)?install/i;

/**
 * Reviewer NO-GO (2026-09-21, A1): WHICH_CUSTOMERS_RE / WHO_SERVICED_RE /
 * GROUP_SHAPE_RE above return true WITHOUT the AGGREGATE_NOUN/CONTEXT check
 * the generic path uses — "Which customers are at 1234 Main St, Mesa AZ?"
 * matched WHICH_CUSTOMERS_RE and was pre-classified as analytics, which then
 * has no `field: "address"` in the closed vocabulary to filter on, so the
 * planner produced an unfiltered `list customers` plan that confidently
 * returned every customer. A question naming a SPECIFIC street address or a
 * serial/model-shaped token is asking about one record, never an aggregate —
 * exactly fastPath's own territory — so it is excluded here, BEFORE any of
 * the trigger regexes below get a chance to bypass the vocabulary check.
 * This is checked first and short-circuits every other rule, deliberately:
 * an address or identifier is a stronger, unambiguous signal than any
 * quantifier/aggregate-noun match could ever override.
 */
// R17 (G4, consolidation): the suffix alternation (capture group below) was this file's own
// hand-maintained list (missing the "boulevard"/"parkway"/"place" long forms); now the shared
// canonical superset — see geo/streetSuffix.js's own header comment. Still one capture group
// (unused — every call site only reads the whole match), same as before.
export const STREET_ADDRESS_RE = new RegExp(
  `\\b\\d{2,6}\\s+[NSEW]?\\.?\\s*[A-Za-z0-9.' ]+\\b(${STREET_SUFFIX_ALTERNATION})\\b`,
  'i'
);
/**
 * Reviewer NO-GO (2026-09-21, round 3, item 3): round 2's WHO_HAS_RE bypass
 * ("who has Trane units") let "who has the unit at 1234 Main" through too —
 * STREET_ADDRESS_RE requires a recognized street-suffix word (st/ave/rd/...)
 * that "1234 Main" alone never supplies. "at <number> <word>" is a weaker but
 * still reliable single-record signal on its own — a real aggregate question
 * essentially never phrases itself "at 1234 Main" — so it is checked here too,
 * before WHO_HAS_RE (or any other trigger) gets a chance to fire. Known,
 * accepted trade-off: a question like "how many customers do we have at 3
 * locations" would also match this and get excluded; that is the same
 * "single-record signal outranks any aggregate signal" call
 * looksLikeSingleRecordReference already makes for STREET_ADDRESS_RE/serial
 * tokens, and false negatives here cost nothing (the question still reaches
 * retrieval, same as any other fast-path/analytics miss).
 */
export const AT_ADDRESS_RE = /\bat\s+\d{1,6}\s+\w/i;
/**
 * Reviewer NO-GO (2026-09-21, round 4, item 1): dropping CONTEXT as a
 * required gate (preClassifyAnalytics, below) opened one real regression —
 * "how many tons is the Whitmore unit" (an existing adversarial check, no
 * address, no digit token) would now pass QUANTIFIER + AGGREGATE_NOUN with
 * nothing left to exclude it. The one thing that DOES distinguish it from a
 * real aggregate question like "how many rooftop units" is the definite
 * article + capitalized proper noun: "the <Name> unit/system/..." names ONE
 * specific, already-identified record, the same shape fastPath itself
 * resolves ("the Whitmore unit", "the Ortega account"). Case-SENSITIVE on
 * purpose — a capital letter is the signal; "the rooftop units" (lowercase,
 * plural) never matches this.
 */
// HVAC persona bank (2026-09-21): "do we have a PO on file for the mercer
// job" / "is the isaacson unit still under warranty" / "startup sheet for the
// prentiss install" — real dispatcher phrasings of this exact shape, just
// never typed with a capital letter (a sloppy/voice/typo'd question is
// lowercase by construction). The capital-letter requirement above was a
// reasonable proxy when this rule was first written but is actually stricter
// than the signal it needs: "the <word> unit/job/account/..." naming ONE of
// this fixed, closed set of singular-record nouns is unambiguous regardless
// of case — a real aggregate question is never phrased "the X job" for any
// word X. Case-insensitive now; 'install'/'ticket'/'visit' added alongside
// the original noun set for the same "startup sheet for the X install"/
// "last service ticket for X" shapes.
// HVAC persona bank (2026-09-21): "What's the oldest unit we're still
// servicing?" fit this exact "the <word> unit" shape just as well as "the
// Thornton unit" does, wrongly flagging a genuine aggregate superlative ask
// as a single-record reference — "the X job" ISN'T always unambiguous, a
// superlative adjective in the X slot is the one case that names no specific
// record at all. Excluded via a negative lookahead (SUPERLATIVE_RE's own
// word list, plus the ranking adjectives BIGGEST_CUSTOMER_RE already
// recognizes) rather than narrowing the noun set, which still needs to catch
// every OTHER "the <real name> unit" phrasing untouched.
// Reviewer NO-GO (2026-09-22): a literal-word lookahead only ever excludes a
// CORRECTLY-SPELLED superlative — "what's the oewest unit we've installed"
// (a typo of "newest") still matched the broad "the <word> unit" shape,
// wrongly single-record-flagging it. Worse, this check runs on the
// ORIGINAL, uncorrected text (normalizeQuestion's own singleRecord guard, so
// nlNormalize's fuzzy corrector never even gets a chance to fix "oewest" to
// "newest" first — a typo that blocks its own fix from ever running, the
// same class of bug "mainttenance" was above. Fixed by splitting the check in
// two: SINGULAR_NAMED_RECORD_RE now just captures the adjective slot
// (group 1) with no exclusion built in, and hasSingularNamedRecord (below)
// rejects the match itself when that captured word is an EXACT OR
// near-typo (edit distance <= 1) match of a superlative/ranking word —
// covering "oewest"/"oldst"/every other single-edit misspelling of
// oldest/newest/latest/earliest/biggest/largest/smallest/most, not just the
// ones spelled correctly.
// Reviewer NO-GO (2026-09-22, follow-up): "Startup sheet for the Holbrook
// instbll?" — a typo of "install" ("instbll") isn't literally in the noun
// alternation, so the whole shape missed this single-record question.
// Tried a fully generic, fuzzy-matched noun slot first, but that reopened a
// worse hole: "instbll" earns its edit-distance-1 tolerance against
// "install", but so does the common PLURAL "customers" against the
// SINGULAR "customer" already in this list — and unlike "install", the
// singular/plural distinction here is load-bearing (an aggregate "group
// customers by county" must never single-record-match). Reverted to a
// literal alternation; "instbll" is added as its own named alternative
// instead, the same narrow, closed-list approach "mainttenance" above
// already uses for exactly this class of typo.
const SINGULAR_NAMED_RECORD_RE =
  /\bthe\s+([a-zA-Z][a-zA-Z']*)\s+(unit|system|account|job|customer|client|property|install|instbll|ticket|visit)\b/gi;
const SUPERLATIVE_WORDS = ['oldest', 'newest', 'latest', 'earliest', 'biggest', 'largest', 'smallest', 'most'];

/** Same Damerau-Levenshtein-<=1 idea nlNormalize.js's own withinEditDistance1
 *  and contactLookup.js's own copy of it already use — duplicated rather
 *  than imported (nlNormalize.js imports FROM this file, so the reverse
 *  import would be circular; see this file's own "must stay DB/model-free,
 *  duplicate the small stuff" convention elsewhere, e.g.
 *  TRAILING_NAME_STOPWORD_RE). Six lines of pure string math, not worth a
 *  shared module for. */
function isCloseTo(a, b) {
  if (a === b) return true;
  const la = a.length;
  const lb = b.length;
  if (Math.abs(la - lb) > 1) return false;
  if (la === lb) {
    let diffs = 0;
    let i1 = -1;
    let i2 = -1;
    for (let i = 0; i < la; i++) {
      if (a[i] !== b[i]) {
        diffs++;
        if (diffs === 1) i1 = i;
        else if (diffs === 2) i2 = i;
        else return false;
      }
    }
    if (diffs <= 1) return true;
    return i2 === i1 + 1 && a[i1] === b[i2] && a[i2] === b[i1];
  }
  const [s, l] = la < lb ? [a, b] : [b, a];
  let i = 0, j = 0, skipped = false;
  while (i < s.length && j < l.length) {
    if (s[i] === l[j]) { i++; j++; continue; }
    if (skipped) return false;
    skipped = true;
    j++;
  }
  return true;
}

function isSuperlativeWord(word) {
  const w = word.toLowerCase();
  return SUPERLATIVE_WORDS.some((sw) => isCloseTo(w, sw));
}

// Reviewer NO-GO (2026-09-22, follow-up 2): with the noun back to a literal
// alternation, a single question can still legitimately contain more than
// one "the <word> <noun>" occurrence (e.g. "the oldest unit" earlier in a
// sentence and "the Thornton job" later) — matchAll (global flag on the
// regex) checks every one for a superlative adjective rather than only the
// first, so an early false one can never mask a real match later in the
// same question.
function hasSingularNamedRecord(q) {
  for (const m of q.matchAll(SINGULAR_NAMED_RECORD_RE)) {
    if (!isSuperlativeWord(m[1])) return true;
  }
  return false;
}

/**
 * Round 15 follow-up (P0, generalization audit): "is Matthew Whitfield out of
 * warranty yet" / "is Abernathy still under warranty and who's the tech" both
 * returned the tenant-wide unit count ("You have 79 units (of 132 total).")
 * instead of declining or scoping to that one customer — this exact shape
 * ("is <bare name subject> {still} under/out of warranty") had no pattern
 * anywhere in this file at all: POSSESSIVE_SINGLE_RE only covers "does/did
 * NAME have/has/need", never a bare "is NAME ...". A named subject here is a
 * single customer's own warranty status, never a fleet-wide aggregate — the
 * same class of bug SINGULAR_NAMED_RECORD_RE/POSSESSIVE_SINGLE_RE already
 * exist to prevent, just a shape neither of them happened to cover. Guarded
 * the same way hasTrailingNameReference already is: the captured subject's
 * FIRST word must not be one of TRAILING_NAME_STOPWORD_RE's closed list (so
 * "is there still a warranty" / "is anyone still under warranty" — a real
 * existence/aggregate question, not a named subject — is never mistaken for
 * one), and the whole subject must not itself be one of this domain's own
 * nouns (TRAILING_NAME_DOMAIN_WORD_RE) so "is the maintenance agreement still
 * under warranty" (never a customer name) is excluded too.
 */
const NAMED_WARRANTY_SUBJECT_RE =
  /\bis\s+([a-zA-Z][a-zA-Z'.-]*(?:\s+[a-zA-Z][a-zA-Z'.-]*){0,3})\s+(?:still\s+|currently\s+)?(?:under|out\s+of)\s+warranty\b/i;

// "who is still under warranty" / "is anyone currently under warranty" — the
// optional still/currently token in NAMED_WARRANTY_SUBJECT_RE is meant to
// come AFTER a real name ("is Abernathy still under warranty"), but with no
// name there at all (the true subject is "who", already consumed before
// "is") the same optional slot can swallow "still"/"currently" itself as if
// it were the captured name. Excluded here rather than folded into the
// shared TRAILING_NAME_STOPWORD_RE list (used by unrelated shapes too) since
// this ambiguity is specific to this one pattern's own optional-adverb slot.
const WARRANTY_SUBJECT_ADVERB_RE = /^(?:still|currently|already|yet)$/i;

function hasNamedWarrantySubject(q) {
  const m = NAMED_WARRANTY_SUBJECT_RE.exec(q);
  if (!m) return false;
  const subject = m[1].trim();
  const firstWord = subject.split(/\s+/)[0];
  if (TRAILING_NAME_STOPWORD_RE.test(firstWord)) return false;
  if (WARRANTY_SUBJECT_ADVERB_RE.test(firstWord)) return false;
  return !TRAILING_NAME_DOMAIN_WORD_RE.test(subject);
}

/**
 * Round 15 follow-up (generalization audit, g109): "is there a customer
 * named ortega" answered "Yes, you have 120 customers." — a tenant-wide
 * aggregate — instead of resolving (or declining on) that ONE named
 * customer. Root cause: preClassifyAnalytics's own existence-shape widening
 * (isExistenceQuestion(q) && cr.aggregateNoun.test(q)) never checked for a
 * trailing "named <Name>" clause, which unambiguously names a single record
 * regardless of the "is there a/an <noun>" existence phrasing wrapped around
 * it — the same class of bug NAMED_WARRANTY_SUBJECT_RE/hasTrailingNameReference
 * already exist to catch, just a shape neither covers ("named" introduces
 * the name, not "for"/"at"/a bare "is <Name>"). Guarded the same way: the
 * captured name's first word must clear TRAILING_NAME_STOPWORD_RE (so "is
 * there a customer named after the street" - a hypothetical non-name "named"
 * use - stays excludable) and must not itself be a domain noun.
 */
const NAMED_RECORD_CLAUSE_RE =
  /\b(?:customer|client|account|business|company)\s+named\s+([a-zA-Z][a-zA-Z'.-]*(?:\s+[a-zA-Z][a-zA-Z'.-]*){0,3})\b/i;

function hasNamedRecordClause(q) {
  const m = NAMED_RECORD_CLAUSE_RE.exec(q);
  if (!m) return false;
  const subject = m[1].trim();
  if (TRAILING_NAME_STOPWORD_RE.test(subject.split(/\s+/)[0])) return false;
  return !TRAILING_NAME_DOMAIN_WORD_RE.test(subject);
}
/** An alnum token >= 8 chars with at least one digit — the same serial/model
 *  shape fastPath.js's own IDENTIFIER_RE looks for (see its file for why:
 *  that's the printed shape of a real HVAC serial/model number, and a bare
 *  4-digit year or short word never qualifies). Duplicated here rather than
 *  imported so this file has no dependency on fastPath.js's internals. */
const IDENTIFIER_TOKEN_RE = /\b[A-Za-z0-9][A-Za-z0-9-]{7,}\b/g;

function looksLikeIdentifierToken(question) {
  const tokens = String(question ?? '').match(IDENTIFIER_TOKEN_RE) ?? [];
  // a bare ISO date ("2026-09-21") has the identifier shape but is a date, never a serial
  return tokens.some((tok) => /\d/.test(tok) && !/^\d{4}-\d{2}-\d{2}$/.test(tok));
}

/** "for serial M100017" / "serial number Y100023" — a serial VALUE named
 *  right after the word "serial" is a single-record reference regardless of
 *  its own length (IDENTIFIER_TOKEN_RE's 8-char floor misses a short one like
 *  "M100017"'s 7 characters) — the word "serial" is itself the strong signal
 *  here, not the token shape. Excludes a bare "serial number(s)" with no
 *  value following (e.g. "what's the serial number of the unit at ...", "how
 *  many serial numbers do we have") so this never fires on a generic mention
 *  of the field name alone. */
const SERIAL_VALUE_RE = /\bserial\s*(?:number)?\s+(?!numbers?\b)[a-z0-9-]{3,}\b/i;

/** "at Thornton's" / "at Prentiss's" — a possessive name right after "at" is
 *  a single-record reference ("when were we last at Thornton's", "last 3
 *  visits at Prentiss's") the same way AT_ADDRESS_RE catches "at <number>
 *  <word>" — case-insensitive on purpose (see SINGULAR_NAMED_RECORD_RE's own
 *  doc comment for why case is not a reliable signal once sloppiness variants
 *  lowercase everything). */
const AT_POSSESSIVE_RE = /\bat\s+[a-z][a-z']*'s\b/i;

/** A small, fixed set of words that can never be the FIRST word of a real
 *  customer/company name — reused from contactLookup.js's own
 *  NAME_STOPWORD_RE list (kept as a separate, slightly larger copy here
 *  rather than an import, since this file must stay DB/model-free and
 *  contactLookup.js additionally touches `db`) plus the prepositions/
 *  quantifiers TRAILING_NAME_RE (below) actually needs to reject that
 *  contactLookup's own list never had to worry about ("in Mesa", "our Trane
 *  jobs", "last month's work"). */
// Round 15 (A): "is there a maintenance agreement on file for ANYONE" — an
// indefinite pronoun ("anyone"/"everyone"/"someone"/...), never a proper
// name, was missing from this list entirely (only the determiner "any" was
// covered) — TRAILING_NAME_RE's own "for/at <name>" shape wrongly read
// "anyone" as a trailing customer surname, making looksLikeSingleRecordReference
// (and so preClassifyAnalytics) misclassify a genuine aggregate/existence
// question as a single-record one.
const TRAILING_NAME_STOPWORD_RE =
  /^(?:the|a|an|this|that|these|those|our|their|his|her|my|your|its|which|who|what|how|does|do|did|is|are|list|show|has|have|in|on|at|of|for|with|without|and|or|no|not|any|anyone|anybody|everyone|everybody|someone|somebody|no one|nobody|all|last|next|first|second|third|most|many|few|several|day|days|today|week|weeks|month|months|year|years|end)$/i;

/** A captured "name" that is actually one of this domain's own nouns
 *  ("maintenance", "warranty", "service", "file", ...) is never a real
 *  customer name — guards the same trailing-preposition shape against a
 *  question like "which customers are overdue for maintenance" (a real
 *  aggregate ask, not "Maintenance" the customer). */
// "mainttenance" (a double-t typo this bank tests) needs its own alternative
// here rather than relying on nlNormalize.js's own fuzzy correction to fix it
// first: this check runs on the ORIGINAL, uncorrected text (see
// normalizeQuestion's own singleRecord guard, above), so a typo'd domain word
// that fails this match gets misread as a trailing NAME instead, which then
// blocks fuzzy correction for the whole question — a typo that stops its own
// fix from ever running.
const TRAILING_NAME_DOMAIN_WORD_RE =
  /\b(maintenance|mainttenance|warrant(?:y|ies)|service|services|tune-?up|checkup|agreement|agreements|invoice|invoices|quote|quotes|permit|permits|proposal|proposals|record|records|paperwork)\b/i;

/**
 * "List invoices for Fitzgerald" / "What was the last service ticket for
 * Bracken?" / "Show me all the invoices for Mercer" — a customer's SURNAME
 * (or short name) is the very last thing in the question, right after "for"/
 * "at", exactly the shape contactLookup.js's own CONNECTOR_NAME_RE
 * recognizes for a phone/email/address ask — this is the same shape for
 * every OTHER per-customer document/history question (invoices, tickets,
 * proposals, ...) that contactLookup.js has no field for and was never meant
 * to own. "of" is deliberately NOT one of the trigger prepositions here (it
 * is for contactLookup.js's own CONNECTOR_NAME_RE) — "of" introduces far more
 * generic English tails in this domain ("end of day", "breakdown of units")
 * than it ever introduces a trailing name. Capped at 1-2 words (a first+last
 * name at most) and anchored to the END of the string so a genuine aggregate
 * tail like "...on file for in Mesa" or "...owe us for last month's work"
 * (3+ words, or starting with a stopword) never matches — see
 * TRAILING_NAME_STOPWORD_RE/TRAILING_NAME_DOMAIN_WORD_RE above for the two
 * halves of that guard.
 */
// Round 15 follow-up (P0, generalization audit): "how many jobs have we done
// for copper sky dental" — a genuine 3-word BUSINESS name (this domain's
// customer_name field holds businesses as often as people) never matched at
// all with the old 1-2-word cap, since the captured group has to reach all
// the way to the end of the string: "for" was never immediately followed by
// the (too-short) captured phrase, so the whole regex missed, and the
// question fell through to the generic aggregate path with no name filter to
// give it — a confident tenant-wide wrong answer. Widened to up to 6 words
// (a full business name like "Valley View Auto Body Shop"); still guarded by
// the same TRAILING_NAME_STOPWORD_RE (first word) / TRAILING_NAME_DOMAIN_WORD_RE
// (whole phrase) checks below, so a genuine multi-word aggregate tail ("for
// our regular customers", "for the ac units") is still excluded the same way
// it always was — those guards check the CONTENT of the captured phrase, not
// its length.
const TRAILING_NAME_RE = /\b(?:for|at)\s+([a-zA-Z][a-zA-Z'.-]*(?:\s+[a-zA-Z][a-zA-Z'.-]*){0,5})\s*[?!.]*\s*$/;

// HVAC persona bank (2026-09-21): "List invoices for Fitzgerald so I can call
// them" / "...for Bracken for the file" / "...for Delgado, thanks" — a
// trailing-context sloppiness variant appends a pleasantry/purpose clause
// AFTER the real trailing name, which TRAILING_NAME_RE's own `$` anchor then
// never reaches (the name is no longer the last thing in the string) —
// wrongly falling through to a false-positive analytics classification
// instead ("list"+"invoices" alone satisfy QUANTIFIER+AGGREGATE_NOUN). The
// same closed, narrow chatter list contactLookup.js's own
// stripTrailingChatter already strips for exactly this reason — duplicated
// here rather than imported, same "this file must stay DB/model-free"
// reasoning TRAILING_NAME_STOPWORD_RE's own doc comment gives.
const TRAILING_CHATTER_RE =
  /,?\s*(?:so\s+i\s+can\s+[a-z]+(?:\s+[a-z]+){0,3}|for\s+the\s+(?:newsletter|file)|before\s+(?:end\s+of\s+day|eod)|thanks?|please)\s*$/i;

function stripTrailingChatterForNameCheck(q) {
  let out = q;
  for (let i = 0; i < 3; i++) {
    const next = out.replace(TRAILING_CHATTER_RE, "").trim();
    if (next === out) break;
    out = next;
  }
  return out;
}

function hasTrailingNameReference(q) {
  const m = TRAILING_NAME_RE.exec(stripTrailingChatterForNameCheck(q));
  if (!m) return false;
  const namePhrase = m[1].trim();
  if (TRAILING_NAME_STOPWORD_RE.test(namePhrase.split(/\s+/)[0])) return false;
  return !TRAILING_NAME_DOMAIN_WORD_RE.test(namePhrase);
}

/**
 * "Did we send Isaacson a quote?" / "What proposal did we give Amy Isaacson?"
 * — a named customer as the OBJECT of "did/do/does we give/send/quote",
 * rather than the subject POSSESSIVE_SINGLE_RE already excludes.
 *
 * HVAC persona bank (2026-09-21): this used to require the captured object
 * word to be capitalized, the same trade-off SINGULAR_NAMED_RECORD_RE's own
 * case-sensitive era made — safe against "How many quotes did we send this
 * quarter?" (a real aggregate; "this"/"quarter" are always lowercase) but it
 * also silently failed every lowercase/typo/voice-style sloppiness variant of
 * the SAME lookup question ("did we send isaacson a quote"). Replaced with an
 * explicit stopword/aggregate-noun rejection instead — the same fix
 * TRAILING_NAME_STOPWORD_RE/AGGREGATE_NOUN already give hasTrailingNameReference
 * — which keeps the "this quarter" guard without needing case at all.
 */
const WE_ACTION_OBJECT_RE = /\b(?:did|do|does)\s+we\s+(?:ever\s+)?(?:give|send|quote)\s+(?:an?\s+)?([A-Za-z][a-zA-Z]*)/i;

function hasNamedActionObject(q) {
  const m = WE_ACTION_OBJECT_RE.exec(q);
  if (!m) return false;
  const word = m[1].toLowerCase();
  if (TRAILING_NAME_STOPWORD_RE.test(word)) return false;
  if (AGGREGATE_NOUN.test(word)) return false;
  return true;
}

/** True when the question names one specific record (a street address, an
 *  "at <number> <word>" reference, a serial/model-shaped token, a "does/did
 *  NAME have" possessive, a "the NAME unit/job/..." reference, a trailing
 *  "for/of/at NAME", or a named object of "did we give/send/quote NAME") —
 *  rather than asking about many. Exported so routes/analytics.js and
 *  scripts/verify-analytics.mjs can both exercise it directly. */
// Reviewer NO-GO (2026-09-22): duplicated from contactLookup.js's own
// STREET_ONLY_RE (same "this file must stay DB/model-free" reasoning
// TRAILING_NAME_STOPWORD_RE's own doc comment already gives — contactLookup.js
// touches `db`, so importing it here would pull that dependency in). Anchored
// the same way: "how many customers on Greenfield Rd" starts with "how
// many", never with "the guy .../customers? on|at", so it never matches here
// either and stays a normal analytics count.
const STREET_ONLY_RE =
  /^(?:the\s+(?:guy|lady|customer|account|people|folks)\s+(?:on|at|over on)|customers?\s+(?:on|at))\s+[a-zA-Z][a-zA-Z']*(?:\s+[a-zA-Z][a-zA-Z']*){0,2}\b/i;
// Same leading-noise words contactLookup.js's own UH_FILLER_RE/
// LEADING_QUANTIFIER_RE strip before trying its shapes — a sloppiness
// variant can stack "uh"/"list"/"pull up" in front of "the guy on
// Greenfield Road" the same way it does everywhere else in this bank, and
// STREET_ONLY_RE above is anchored at `^` so it never sees past them
// otherwise.
const UH_FILLER_STRIP_RE = /^(?:uh+|um+)\s+/i;
const LEADING_QUANTIFIER_STRIP_RE = /^(?:show me|pull up|list|need the)\s+/i;

function stripLeadingNoiseForStreetCheck(q) {
  let out = q;
  for (let i = 0; i < 5; i++) {
    const next = out.replace(UH_FILLER_STRIP_RE, '').replace(LEADING_QUANTIFIER_STRIP_RE, '').trim();
    if (next === out) break;
    out = next;
  }
  return out;
}

export function looksLikeSingleRecordReference(question) {
  const q = String(question ?? '');
  return (
    STREET_ADDRESS_RE.test(q) ||
    AT_ADDRESS_RE.test(q) ||
    hasSingularNamedRecord(q) ||
    looksLikeIdentifierToken(q) ||
    SERIAL_VALUE_RE.test(q) ||
    AT_POSSESSIVE_RE.test(q) ||
    (POSSESSIVE_SINGLE_RE.test(q) && !COMPARISON_THAN_RE.test(q)) ||
    hasTrailingNameReference(q) ||
    hasNamedActionObject(q) ||
    hasNamedWarrantySubject(q) ||
    hasNamedRecordClause(q) ||
    STREET_ONLY_RE.test(stripLeadingNoiseForStreetCheck(q))
  );
}

/* ============================================================ learned overlay
 *
 * Tier 2 "Donovan learns nightly" (handoffs/DONOVAN_TRAINING_PLAN_2026-09-21.md),
 * Part A — see nlNormalize.js's own copy of this same pattern for the fuller
 * rationale. No shared mutable overlay lives in this file: every caller
 * passes its own overlay object explicitly, and a WeakMap keyed on that
 * object's identity is the only "cache" involved, so two overlays (the
 * process-wide active one vs. a single candidate proposal being verified)
 * can never leak into each other regardless of call order.
 */
function isOverlayEmpty(overlay) {
  if (!overlay) return true;
  return !(overlay.synonyms && Object.keys(overlay.synonyms).length);
}

function mergedEntitySynonyms(overlay) {
  const merged = {};
  for (const [entity, words] of Object.entries(ENTITY_SYNONYMS)) merged[entity] = [...words];
  if (overlay?.synonyms) {
    for (const [entity, words] of Object.entries(overlay.synonyms)) {
      if (!merged[entity] || !Array.isArray(words)) continue;
      merged[entity] = [...new Set([...merged[entity], ...words.map((w) => String(w ?? '').toLowerCase())])];
    }
  }
  return merged;
}

const overlayClassifierCache = new WeakMap();

/** Calls `fn(classifierRegexes)` — the base, module-level regex bag when
 *  `overlay` is empty/absent (byte-for-byte the pre-overlay behavior), or a
 *  freshly-merged one (cached per overlay OBJECT identity) otherwise.
 *  Exported for scripts/verify-learning.mjs's overlay-purity checks. */
export function withLearnedOverlay(overlay, fn) {
  if (isOverlayEmpty(overlay)) return fn(BASE_CLASSIFIER_REGEXES);
  let cr = overlayClassifierCache.get(overlay);
  if (!cr) {
    cr = buildClassifierRegexes(mergedEntitySynonyms(overlay));
    overlayClassifierCache.set(overlay, cr);
  }
  return fn(cr);
}

/**
 * Reviewer NO-GO (2026-09-21, round 4, item 1): the generic path used to
 * require QUANTIFIER && AGGREGATE_NOUN && CONTEXT, where CONTEXT was a
 * location/time/brand word (a county, "this month", "brand", ...). That
 * gate is why "how many clients do we have" — the live owner question —
 * fell through to retrieval: it names no location/time/brand at all, only
 * the aggregate noun and the quantifier. Checked against every existing
 * verify case (adversarial included), the ONLY negative that actually
 * depended on CONTEXT for its exclusion was "how many tons is the Whitmore
 * unit", now independently caught by SINGULAR_NAMED_RECORD_RE above — every
 * other single-record negative was already excluded up front by
 * looksLikeSingleRecordReference or POSSESSIVE_SINGLE_RE. So CONTEXT is no
 * longer a required gate: QUANTIFIER + AGGREGATE_NOUN alone is enough once
 * the exclusions above have already run. A true false positive here (a
 * genuinely ambiguous "which one do you like" that happens to also contain
 * an aggregate noun) still costs nothing but one wasted, cheap planner call
 * that validatePlan/the executor then reject — the same trade-off this
 * file's own header comment has always accepted.
 */
/**
 * `opts.overlay` (Tier 2 learning, Part A): an optional runtime-learned
 * `{ synonyms: { <entity>: [words] } }` bag that widens the entity-noun
 * regexes above for this call only (see withLearnedOverlay below) — omitted,
 * null, or empty, this is byte-for-byte the same function as before overlays
 * existed. Every OTHER regex used here (WHO_HAS_RE, GEO_WORD_RE, BRAND_RE,
 * ...) is not synonym-driven and stays exactly as-is regardless of overlay.
 */
const AGREEMENT_END_ADMIT_RE = /\b(?:agreements?|contracts?)\b(?=[\s\S]*\b(?:expir\w*|ends?|ending|renew\w*|(?:run|runs|running|good|valid|active|effective|in\s+effect)\s+(?:through|thru|until|till|to))\b)(?=[\s\S]*\b(?:19|20|21)\d{2}\b)/i;

const BP_MON = "(?:january|february|march|april|may|june|july|august|september|october|november|december)";
const BP_PERIOD = `(?:(?:first|second|third|fourth|1st|2nd|3rd|4th)\\s+(?:half|quarter)\\s+(?:of\\s+)?|q[1-4]\\s+(?:of\\s+)?|${BP_MON}\\s+(?:(?:through|to|thru)\\s+${BP_MON}\\s+)?)?(?:19|20)\\d{2}`;
const BARE_NOUN_PERIOD_RE = new RegExp(`^(?:the\\s+)?(?:total\\s+)?(?:number\\s+of\\s+)?((?:[a-z]+\\s+){0,2}[a-z]+)\\s+(?:in|during|from|for|dated|between|issued|logged|written|created)\\s+(?:the\\s+)?(?:from\\s+)?${BP_PERIOD}(?:\\s+(?:to|through|thru|and)\\s+${BP_PERIOD})?$`, "i");
/** The counted noun phrase of a bare "<kind of paper> in <period>" question (nothing else in the sentence), or null. */
function bareNounPeriodNoun(q, cr) {
  const m = BARE_NOUN_PERIOD_RE.exec(String(q).trim().replace(/[?.!]+$/, ""));
  if (!m) return null;
  // only kinds of paper that carry a date the window can be read from (a service date, an invoice or quote date): an undated kind is the date lane's honest "not dated" answer, not a count of zero
  return m[1] && /^(?:(?:service|repair|pm|maintenance)\s+)?(?:tickets?|calls?|visits?|jobs?)$|^(?:invoices?|quotes?|proposals?|estimates?|bills?)$/i.test(m[1].trim()) && cr.aggregateNoun.test(m[1]) ? m[1] : null;
}
export function preClassifyAnalytics(question, opts = {}) {
  const overlay = opts?.overlay;
  const q = String(question ?? '').trim();
  if (!q) return false;
  // looksLikeSingleRecordReference now also covers POSSESSIVE_SINGLE_RE's own
  // "does/did NAME have" shape (see that function's own doc comment) — no
  // separate check needed here any more.
  if (looksLikeSingleRecordReference(q)) return false;
  return withLearnedOverlay(overlay, (cr) => {
    if (
      WHO_SERVICED_RE.test(q) ||
      WHICH_CUSTOMERS_RE.test(q) ||
      cr.customersWhose.test(q) ||
      cr.groupShape.test(q) ||
      WHO_HAS_RE.test(q) ||
      NOUN_WITH_RE.test(q) ||
      cr.biggestCustomer.test(q) ||
      BUSIEST_RE.test(q) ||
      cr.whatPlural.test(q) ||
      cr.whatDidWe.test(q) ||
      THE_MOST_RE.test(q) ||
      WHO_DUE_RE.test(q) ||
      WHO_WARRANTY_RE.test(q) ||
      // "clients out of warranty" / "customers under warranty" — a bare noun + warranty-status
      // phrase with no quantifier word (QUANTIFIER below requires "how many"/"which"/etc).
      // B3: a bare "<kind of paper> in <period>" ("service tickets in the second half of 2025", "invoices dated in 2019"): no question word, but a counted noun plus a window is a count
      (bareNounPeriodNoun(q, cr) != null && Boolean(resolveAnyTimeRange(q, new Date().toISOString().slice(0, 10)))) ||
      (cr.aggregateNoun.test(q) && WARRANTY_STATUS_WORD_RE.test(q)) ||
      (cr.aggregateNoun.test(q) && AGE_FILTER_RE.test(q)) ||
      (cr.aggregateNoun.test(q) && SUPERLATIVE_RE.test(q)) ||
      (cr.aggregateNoun.test(q) && CONTACT_FILTER_RE.test(q)) ||
      (cr.aggregateNoun.test(q) && FOLLOWUP_NARROW_RE.test(q)) ||
      // BRAND_RE deliberately excluded from this bare, no-quantifier combo —
      // unlike a city/zip (GEO_WORD_RE/ZIP_*, which only ever names a LOCATION,
      // never a single unit's own attribute), a brand name shows up just as
      // often inside a genuine single-record attribute question ("what is the
      // serial number on the Trane condenser") as it does in a real aggregate
      // one, and every real brand-aggregate case already reaches analytics via
      // QUANTIFIER+AGGREGATE_NOUN ("how many Trane units...") or WE_YES_NO_RE
      // ("do we have any Daikin customers...") below, both of which pair the
      // brand with an explicit count/existence question word first.
      (cr.aggregateNoun.test(q) && (GEO_WORD_RE.test(q) || ZIP_CODE_WORD_RE.test(q) || ZIP_VALUE_RE.test(q))) ||
      (WE_YES_NO_RE.test(q) && (cr.weYesNoNoun.test(q) || BRAND_RE.test(q) || GEO_WORD_RE.test(q) || ZIP_CODE_WORD_RE.test(q))) ||
      (QUANTIFIER.test(q) && COVERAGE_NOUN_RE.test(q)) ||
      (/\bwhat\b/i.test(q) && COVERAGE_NOUN_RE.test(q) && /\bdo we\b/i.test(q)) ||
      // Round 15 (A): "is there a maintenance agreement on file for anyone",
      // "are there documents missing a customer", "did we do any service
      // calls last month" — WE_YES_NO_RE above only ever covers "do/does/have/
      // has we"; isExistenceQuestion (below, hoisted) is the broader
      // "do/does/is/are/did/have/has we/there/you/our shop" existence shape
      // R7's own existenceWrap already answers correctly once a plan reaches
      // it — paired with a real aggregate noun so a genuinely single-record
      // "is there a warranty on the Whitmore unit" still falls to
      // looksLikeSingleRecordReference's own exclusion above, never here.
      (isExistenceQuestion(q) && cr.aggregateNoun.test(q)) ||
      // R20 (J3): "is Daikin more common than Goodman in our records" / "did we install more
      // units last year than this year" — a genuine yes/no COMPARISON_THAN_RE shape (see its
      // own doc comment) names no aggregate noun at all when the compared values ARE the nouns
      // (two brand names, two years) — admitted directly rather than requiring cr.aggregateNoun,
      // same as isExistenceQuestion's own bare "is there a maintenance agreement" branch above.
      // detectCountComparison (routes/analytics.js) still bails to null (never guesses) if the
      // two compared values don't resolve to a real brand/city/year pair.
      (COMPARISON_YESNO_LEAD_RE.test(q) && COMPARISON_THAN_RE.test(q)) ||
      // R21 M2 (deferred list, i095, "do most of our warranty registrations happen within 30 days
      // of the install"): a majority-comparison shape with no "than" at all (see
      // analytics/comparison.js's detectWarrantyRegDaysMajority, whose own regex this mirrors) — the
      // COMPARISON_THAN_RE admission just above only ever covers an explicit "X than Y" comparison,
      // so this needs its own admission line the same way the warranty-registered-vs-unregistered
      // "than" comparison above it did before COMPARISON_THAN_RE existed.
      WARRANTY_REG_DAYS_MAJORITY_ADMIT_RE.test(q) ||
      // D4: "maintenance agreements ending in 2028", "any contracts that expire in 2027" - an agreement noun + an END cue + a year names the
      // agreement END year (detPlan.js's detectAgreementEndYear) even with no "how many"/"which" quantifier.
      AGREEMENT_END_ADMIT_RE.test(q)
    ) {
      return true;
    }
    return QUANTIFIER.test(q) && cr.aggregateNoun.test(q);
  });
}

/**
 * Reviewer NO-GO (2026-09-21, A1b): defense-in-depth for the executor. Even
 * if the classifier above somehow lets a single-record question through (a
 * phrasing neither STREET_ADDRESS_RE nor an identifier token catches), an
 * unfiltered `list`/`count` plan over `customers` for a question that names
 * ANY number of 2+ digits (a street number, a ZIP, a customer number typo,
 * a serial fragment) is treated as a sign the question was actually about
 * something specific this plan lost — not a real "how many customers do we
 * have" question, which never contains a number at all. Pure, so this is
 * checked before the executor ever runs a query — see runAnalyticsQuestion
 * in routes/analytics.js.
 */
const TWO_OR_MORE_DIGITS_RE = /\d{2,}/;

export function suspiciousUnfilteredCustomerPlan(plan, question) {
  if (!plan || plan.entity !== 'customers') return false;
  if (plan.op !== 'list' && plan.op !== 'count') return false;
  if (Array.isArray(plan.filters) && plan.filters.length > 0) return false;
  return TWO_OR_MORE_DIGITS_RE.test(String(question ?? ''));
}

/* ============================================================ honest fallback
 *
 * Reviewer NO-GO (2026-09-21, round 5, item 3): a plan that silently DROPS a
 * condition the question actually named (the model has no filter for it, or
 * just forgot) still executes as an unfiltered query and answers confidently
 * — exactly item 2's original bug shape ("how many customers have an email
 * on file" -> the plain customer count), which the hasEmail/hasPhone filters
 * fixed for THAT one phrasing but not for the general case (a brand, a
 * county, a month the model dropped for some other reason). detectedConditions
 * is deliberately dumb and self-contained (word/known-name matching, nothing
 * from the classifier's own regexes) — a false positive here just means an
 * honest "can't filter by X yet" where a fuller plan would have worked, never
 * a wrong answer; see missingConditions/unsupportedConditionAnswer below for
 * how routes/analytics.js's runAnalyticsQuestion uses this.
 */
const CONTACT_WORD_RE = { email: /\bemail\b/i, phone: /\bphone\b/i };

/**
 * Live miss cluster 2 (2026-09-21 270-question sample): "What's the total
 * dollar amount of our open invoices?" / "how much did we invoice last
 * month" and friends returned a fabricated "$0.00 across N documents." —
 * there is no financials layer yet (handoffs/FINANCIALS_DESIGN_2026-09-21.md,
 * not built), so the `sum` op silently summed a non-numeric column (a
 * filename, a document id) down to 0 and printed it as though it were a real
 * total. Any question this matches must get the honest fallback below
 * instead of ever reaching the planner/executor — see api/ask.js's money
 * gate (checked BEFORE the Haiku planner call, so a money question never
 * spends a model call at all) and executeAnalyticsPlan's own sum-op guard
 * (routes/analytics.js) for the second line of defense. Deliberately broad
 * (a false positive here just means an honest "can't do that yet" where a
 * real analytics answer might have worked, never a wrong dollar figure).
 */
// Stemmed rather than a fixed "invoice"/"invoiced" pair — reviewer NO-GO
// (2026-09-21): "total invoiced this year" missed because the outer \b
// forced a word-boundary right after literal "invoice", which "invoiced"
// (word char 'd' next) never has. INVOICE_STEM covers invoice/invoiced/
// invoices/invoicing wherever this regex used to spell out only one form.
const INVOICE_STEM = 'invoic(?:e|ed|es|ing)';
// HVAC persona bank (2026-09-21) added three more real bookkeeper phrasings
// MONEY_RE was still missing:
//   - "total amount we've invoiced" — "total" and the invoice stem are both
//     present but in the OPPOSITE order/adjacency the two existing
//     "invoice-word total" patterns above require ("invoiced total"/"total
//     invoiced"); a bare "total amount" is just as much a money phrase on its
//     own in this domain and needs no invoice word next to it at all.
//   - "average ticket/invoice size/amount" — "what's our average ticket
//     size", "what's the average invoice amount for our Trane jobs".
//   - "what did we bill <customer>" — bare "bill" (not just "billed") as its
//     own verb, the same INVOICE_STEM-style gap "invoiced" once was.
// Live 100-question persona sample (2026-09-22): "total we've collected in
// maintenance agreement fees" / "what fees have we collected" / "have
// customers paid us" / "outstanding receivables" / "what's outstanding" all
// missed MONEY_RE — "collected"/"fees"/"paid us"/"receivables"/"outstanding"
// (bare, not just "outstanding balance") are just as much a no-financials-
// layer-yet money question as "billed"/"invoiced" already are.
const MONEY_RE = new RegExp(
  '\\b(revenue|' + INVOICE_STEM + '\\s+(?:total|amount)|' +
    'total\\s+(?:' + INVOICE_STEM + '|billed|dollar|amount|collected)|' +
    'average\\s+(?:ticket|' + INVOICE_STEM + ')\\s+(?:size|amount)|' +
    'how much (?:did we|have we|do we)\\s+(?:bill|' + INVOICE_STEM + '|charge|make|earn|spend|collect)|' +
    'what did we bill|' +
    'dollar amount|\\$\\s?\\d|\\bbill(?:ed)?\\b|owed|outstanding(?:\\s+balance)?|unpaid invoices?|by revenue|by sales|' +
    'spend(?:ing)?|collected|\\bfees?\\b|paid us|receivables?)\\b',
  'i'
);

export function isMoneyQuestion(question) {
  return MONEY_RE.test(String(question ?? ''));
}

/** The one honest answer every money question gets until the financials
 *  layer ships — no facts (there is no real number to show), not cached, no
 *  model call. Text is fixed on purpose so every money phrasing reads
 *  identically rather than each falling back through a different path with
 *  its own wording. */
export const MONEY_FALLBACK_TEXT =
  "I can't total invoice amounts yet — that's coming with the Financials update. I can count invoices and find a specific one if that helps.";

export function moneyFallbackAnswer() {
  return {
    kind: 'answer', text: MONEY_FALLBACK_TEXT,
    facts: [], sources: [], confidence: 1, verifiedCount: 0, unverifiedCount: 0, closest: [],
  };
}

/**
 * R21 M2 (Cluster 6, j192 "do we have an invoice dated January 1st, 2030" / j195 "how many jobs do
 * we have logged for 2030"): a question naming a YEAR strictly after `today`'s own year has nothing
 * on file it could possibly match — every record in this corpus is dated on or before today (see
 * splitFuture, scope.js), so a genuine future year is never a "0 results, computed" answer, it's an
 * out-of-range question with no real data to search. Two real bugs this fixes, both root-caused to
 * the SAME "a future date was never handled as its own case" gap:
 *   - MONTH_NAME_RE (this file, above) captures a year only immediately after the month name
 *     ("August 2024"); "January 1st, 2030" has a day-ordinal in between, so the year silently never
 *     captured at all and the question fell back to a bare "January" in the CURRENT year — a
 *     confidently wrong non-zero answer for a date that was never asked about.
 *   - a bare "for 2030"/"in 2030" with no month name at all matches no time-window regex anywhere in
 *     this file, so the question fell through with NO time filter whatsoever and silently answered
 *     with the WHOLE unfiltered corpus total.
 * Checked up front in routes/analytics.js's runAnalyticsQuestion, before any plan/cache — same
 * "decide before the model ever gets a guess" idiom as money/maintenance — and answers with a
 * genuine decline (no facts, no computed "0" attached to anything) so honest-zero grading (a real
 * zero that still carries a facts entry fails it — see compareHonestZero) can never be tripped up by
 * this looking like a normal, successfully-computed empty result.
 */
const FUTURE_YEAR_TOKEN_RE = /\b(19\d{2}|20\d{2}|21\d{2})\b/g;
// R34: a FORWARD-LOOKING record field is legitimately dated in the future - "which warranties expire in 2027" is answerable from the
// warranty end dates on file, not "a future date, nothing on file". Only a question about a past EVENT (filed/issued/logged/did) in a future
// year is declined here.
const FORWARD_RECORD_FIELD_RE_MAIN = /\b(?:expir\w*|renew\w*|ends?|ending|due|schedul\w*|upcoming|coverage|covered|valid\s+(?:through|until)|good\s+(?:through|until)|runs?\s+(?:through|thru|until|till|to)|agreements?|contracts?|terms?)\b/i;
// D4: "run(s) through 2027", "good/valid/active/effective through 2028", and a contract/warranty/plan noun followed by through/until ("agreements through 2031")
// name the END of a term the same way "expire" does.
const FORWARD_RECORD_FIELD_RE = new RegExp(
  '\\b(?:expir\\w*|renew\\w*|ends?|ending|due|schedul\\w*|upcoming|coverage|covered|valid\\s+(?:through|until)|good\\s+(?:through|until))\\b'
  + '|\\b(?:run|runs|running|ran|good|valid|active|effective|in\\s+effect|current|lasts?|lasting)\\s+(?:through|thru|until|till|to)\\b'
  + '|\\b(?:agreements?|contracts?|warrant(?:y|ies))\\b[^.?]{0,40}\\b(?:through|thru|until|till)\\b'
  // D4: "agreements still active in 2027" / "contracts that run past 2026" are end-of-term questions too.
  + '|\\b(?:agreements?|contracts?|memberships?)\\b[^.?]{0,40}\\b(?:(?:still\\s+)?(?:active|valid|in\\s+force|in\\s+effect)\\s+(?:in|during|at|by)|(?:run|runs|running|extend\\w*|go|goes|going)\\s+(?:past|beyond))\\b',
  'i'
);
export function mentionsFutureYear(question, today) {
  const q = String(question ?? '');
  if (FORWARD_RECORD_FIELD_RE.test(q) || FORWARD_RECORD_FIELD_RE_MAIN.test(q)) return false;
  const now = today ? new Date(today) : new Date();
  if (Number.isNaN(now.getTime())) return false;
  const currentYear = now.getUTCFullYear();
  for (const m of q.matchAll(FUTURE_YEAR_TOKEN_RE)) {
    if (Number(m[1]) > currentYear) return true;
  }
  return false;
}

export const FUTURE_DATE_TEXT =
  "That's a future date — I have nothing on file for it (every record here is dated on or before today).";
export function futureDateAnswer() {
  return {
    kind: 'answer', text: FUTURE_DATE_TEXT,
    facts: [], sources: [], confidence: 1, verifiedCount: 0, unverifiedCount: 0, closest: [],
  };
}

/**
 * Live miss cluster 3 (2026-09-21 270-question sample): "Which customers are
 * overdue for maintenance?" / "List customers due for a tune-up" matched the
 * classifier (WHICH_CUSTOMERS_RE / QUANTIFIER+AGGREGATE_NOUN) but named a
 * condition — "no service since" — that has no filter field anywhere in the
 * closed vocabulary (FILTER_FIELDS, analytics.js), so the model's plan came
 * back with zero filters and executed as a confident, unfiltered "49
 * customers." "Which customers have not had service in 12 months?" reads the
 * same way but happened to already fall through to retrieval honestly,
 * purely as a side effect of naming a 2+ digit number ("12") that trips
 * suspiciousUnfilteredCustomerPlan (below) — a coincidence, not a real fix.
 * This condition makes every phrasing of the same question honest the same
 * way: CONDITION_PLAN_FIELD has no entry for 'maintenance' (there is no such
 * plan field to ever satisfy it), so missingConditions() below always finds
 * it missing and runAnalyticsQuestion (routes/analytics.js) always returns
 * unsupportedConditionAnswer('maintenance', ...) instead of executing an
 * unfiltered query.
 */
// HVAC persona bank (2026-09-21): "Who's due for fall maintenance?" — a
// seasonal qualifier (fall/spring/annual/seasonal) between "due for" and the
// maintenance/tune-up word itself, which the original pattern's fixed
// "due for (?:a )" gap never allowed for.
const MAINTENANCE_DUE_RE =
  /\b(overdue for (?:a )?(?:maintenance|service)|due for (?:a )?(?:fall |spring |annual |seasonal )?(?:tune-?up|maintenance|service|checkup)|haven'?t been serviced|not had service|no (?:maintenance|service) in \d+\s*months?|needs?\s+(?:a )?service)\b/i;

/**
 * R18 P4 (C2, multi-hop AND-drop; C4, negation collapse): "needed a repair visit"/"have had a
 * repair call"/"a preventive maintenance visit"/"only preventive maintenance, never a repair" — a
 * mention of a real extractions.field_key='service_type' VALUE (see SERVICE_TYPE_FILTER_FIELDS'
 * own doc comment), distinct from MAINTENANCE_DUE_RE just above (which is about a customer being
 * OVERDUE — a scheduling concern with no filter field at all — never about whether a past visit of
 * a given type already happened, which this IS a real, answerable filter for). Longest/most
 * specific phrase first so "preventive maintenance visit" is read as one phrase, not "maintenance"
 * (MAINTENANCE_DUE_RE's own word) plus a stray "visit".
 */
// R21 M2 (Cluster 1, C1, j022/j028/j031/j034 "had/got a maintenance tune-up"): a THIRD phrasing for
// the same Preventive Maintenance value, distinct from MAINTENANCE_DUE_RE's own "due for a
// tune-up" (a scheduling/overdue concern, no filter field at all — see that regex's own doc
// comment) by context: "had/got/needed a maintenance tune-up" names a visit that already
// HAPPENED, the same past-tense shape "a repair"/"a repair call" already name below.
export const SERVICE_TYPE_PHRASE_RE =
  /\b(preventive maintenance visits?|preventive maintenance|maintenance tune-?ups?|repair visits?|repair calls?|repair jobs?|a repair)\b/i;

/** The canonical SERVICE_TYPE_VALUES member a single SERVICE_TYPE_PHRASE_RE match names. */
export function serviceTypeValueOf(phrase) {
  return /^preventive maintenance|^maintenance tune-?up/i.test(phrase) ? 'Preventive Maintenance' : 'Repair';
}

/** A dumb, self-contained scan of the question TEXT for a handful of
 *  conditions a plan might drop: 'email'/'phone' (the hasEmail/hasPhone
 *  shape), 'brand' (a known manufacturer name), 'county' (the word "county"
 *  or a known AZ county name), 'month' (anything resolveQuestionTimeRange
 *  recognizes), 'money' (a dollar-total question with no financials layer to
 *  back it — see MONEY_RE), 'maintenance' (a "no service since" question with
 *  no such filter field — see MAINTENANCE_DUE_RE). Returns a Set; order is
 *  insertion order so a caller picking "the" missing condition when several
 *  are detected gets a stable, deterministic choice. */
export function detectedConditions(question) {
  const q = String(question ?? '').toLowerCase();
  const found = new Set();
  if (CONTACT_WORD_RE.email.test(q)) found.add('email');
  if (CONTACT_WORD_RE.phone.test(q)) found.add('phone');
  if (BRAND_WORDS.some((b) => new RegExp(`\\b${b}\\b`).test(q))) found.add('brand');
  if (/\bcounty\b/.test(q) || KNOWN_COUNTY_NAMES.some((c) => new RegExp(`\\b${c}\\b`).test(q))) found.add('county');
  // city/state/zip (item 4, 2026-09-22): the same "a known geo word is
  // present" signal GEO_WORD_RE/ZIP_VALUE_RE already use for classification,
  // reused here so missingConditions can flag a plan that dropped one.
  if ([...KNOWN_AZ_CITY_NAMES, ...KNOWN_US_CITY_NAMES].some((c) => new RegExp(`\\b${escapeRegExp(c)}\\b`).test(q))) {
    found.add('city');
  }
  if (/\barizona\b|\bnevada\b|\baz\b|\bnv\b/.test(q)) found.add('state');
  if (ZIP_VALUE_RE.test(q) || ZIP_CODE_WORD_RE.test(q)) found.add('zip');
  if (/\bthis month\b|\blast month\b/.test(q) || resolveAnyTimeRange(question) != null) found.add('month');
  if (MONEY_RE.test(q)) found.add('money');
  if (MAINTENANCE_DUE_RE.test(q)) found.add('maintenance');
  if (/\bwarrant/.test(q) && WARRANTY_STATUS_WORD_RE.test(q)) found.add('warranty');
  // Checked BEFORE CROSS_VISIT_RELATION_RE below: a bare "callback(s)" with no "within N days of"
  // qualifier is the untracked-concept shape (see CONDITION_UNTRACKED_CALLBACK's own doc comment),
  // not the computable cross-visit-relation one — both regexes would otherwise match the same text.
  if (UNTRACKED_CALLBACK_RE.test(q) && !CALLBACK_TIME_WINDOW_RE.test(q)) found.add(CONDITION_UNTRACKED_CALLBACK);
  // R21 M2 (deferred list, i093 "how many warranty registrations went in within 30 days of the
  // install date"): "within N days of" is CROSS_VISIT_RELATION_RE's own trigger phrase (it exists
  // to catch a join BETWEEN TWO ROWS, e.g. two separate service visits) — but "warranty
  // registration(s) ... within N days of the install(ation) (date)" compares two dates on the
  // SAME equipment row (registrationOnFile vs its own installDate), which is exactly what the
  // deterministic warrantyRegistrationDays field/detector (detPlan.js's
  // WARRANTY_REG_DAYS_WITHIN_RE) already computes — never an unresolvable cross-row relation.
  // Guarded the same way CALLBACK_TIME_WINDOW_RE guards the untracked-callback condition just
  // above: checked first so the generic phrase never shadows a real, answerable shape.
  const WARRANTY_REG_WITHIN_INSTALL_RE = /\bwarranty\s+registrations?\b[\s\S]{0,25}\bwithin\s+\d+\s*days?\s+of\s+(?:the\s+)?install/i;
  if (CROSS_VISIT_RELATION_RE.test(q) && !WARRANTY_REG_WITHIN_INSTALL_RE.test(q)) found.add(CONDITION_CROSS_VISIT_RELATION);
  if (RATIO_RE.test(q)) found.add(CONDITION_RATIO);
  // R18 P4 (C2, multi-hop AND-drop): "needed a repair visit"/"have had a repair call"/"only
  // preventive maintenance, never a repair" — see SERVICE_TYPE_FILTER_FIELDS' own doc comment.
  // Detected here (independent of detPlan.js's own dedicated detector) so a MODEL plan that drops
  // this condition is caught by the exact same missing-condition safety net every other condition
  // already gets, never just the deterministic planner's own path.
  if (SERVICE_TYPE_PHRASE_RE.test(q)) found.add('serviceType');
  return found;
}

/**
 * R7 guardrail (R7_MEASURE.md item 1): "How many Trane units had a repeat visit within 90 days of
 * installation?" and "Which customers had a callback within 14 days of a previous service visit?" (and every
 * "within N days of <event>" / "two different technicians ... within N days of each other" phrasing) name a
 * CROSS-ROW relationship between two dated records — a join no flat entity/op/groupBy/filter plan can ever
 * express. The fast/analytics plan silently dropped the relationship and answered a plain brand/entity count
 * instead (the exact bug this guard exists to catch) — "a repeat visit within 90 days of installation" became
 * "the Trane count", "a callback within 30 days" became "how many jobs this technician ran". Deliberately no
 * CONDITION_PLAN_FIELD entry (below), same idiom as 'money'/'maintenance': a plan can never satisfy this
 * condition, so missingConditions() always flags it and the caller falls through to the agent instead of ever
 * answering it here (see routes/analytics.js's own up-front check, checked before the plan/cache like
 * money/maintenance, and its own doc comment for why the agent gets first crack rather than a canned decline).
 */
const CROSS_VISIT_RELATION_RE = /\b(repeat\s+visits?|callbacks?|within\s+\d+\s*days?\s+of)\b/i;
export const CONDITION_CROSS_VISIT_RELATION = 'a repeat-visit or callback time window';

/**
 * R21 M2 (Cluster deferred list, h106 "which trane customers had a callback" / i006 "which tech
 * has the most callbacks"): a BARE "callback(s)" mention with no "within N days of ..." time-window
 * qualifier at all names "callback" as a TRACKED EVENT/CONCEPT ("did this customer have one",
 * "which tech has the most") — never recorded anywhere in this schema (no field_key for it exists;
 * the generator's own oracle counts extractions.field_key IN ('callback','callback_reason',
 * 'return_visit_reason'), which this corpus never populates). Distinct from
 * CONDITION_CROSS_VISIT_RELATION just above, whose whole reason for existing is the OPPOSITE case —
 * "callback ... within N days of a previous visit" IS a computable join a real agent could resolve
 * from the service-visit dates already on file, so that shape still gets its one agent shot
 * (routes/analytics.js's own doc comment on why). This one never does: there is no path to a real
 * answer, ever, so it declines immediately, the same up-front, no-model-call way 'money'/
 * 'maintenance' already do (routes/analytics.js).
 */
const UNTRACKED_CALLBACK_RE = /\bcallbacks?\b/i;
const CALLBACK_TIME_WINDOW_RE = /\bwithin\s+\d+\s*days?\s+of\b/i;
export const CONDITION_UNTRACKED_CALLBACK = 'callback';

/** "What percentage/ratio/proportion of..." — same idiom: no plan field can ever compute a ratio, so this is
 *  always an honest fall-through to the agent rather than a count that quietly answers a different question. */
const RATIO_RE = /\b(percent(?:age)?|\bratio\b|\bproportion\b)\b/i;
export const CONDITION_RATIO = 'a ratio or percentage';

/** "active warranties" / "still under warranty" / "expired" / "out of
 *  warranty" / "expiring soon" — a warranty-status condition the plan must
 *  carry as a warrantyStatus filter. Live miss 2026-09-22 ("how many active
 *  warranties do we have"): the model dropped the status and the count came
 *  back as every unit, so this is decided in code like email/brand/geo. */
const WARRANTY_STATUS_WORD_RE =
  /\b(?:active|current|valid|still (?:under|covered|in) warranty|under warranty|in warranty|covered|expired|out of warranty|no longer (?:under|covered)|lapsed|expiring|expires? soon|about to expire|running out|unknown warranty|warranty (?:status )?unknown|past (?:its|their|the) ?warranty|past warranty)\b/i;

// R20 (coordinator follow-up, 2026-09-27): "past their warranty" / "past its warranty" / "past the
// warranty" / bare "past warranty" is the same 'expired' bucket as "out of warranty"/"no longer
// covered" (d005: "how many of those are past their warranty?"). The coarse WARRANTY_STATUS_WORD_RE
// alt above is deliberately loose (it only gates "does this question mention a warranty-status
// phrase at all", same as every other alt in that regex) — this dedicated regex is the precise one
// that actually decides the 'expired' bucket, and it must NOT fire when "warranty" is the head of a
// different noun phrase entirely ("past warranty claims" = old CLAIMS, not an expired unit; "past
// the warranty registration deadline" = a DEADLINE, not a status). The negative lookahead rules out
// that closed set of nouns; it never guesses on anything else "past ... warranty" doesn't fit.
const PAST_WARRANTY_RE =
  /\bpast\s+(?:its|their|the)?\s*warrant(?:y|ies)\b(?!\s+(?:claims?|registrations?|paperwork|applications?|deadlines?|periods?|docs?|documents?))/i;

// Reviewer NO-GO (2026-09-26, round 14): "units that are NOT expired" / "not
// active" / "which units aren't under warranty" / "not out of warranty" all
// matched their bucket's own positive substring exactly as the positive
// phrasing would (a bare "expired"/"active"/"under warranty" test has no
// idea a "not"/"isn't"/"aren't" sits right in front of it) and returned that
// SAME bucket — the exact opposite status, confidently. A negation
// directly in front of the matched phrase (never a wide word-window, so an
// unrelated negation elsewhere in the sentence can't flip this) means this
// specific bucket was RULED OUT, not asked for — and which of the other two
// buckets was actually meant is genuinely ambiguous ("not expired" could be
// active OR expiring OR unknown), so this returns null (never guesses)
// rather than picking one.
const STATUS_NEGATED_BEFORE_RE = /\b(?:not|isn'?t|aren'?t|wasn'?t|weren'?t|doesn'?t|don'?t)\b(?:\s+\S+){0,2}\s*$/i;
function statusNegatedAt(q, idx) {
  return STATUS_NEGATED_BEFORE_RE.test(q.slice(0, idx));
}

/** True when the question names one of warrantyStatusFromQuestion's own status phrases but with a
 *  negation directly in front of it — the "genuinely ambiguous, never guess" case that function itself
 *  already returns null for. A caller (detPlan.js's impliedWarrantyStatus) that would otherwise silently
 *  build an UNFILTERED plan when this function returns null (mistaking "negated" for "no warranty
 *  condition mentioned at all") needs this to tell the two apart and bail on the whole plan instead — see
 *  that call site's own doc comment. */
export function hasAmbiguousWarrantyStatusNegation(question) {
  const q = String(question ?? '').toLowerCase();
  if (!/\bwarrant/.test(q)) return false;
  const REGEXES = [
    /\be[xp]{2}ir(?:ing|es? soon)\b|\babout to expire\b|\brunning out\b/,
    /\bexpired\b|\bout of warranty\b|\bno longer\b|\blapsed\b/,
    /\bactive\b|\bcurrent\b|\bvalid\b|\bstill\b|\bunder warranty\b|\bin warranty\b|\bcovered\b|\bwarrantied\b|\bin-warranty\b/,
    PAST_WARRANTY_RE,
  ];
  // R34: phrasings that ARE the negation (not a status word preceded by one) and do not say whether the warranty lapsed or was never on
  // file ("units with no warranty", "units that don't have a warranty") - never guessed.
  const SELF_NEGATED = [
    /\b(?:(?:with|have|has|had)\s+no|without(?:\s+(?:a|any))?)\s+warrant(?:y|ies)\s*[?.!]*$/,
    /\b(?:don'?t|doesn'?t|do\s+not|does\s+not)\s+(?:still\s+)?have\s+(?:a\s+|any\s+)?warrant(?:y|ies)\b(?!\s+(?:registration|paperwork|info|information|date|on\s+file|anymore|any\s+more|any\s+longer|now))/,
  ];
  if (SELF_NEGATED.some((re) => re.test(q))) return true;
  return REGEXES.some((re) => {
    const m = re.exec(q);
    return m ? statusNegatedAt(q, m.index) : false;
  });
}

/**
 * R35 (owner decision 2026-10-01) SUPERSEDES the note below: these phrases now return 'covered' (not expired), and
 * counts-warranty-0004-canonical's oracle was rewritten to that reading (ADJUDICATION.md "R35").
 * R18 P4 (C2/C3, blind generalization round 18 part 2): tried folding "still"/"under
 * warranty"/"in warranty"/"covered" into a coarser 'not_expired' bucket (active OR
 * expiring) instead of the strict >365-day 'active' bucket, to fix g135/h050 ("how many
 * trane/carrier units are still under warranty"). REVERTED: the frozen base-exam id
 * counts-warranty-0004-canonical ("How many units have still under warranty?") has an
 * oracle that is literally the strict 'active' bucket for this exact same phrasing with
 * no other filter, and floors only go up in this round — a global text-based rule can't
 * give both answers, and the frozen id wins. "still"/"under warranty"/"in warranty"/
 * "covered" fold back into the same strict 'active' bucket as "active"/"current"/"valid".
 */
const STRICT_ACTIVE_STATUS_RE = /\bactive\b|\bcurrent\b|\bvalid\b|\bstill\b|\bunder warranty\b|\bin warranty\b|\bcovered\b|\bwarrantied\b|\bin-warranty\b/; // R35: + warrantied / in-warranty
// R35: "more than a year left" / "over 12 months of warranty" — the strict bucket, asked for explicitly.
const MORE_THAN_A_YEAR_LEFT_RE = /\b(?:more than|over|at least|longer than)\s+(?:a|one|another|1|12|twelve|365)\s*(?:full\s+)?(?:year|years|yr|yrs|months?|days?)\b(?:[^?.!]{0,30}\b(?:left|remaining|of (?:warranty|coverage)|from now))?/;

const UNKNOWN_WARRANTY_RE =
  /\b(?:no|without|missing|lack(?:s|ing)?)\s+(?:a\s+|any\s+|the\s+)?warrant(?:y|ies)\s+(?:on\s+file|info(?:rmation)?|dates?|end\s+dates?|expir\w*(?:\s+dates?)?|recorded|listed|data)\b|\bwarrant(?:y|ies)\s+(?:is\s+|are\s+)?(?:not\s+on\s+file|missing|not\s+listed|not\s+recorded)\b/;
const NO_WARRANTY_ANYMORE_RE =
  /\b(?:don'?t|doesn'?t|do\s+not|does\s+not)\s+(?:still\s+)?have\s+(?:a\s+|any\s+)?warrant(?:y|ies)\s+(?:anymore|any\s+more|any\s+longer|now)\b/;
/** The warrantyStatus bucket a question names, or null. Pure. */
export function warrantyStatusFromQuestion(question) {
  const q = String(question ?? '').toLowerCase();
  if (!/\bwarrant/.test(q)) return null;
  // "epxiring" — a common adjacent-letter-transposition typo of "expiring"
  // (swapping the 2nd/3rd letters is one of the most frequent human typing
  // slips) that normalizeQuestion's own fuzzy-corrector never catches
  // (its VOCAB is domain nouns/names, not generic words like "expiring").
  let m = /\be[xp]{2}ir(?:ing|es? soon)\b|\babout to expire\b|\brunning out\b/.exec(q);
  if (m) return statusNegatedAt(q, m.index) ? null : 'expiring';
  m = /\bexpired\b|\bout of warranty\b|\bno longer\b|\blapsed\b/.exec(q);
  if (m) return statusNegatedAt(q, m.index) ? null : 'expired';
  m = PAST_WARRANTY_RE.exec(q);
  if (m) return statusNegatedAt(q, m.index) ? null : 'expired';
  if (/\bunknown\b/.test(q)) return 'unknown';
  // R34: "units with no warranty on file / no warranty end date / warranty info missing" is the 'unknown' bucket (no end date known), and
  // "units that don't have a warranty anymore" is 'expired' - both used to match nothing here and answered with every unit.
  if (UNKNOWN_WARRANTY_RE.test(q)) return 'unknown';
  if (NO_WARRANTY_ANYMORE_RE.test(q)) return 'expired';
  if (MORE_THAN_A_YEAR_LEFT_RE.test(q)) return 'active';
  m = STRICT_ACTIVE_STATUS_RE.exec(q);
  if (m) return statusNegatedAt(q, m.index) ? null : 'covered';
  return null;
}

const CONDITION_PLAN_FIELD = {
  email: 'hasEmail', phone: 'hasPhone', brand: 'brand', county: 'county',
  city: 'city', state: 'state', zip: 'zip', warranty: 'warrantyStatus',
};

/** Conditions detectedConditions(question) found that the validated PLAN has
 *  no corresponding filter (or, for 'month', no timeRange) for — the plan
 *  silently dropped something the question actually asked for.
 *
 *  Round 15 (A) BUG FIX: a condition is also satisfied when the plan
 *  expresses it as `groupBy` rather than a `filters[].field` — "how many
 *  different zip codes do we cover" / "customers by county" validly answer
 *  the "zip"/"county" condition a groupBy plan carries (GROUP_BY_FIELDS and
 *  CONDITION_PLAN_FIELD share the same field names for city/county/state/
 *  zip/brand/warrantyStatus), but this used to only ever check `filters`,
 *  never `groupBy` — so EVERY valid groupBy/countDistinct coverage plan was
 *  flagged as having silently dropped the very condition it was built to
 *  answer, and routes/analytics.js's runAnalyticsQuestion (see its own
 *  missingConditions check) replaced a correct answer with the honest-
 *  decline "I can count customers, but I can't filter by zip yet." — worse
 *  than simply answering, since ask.js then still spends a model call on
 *  top of that decline. */
export function missingConditions(plan, question) {
  const missing = new Set();
  for (const c of detectedConditions(question)) {
    if (c === 'month') {
      // D4: an agreement-end plan carries the year as agreementEnd bounds, not as a timeRange.
      if (!plan?.timeRange && !plan?.filters?.some((f) => f.field === 'agreementEnd')) missing.add(c);
      continue;
    }
    const field = CONDITION_PLAN_FIELD[c];
    if (field !== undefined && plan?.groupBy === field) continue;
    // R18 (H1, breadth-data-quality-009): "How many customer addresses are missing a zip code?"
    // detectAnalyticsPlan already builds the CORRECT plan for this - a `hasZip: false` boolean
    // presence-filter (the data-quality shape), not a literal `zip` value filter (the "customers
    // in zip 85201" shape) - but CONDITION_PLAN_FIELD's 'zip' entry only ever names the latter, so
    // this otherwise-correct plan was flagged as having silently dropped the 'zip' condition and
    // replaced with the honest-but-wrong "I can't filter by zip yet" fallback. Both field names are
    // valid satisfiers of the same 'zip' condition; only 'zip' (c === 'zip') gets the extra check,
    // everything else keeps checking its one CONDITION_PLAN_FIELD name exactly as before.
    if (c === 'zip' && plan?.filters?.some((f) => f.field === 'hasZip')) continue;
    // R18 P4 (C2): 'serviceType' has no single CONDITION_PLAN_FIELD name — a plan can satisfy it
    // with EITHER hasServiceType or lacksServiceType (or both — see SERVICE_TYPE_FILTER_FIELDS'
    // own doc comment), so this checks the pair directly rather than one fixed field name.
    if (c === 'serviceType') {
      if (!plan?.filters?.some((f) => f.field === 'hasServiceType' || f.field === 'lacksServiceType')) missing.add(c);
      continue;
    }
    // g103 ("how many trane jobs have we done total"): detectBrandJobsDocumentCount
    // (analytics/detPlan.js) builds a `documents` plan whose brand filter is named
    // `linkedEquipmentBrand` (it filters documents joined to equipment of that
    // manufacturer, not a `brand` field on the document itself — routes/analytics.js's
    // queryDocumentsByEquipmentBrand) rather than the plain `brand` name every OTHER
    // entity's brand filter uses. Without this, missingConditions flagged 'brand' as
    // silently dropped even though the plan already answers it, buildConditionOverrideFilter
    // then bolted on a second, plain `brand` filter `documents` has no support for
    // (ENTITY_SUPPORTED_FIELDS.documents), and executeAnalyticsPlan quietly returned no
    // data — same "silently answer wrong/nothing" failure this whole function exists to
    // prevent, just from the override path instead of a dropped condition.
    if (c === 'brand' && plan?.filters?.some((f) => f.field === 'linkedEquipmentBrand')) continue;
    // D8: a permit's issuing city is its own filter (permitCity), not the customer-geo `city`.
    if (c === 'city' && plan?.filters?.some((f) => f.field === 'permitCity')) continue;
    // E1: "Maricopa County" names the COUNTY. When the plan already filters on the county and the question says "county", the same word read as a city is that
    // county (the router stamps plan.placeReading when it resolved a county/city twin), not a dropped city condition (bolting it on as a second filter turned "customers in Maricopa County" into a confident 0).
    if (c === 'city' && plan?.placeReading === 'county' && plan?.filters?.some((f) => f.field === 'county')) continue;
    if (c === 'county' && plan?.placeReading === 'city' && plan?.filters?.some((f) => f.field === 'city')) continue;
    if (!plan?.filters?.some((f) => f.field === field)) missing.add(c);
  }
  return missing;
}

function titleCaseWords(s) {
  return String(s ?? '')
    .split(/\s+/)
    .map((w) => (w ? w[0].toUpperCase() + w.slice(1).toLowerCase() : w))
    .join(' ');
}

/**
 * Item 4 (100-question persona sample, 2026-09-22): rather than always
 * falling back honestly whenever the model's plan drops a condition the
 * question named, build the missing filter DETERMINISTICALLY when the
 * question gives enough to construct it with confidence — polarity from
 * "missing/without/no" vs "have/with/on file" for email/phone, the matched
 * brand/county/city word itself, a bare 5-digit zip, or a recognized state
 * name. Returns null when this specific condition can't be turned into a
 * filter this way (an unrecognized brand/county/city word, or a
 * state/zip that never actually appears despite the condition being
 * detected some other way) — the caller (routes/analytics.js) then keeps the
 * honest "can't filter by X yet" fallback for THAT condition, exactly as
 * before this existed. Never called for 'money'/'maintenance'/'month' —
 * those have no CONDITION_PLAN_FIELD entry at all and are handled earlier,
 * by the plan-independent up-front checks in runAnalyticsQuestion.
 */
// Reviewer NO-GO (2026-09-26, round 14): "how many customers are not in
// Mesa" / "units that are not Trane" / "excluding Mesa" / "outside of Mesa"
// all detected their geo/brand word exactly as any positive phrasing would,
// then silently built a POSITIVE `eq` filter — the exact opposite of the
// asked-for set, answered with full confidence. Checked right before the
// matched word itself (never a wide word-window, which would risk an
// unrelated "don't have a phone" elsewhere in the same sentence flipping an
// unrelated city/brand word) — a real, common negation idiom directly
// governing THIS SPECIFIC matched word, nothing else.
// R18 P4 (C4, negation collapse/inversion): "list every customer whose service address isnt even
// in arizona" (h189) inverted — the negation word ("isn't") was there, right before "arizona", but
// the intensifier "even" sitting between "isnt" and "in" broke the fixed-filler-word match this
// regex required, so isNegatedWord silently returned false and built the exact opposite (an `eq`,
// not `neq`) filter. "even"/"really"/"actually" are common intensifiers a real negation phrasing
// inserts right there ("isn't even in Arizona", "doesn't actually have a Trane unit") — added to
// the filler-word alternation (not a separate rule) so every existing caller (brand/city/county/
// state/zip negation) gets the same tolerance for free.
const NEGATION_IMMEDIATELY_BEFORE_RE =
  /\b(?:not|except(?:\s+for)?|excluding|other\s+than|besides|outside(?:\s+of)?|without|no|isn'?t|aren'?t|wasn'?t|weren'?t)\s+(?:(?:an?|the|in|from|on|even|really|actually)\s+){0,3}$/i;

function isNegatedWord(q, word) {
  const esc = escapeRegExp(word);
  const idx = new RegExp(`\\b${esc}\\b`, 'i').exec(q)?.index;
  if (idx == null) return false;
  if (NEGATION_IMMEDIATELY_BEFORE_RE.test(q.slice(0, idx))) return true;
  // "customers who do not have a Trane unit" / "don't have a unit in Mesa" —
  // the same negative-possession shape buildConditionOverrideFilter's own
  // email/phone branch already recognizes, just generalized to whichever
  // word this call is checking (bounded window, so an unrelated "don't have
  // an email" earlier in a long sentence never flips a LATER, unrelated
  // city/brand mention).
  if (new RegExp(`\\b(?:don'?t|doesn'?t|do not|does not)\\s+have\\b[\\s\\S]{0,20}\\b${esc}\\b`, 'i').test(q)) return true;
  // "customers who do not live in Arizona" / "aren't located in Mesa" / "not based in AZ": a negated residence verb right before the place.
  return new RegExp(`\\b(?:don'?t|doesn'?t|do not|does not|aren'?t|are not|isn'?t|is not|not|never)\\s+(?:live|lives|living|located|based|reside|resides|residing|situated|from)\\s+(?:in|at|within|inside)?\\s*(?:the\\s+)?(?:state\\s+of\\s+)?${esc}\\b`, 'i').test(q);
}

/**
 * `entity`, when given, is the plan's (or detPlan.js's own current best
 * guess at the) entity — only ever consulted for a NEGATED brand condition:
 * "customers without a Trane unit" cannot be expressed as a single-row
 * `brand != Trane` filter the way "units that are not Trane" can (a customer
 * can own several units, so "has a non-Trane unit" — what a neq filter over
 * the joined equipment rows would actually compute — is not the same claim
 * as "owns no Trane unit at all", a NOT EXISTS this closed filter vocabulary
 * has no way to express). Returning null there (never guessing which one
 * was meant) is the same "never guess" rule as everywhere else in this
 * file; a plain equipment/warranties-entity brand negation has no such
 * per-customer ambiguity and is always resolved to `neq`.
 */
export function buildConditionOverrideFilter(condition, question, entity) {
  const q = String(question ?? '').toLowerCase();
  if (condition === 'email' || condition === 'phone') {
    const field = condition === 'email' ? 'hasEmail' : 'hasPhone';
    // "no/missing/without <email/phone>" said right next to the noun, OR a
    // "don't/doesn't/do not/does not have" clause anywhere earlier in the
    // question ("customers who don't have a phone number on file") — both
    // are the same negative-possession shape, just with the negation word
    // further from the noun in the second one.
    const negative = new RegExp(
      `\\b(?:no|missing|without)\\s+(?:an?\\s+)?${condition}\\b|` +
        `\\b(?:don'?t|doesn'?t|do not|does not)\\s+have\\b[\\s\\S]{0,20}\\b${condition}\\b`,
      'i'
    );
    return { field, op: 'eq', value: !negative.test(q) };
  }
  if (condition === 'brand') {
    const matches = [...new Set(BRAND_WORDS.filter((b) => new RegExp(`\\b${b}\\b`).test(q)))];
    if (matches.length === 0) return null;
    // Reviewer NO-GO (2026-09-26, round 14): "how many Trane and Carrier customers in Mesa" naming TWO
    // values for the same dimension is genuinely ambiguous with this closed, flat filter vocabulary — an
    // AND (no unit is both brands) is a silent zero/undercount, an OR needs an `in` filter this function
    // never builds for a safety-net condition. Never guess which one (or that it was really both) was
    // meant; see the matching city/county/zip/state guards below for the identical shape.
    if (matches.length > 1) return null;
    const word = matches[0];
    if (isNegatedWord(q, word)) {
      if (entity === 'customers') return null; // exists-not-at-all — no flat filter can say this; never guess
      return { field: 'brand', op: 'neq', value: titleCaseWords(word) };
    }
    return { field: 'brand', op: 'eq', value: titleCaseWords(word) };
  }
  if (condition === 'county') {
    const sorted = [...KNOWN_COUNTY_NAMES].sort((a, b) => b.length - a.length);
    const matches = [...new Set(sorted.filter((c) => new RegExp(`\\b${escapeRegExp(c)}\\b`).test(q)))];
    if (matches.length === 0) return null;
    if (matches.length > 1) return null; // two distinct counties named — never guess which (see brand's own doc comment)
    const word = matches[0];
    return { field: 'county', op: isNegatedWord(q, word) ? 'neq' : 'eq', value: titleCaseWords(word) };
  }
  if (condition === 'city') {
    const names = [...new Set([...KNOWN_AZ_CITY_NAMES, ...KNOWN_US_CITY_NAMES])].sort((a, b) => b.length - a.length);
    const matches = [];
    for (const c of names) {
      if (!new RegExp(`\\b${escapeRegExp(c)}\\b`).test(q)) continue;
      // A shorter matched name that is itself a SUBSTRING of a longer name already matched (e.g. "Casa"
      // inside "Casa Grande") is the same one mention, not a second city — only a genuinely distinct
      // name counts toward the ambiguity check below.
      if (matches.some((m) => m.includes(c) || c.includes(m))) continue;
      matches.push(c);
    }
    if (matches.length === 0) return null;
    if (matches.length > 1) return null; // two distinct cities named — never guess which (see brand's own doc comment)
    const word = matches[0];
    return { field: 'city', op: isNegatedWord(q, word) ? 'neq' : 'eq', value: titleCaseWords(word) };
  }
  if (condition === 'state') {
    const az = /\barizona\b|\baz\b/.test(q);
    const nv = /\bnevada\b|\bnv\b/.test(q);
    if (az && nv) return null; // both states named — never guess which (see brand's own doc comment)
    if (az) {
      const word = /\barizona\b/.test(q) ? 'arizona' : 'az';
      return { field: 'state', op: isNegatedWord(q, word) ? 'neq' : 'eq', value: 'AZ' };
    }
    if (nv) {
      const word = /\bnevada\b/.test(q) ? 'nevada' : 'nv';
      return { field: 'state', op: isNegatedWord(q, word) ? 'neq' : 'eq', value: 'NV' };
    }
    return null;
  }
  if (condition === 'zip') {
    const matches = [...new Set(q.match(/\b\d{5}\b/g) ?? [])];
    if (matches.length === 0) return null;
    if (matches.length > 1) return null; // two distinct zips named — never guess which (see brand's own doc comment)
    const m = matches[0];
    return { field: 'zip', op: isNegatedWord(q, m) ? 'neq' : 'eq', value: m };
  }
  if (condition === 'warranty') {
    const status = warrantyStatusFromQuestion(q);
    return status ? { field: 'warrantyStatus', op: 'eq', value: status } : null;
  }
  // R18 P4 (C2): safety-net path for a MODEL plan that dropped a service_type condition —
  // customers-only (validatePlan enforces this), builds only the single filter this simple
  // condition->filter mapping can express (a has OR a lacks, from whichever polarity the nearest
  // match reads); detPlan.js's own detectCustomersHasServiceType handles the richer "has X, never
  // Y" combo directly (both filters in one plan) since it can look at every phrase, not just one.
  if (condition === 'serviceType') {
    const m = SERVICE_TYPE_PHRASE_RE.exec(q);
    if (!m) return null;
    const value = serviceTypeValueOf(m[1]);
    return isNegatedWord(q, m[1]) ? { field: 'lacksServiceType', op: 'eq', value } : { field: 'hasServiceType', op: 'eq', value };
  }
  return null;
}

/** The honest "I can't do that yet" answer for one dropped condition —
 *  `kind: 'answer'` (never an error) so the client renders it exactly like
 *  any other analytics reply, just with no facts and no false count. */
export function unsupportedConditionAnswer(condition, entity = 'customers') {
  const noun = (ENTITY_NOUN[entity] ?? ENTITY_NOUN.customers)(2);
  return {
    kind: 'answer',
    text: `I can count ${noun}, but I can't filter by ${condition} yet.`,
    facts: [], sources: [], confidence: 1, verifiedCount: 0, unverifiedCount: 0, closest: [],
  };
}

/**
 * Item 7 (100-question persona sample, 2026-09-22), "has X but no Y":
 * "customers with a maintenance agreement but no service this year" /
 * "customers with a proposal but no invoice" — a cross-document-type filter
 * with no path through the ordinary entity/filter vocabulary at all (a
 * customer either has or lacks a document of some type; nothing in
 * FILTER_FIELDS before hasDocType/lacksDocType existed could express that).
 * Detected and turned into a plan HERE, deterministically, before the model
 * is ever asked — the same "code decides the shape, never the model"
 * contract resolveServiceVisitsOverride already keeps for entity/op.
 *
 * When the "no ___" half names a real document type ("no invoice", "no
 * proposal"), both halves resolve to real hasDocType/lacksDocType filters and
 * the question is answered for real. When it names "service" instead (a
 * SERVICE VISIT, not a document type this corpus tracks as such) — optionally
 * with a time window ("no service this year") — there is no filter field for
 * that at all, so this returns `unsupported` naming exactly the part that
 * can't be expressed, and the caller (runAnalyticsQuestion) gives the honest
 * fallback instead of guessing.
 */
const CROSS_DOC_BUT_NO_RE = new RegExp(
  `\\b(${docTypeSynonymAlternation()})\\b(?:s)?[\\s\\S]{0,10}\\bbut\\s+no\\s+(${docTypeSynonymAlternation()}|service)\\b([\\s\\S]{0,25})?`,
  'i'
);
const CROSS_DOC_TIME_WINDOW_RE = /\b(this year|last year|this month|last month|this week|last week|since\s+\d{4})\b/i;

export function parseCrossDocCondition(question) {
  const q = String(question ?? '').toLowerCase();
  const m = q.match(CROSS_DOC_BUT_NO_RE);
  if (!m) return null;
  const hasType = docTypeFromWord(m[1]);
  if (!hasType) return null;
  const lacksWord = m[2].toLowerCase();
  const trailing = m[3] ?? '';
  if (lacksWord === 'service') {
    const windowMatch = trailing.match(CROSS_DOC_TIME_WINDOW_RE);
    return { hasType, lacksType: null, unsupported: 'service', windowLabel: windowMatch ? windowMatch[1] : null };
  }
  const lacksType = docTypeFromWord(lacksWord);
  if (!lacksType) return null;
  return { hasType, lacksType, unsupported: null };
}

/** The honest fallback for a cross-doc condition this file can't express
 *  (the "no service ___" half) — names the part that DOES work (the
 *  hasDocType half) alongside the part that doesn't, never a silent
 *  unfiltered answer. */
export function crossDocUnsupportedAnswer(cross) {
  const label = documentTypeLabel(cross.hasType).toLowerCase();
  const windowPart = cross.windowLabel ? ` ${cross.windowLabel}` : '';
  return {
    kind: 'answer',
    text: `I can find customers with a ${label}, but I can't filter by "no ${cross.unsupported}${windowPart}" yet.`,
    facts: [], sources: [], confidence: 1, verifiedCount: 0, unverifiedCount: 0, closest: [],
  };
}

/* =================================================================== schema */

export const ANALYTICS_TOOL = {
  name: 'analytics_plan',
  description:
    "Turn the dispatcher's counting/listing/grouping question into a structured query plan. " +
    'Never answer in prose and never write SQL — only fill this schema. Use ONLY the listed ' +
    'entities/ops/fields; if nothing in the vocabulary fits the question, still return your best ' +
    'guess (the caller validates and safely falls back if it does not fit).',
  input_schema: {
    type: 'object',
    properties: {
      entity: {
        type: 'string',
        enum: ENTITIES,
        description:
          'What is being counted/listed. Default to "customers" when the question names no ' +
          'entity at all (e.g. "how many in Maricopa County").',
      },
      op: {
        type: 'string',
        enum: OPS,
        description:
          '"count": a single number. "list": individual rows (customer names, etc). ' +
          '"groupBy": counts broken down by groupBy field (e.g. "by city"). "sum": total a numeric field.',
      },
      groupBy: {
        type: 'string',
        enum: GROUP_BY_FIELDS,
        description: 'Required when op is "groupBy". Omit otherwise.',
      },
      filters: {
        type: 'array',
        items: {
          type: 'object',
          properties: {
            field: {
              type: 'string',
              enum: FILTER_FIELDS,
              description:
                'state: 2-letter code ("AZ") — "Arizona"/"arizona" both mean AZ. county: bare name, ' +
                'no the word "County" ("Maricopa", not "Maricopa County"). warrantyStatus: one of ' +
                `${WARRANTY_STATUSES.join('|')} ("out of warranty"/"expired" -> expired; "still under ` +
                'warranty"/"active"/"current"/"covered" -> covered (not expired yet); "more than a year left" -> active; ' +
                '"expiring soon" -> expiring). installYear: the calendar ' +
                'year installed, for "older/newer than N years" compute the year and use op gt/lt. ' +
                'hasEmail (customers only, boolean value, op "eq"): "have/has an email on file" -> true; ' +
                '"missing/without/no email" -> false. hasPhone (customers only, boolean value, op "eq"): ' +
                '"have/has a phone (number) on file" -> true; "missing/without/no phone (number)" -> false.',
            },
            op: { type: 'string', enum: FILTER_OPS },
            value: { description: 'A string or number matching the field (an array only for op "in").' },
          },
          required: ['field', 'op', 'value'],
        },
      },
      timeRange: {
        type: 'object',
        properties: { from: { type: 'string' }, to: { type: 'string' } },
        description: 'YYYY-MM-DD or YYYY-MM, for "this month"/"in August"/"since 2024" style questions.',
      },
      limit: { type: 'number', description: `Row cap for "list". Defaults to ${DEFAULT_LIMIT}.` },
      sortBy: {
        type: 'string',
        enum: SORT_FIELDS,
        description:
          'Only for entity "customers" + op "list": rank customers by size instead of filtering them. ' +
          '"who\'s our biggest/largest/top customer(s)" -> "equipmentCount" unless the question names ' +
          'documents/invoices/paperwork specifically, in which case "documentCount". Omit for every other question.',
      },
    },
    required: ['entity', 'op'],
  },
};

/** One line per canonical entity, its plain-English synonyms, built from
 *  ENTITY_SYNONYMS (above) so the prompt can never drift from the
 *  classifier's own noun list — see that table's own doc comment. */
function synonymPromptLine() {
  return Object.entries(ENTITY_SYNONYMS)
    .filter(([entity]) => entity !== 'technicians')
    .map(([entity, words]) => `${entity} = ${[...new Set(words)].join('/')}`)
    .join('; ');
}

export const ANALYTICS_SYSTEM_PROMPT_BASE =
  'You turn a company\'s counting/listing/grouping question about its own records into a query plan ' +
  'using the "analytics_plan" tool. You never see or write SQL, and you never answer the question ' +
  'yourself — you only choose entity/op/groupBy/filters from the closed vocabulary the tool schema ' +
  'declares. The owner uses plain English, not database terms — map every synonym to its canonical ' +
  `entity before filling the schema: ${synonymPromptLine()}. "Arizona"/"AZ"/"arizona" always means ` +
  'the state filter value "AZ". A bare county name ("Maricopa", "Pima") means the county filter with ' +
  'that name, no "County" suffix. A brand name (Trane, Carrier, Goodman, Lennox, Rheem, York, Daikin, ' +
  'Mitsubishi, ...) means the brand filter. "this month"/"last month"/"this week"/a named month means ' +
  'timeRange. "who\'s our biggest/largest/top customer(s)" means entity "customers", op "list", and ' +
  'sortBy "equipmentCount" (or "documentCount" if the question specifically names documents/invoices) ' +
  '— never a filter. "have/has an email on file" means filter hasEmail=true; "missing/without/no email" ' +
  'means hasEmail=false; the same mapping applies to "phone"/hasPhone. If the question names no entity, ' +
  'assume "customers". Always call the tool exactly once.';

/* ============================================================ few-shot examples
 *
 * Day 2 training plan (handoffs/DONOVAN_TRAINING_PLAN_2026-09-21.md): ~25
 * tricky question -> plan pairs, curated from the shapes the Day 1 question
 * bank and the live miss clusters actually found hard — a bare month with no
 * year, county vs city vs state, a brand+county combo, hasEmail/hasPhone in
 * both polarities, warrantyStatus, an installYear age filter, documentType
 * synonyms, a technician filter, every groupBy dimension, list vs count, a
 * brand-vs-brand comparison (groupBy + an `in` filter), and the customers-
 * via-equipment-join shape ("which customers in Mesa have Trane units").
 *
 * Each `plan` here is a real `analytics_plan` tool-input shape — every one is
 * checked against validatePlan by scripts/verify-analytics.mjs, so this list
 * can never silently drift out of the closed vocabulary it's meant to teach.
 * Questions are written in the NORMALIZED form the planner actually receives
 * (nlNormalize.js has already lowercased, expanded abbreviations like "az" ->
 * "arizona", and fixed typos before this prompt ever sees the question) — see
 * routes/analytics.js's planAnalyticsQuestion, which is called with
 * `question_n`, never the raw text.
 *
 * The last three are NEGATIVE examples: shapes the planner must not spend a
 * confident plan on because api/ask.js / runAnalyticsQuestion already
 * intercept them before (or instead of) trusting a plan — a money question
 * (isMoneyQuestion), a maintenance-due question (detectedConditions'
 * 'maintenance', MAINTENANCE_DUE_RE) and a single-record address lookup
 * (looksLikeSingleRecordReference). `fallback` names the exact internal
 * marker each one maps to — the same string these real detectors key off —
 * rather than a plan, and `plan` is deliberately absent (renderFewShotLine
 * below renders these as a `SKIP` line, never a JSON tool-input, since the
 * schema has no field for "decline"). scripts/verify-analytics.mjs checks
 * each of these three questions actually trips its named detector, so this
 * list can never drift out of sync with the real fallback logic either.
 */
export const ANALYTICS_FEW_SHOT = [
  // ---- time ----
  { q: 'how many jobs did we do in august', plan: { entity: 'serviceVisits', op: 'count' } },
  {
    q: 'how many invoices from august of 2023',
    plan: {
      entity: 'documents', op: 'count',
      filters: [{ field: 'documentType', op: 'eq', value: 'invoice' }],
      timeRange: { from: '2023-08', to: '2023-08' },
    },
  },
  // ---- geo: county vs city vs state ----
  { q: 'how many customers in maricopa county', plan: { entity: 'customers', op: 'count', filters: [{ field: 'county', op: 'eq', value: 'Maricopa' }] } },
  { q: 'how many customers in chandler', plan: { entity: 'customers', op: 'count', filters: [{ field: 'city', op: 'eq', value: 'Chandler' }] } },
  { q: 'how many customers in arizona', plan: { entity: 'customers', op: 'count', filters: [{ field: 'state', op: 'eq', value: 'AZ' }] } },
  // ---- brand + county combo ----
  {
    q: 'how many trane units in pima county',
    plan: { entity: 'equipment', op: 'count', filters: [{ field: 'brand', op: 'eq', value: 'Trane' }, { field: 'county', op: 'eq', value: 'Pima' }] },
  },
  // ---- hasEmail / hasPhone, both polarities ----
  { q: 'how many customers have an email on file', plan: { entity: 'customers', op: 'count', filters: [{ field: 'hasEmail', op: 'eq', value: true }] } },
  { q: 'how many customers are missing a phone number', plan: { entity: 'customers', op: 'count', filters: [{ field: 'hasPhone', op: 'eq', value: false }] } },
  // ---- warrantyStatus ----
  { q: 'which units have an expired warranty', plan: { entity: 'warranties', op: 'list', filters: [{ field: 'warrantyStatus', op: 'eq', value: 'expired' }] } },
  // ---- installYear age filter ----
  { q: 'which customers have units older than 10 years', plan: { entity: 'customers', op: 'list', filters: [{ field: 'installYear', op: 'lt', value: 2016 }] } },
  // ---- documentType synonyms ----
  { q: 'how many permits do we have', plan: { entity: 'documents', op: 'count', filters: [{ field: 'documentType', op: 'eq', value: 'permit' }] } },
  { q: 'how many proposal quotes are there', plan: { entity: 'documents', op: 'count', filters: [{ field: 'documentType', op: 'eq', value: 'proposal-quote' }] } },
  { q: 'how many service tickets do we have', plan: { entity: 'documents', op: 'count', filters: [{ field: 'documentType', op: 'eq', value: 'service-ticket' }] } },
  // ---- technician ----
  { q: 'how many jobs did mike do last week', plan: { entity: 'serviceVisits', op: 'count', filters: [{ field: 'technician', op: 'eq', value: 'Mike' }] } },
  // ---- groupBy: month, brand, county, zip ----
  { q: 'jobs per month this year', plan: { entity: 'serviceVisits', op: 'groupBy', groupBy: 'month' } },
  { q: 'how many units do we have by brand', plan: { entity: 'equipment', op: 'groupBy', groupBy: 'brand' } },
  { q: 'customers by county', plan: { entity: 'customers', op: 'groupBy', groupBy: 'county' } },
  // "what zip codes do we serve" (round 6, 2026-09-25 coverage failure): the question about the DIMENSION itself
  // ("what zip codes/counties/cities do we serve/cover") is a groupBy over that dimension, the same shape as
  // "customers by county" above — nothing in the few-shot bank named "zip" at all before this, so the planner had
  // no example anchoring "serve"/"cover" + a geo dimension word to groupBy instead of some other op.
  { q: 'what zip codes do we serve', plan: { entity: 'customers', op: 'groupBy', groupBy: 'zip' } },
  // ---- list vs count ----
  { q: 'list customers in gilbert', plan: { entity: 'customers', op: 'list', filters: [{ field: 'city', op: 'eq', value: 'Gilbert' }] } },
  // ---- comparison: groupBy + an `in` filter, not two separate plans ----
  {
    q: 'trane vs carrier units',
    plan: { entity: 'equipment', op: 'groupBy', groupBy: 'brand', filters: [{ field: 'brand', op: 'in', value: ['Trane', 'Carrier'] }] },
  },
  // ---- customers-via-equipment join ----
  {
    q: 'which customers in mesa have trane units',
    plan: { entity: 'customers', op: 'list', filters: [{ field: 'city', op: 'eq', value: 'Mesa' }, { field: 'brand', op: 'eq', value: 'Trane' }] },
  },
  // ---- "had/were serviced" shape (live miss, 2026-09-21) — entity
  // serviceVisits, never equipment/customers, which carry no service_date
  // column at all; see resolveServiceVisitsOverride's own doc comment for why
  // this is also forced deterministically rather than left to the model. ----
  { q: 'which units had service this month', plan: { entity: 'serviceVisits', op: 'list', timeRange: { from: '2026-09', to: '2026-09' } } },
  { q: 'how many service calls this month', plan: { entity: 'serviceVisits', op: 'count', timeRange: { from: '2026-09', to: '2026-09' } } },
  // ---- NEGATIVE: never plan these — already handled before/instead of you ----
  { q: 'how much did we invoice last month', fallback: 'money' },
  { q: 'which customers are overdue for maintenance', fallback: 'maintenance' },
  { q: "what's the warranty on the unit at 1234 elm street", fallback: 'single-record' },
];

/** One compact line per few-shot example — minified JSON for a real plan, or
 *  a `SKIP(marker)` line for a negative example (see ANALYTICS_FEW_SHOT's own
 *  doc comment for why a negative can't be a tool-input JSON value). */
function renderFewShotLine(ex) {
  if (ex.fallback) return `Q:"${ex.q}"->SKIP(${ex.fallback})`;
  return `Q:"${ex.q}"->${JSON.stringify(ex.plan)}`;
}

/** Appended at the END of the system prompt, after every other line, so the
 *  long STABLE prefix above (task framing, entity synonyms, rules) stays
 *  byte-for-byte first — Anthropic's prompt cache matches on a shared prefix,
 *  so anything that might grow/reorder in the future belongs after it, not
 *  interleaved with it. */
export const ANALYTICS_FEW_SHOT_BLOCK =
  '\n\nEXAMPLES (question -> analytics_plan tool input; SKIP means a question you must not invent a ' +
  "plan for — it's already handled before you're ever called):\n" +
  ANALYTICS_FEW_SHOT.map(renderFewShotLine).join('\n');

export const ANALYTICS_SYSTEM_PROMPT = ANALYTICS_SYSTEM_PROMPT_BASE + ANALYTICS_FEW_SHOT_BLOCK;

/** ~4 chars/token is a standard, conservative estimate for English prose and
 *  compact JSON alike — good enough for a soft cap, never sent to a
 *  tokenizer. Exported so scripts/verify-learning.mjs can pin the same
 *  arithmetic the cap below uses. */
export function estimateTokens(s) {
  return Math.ceil(String(s ?? '').length / 4);
}

const LEARNED_FEW_SHOT_MAX_ITEMS = 12;
const LEARNED_FEW_SHOT_MAX_TOKENS = 500;

/**
 * Tier 2 learning (Part A): `extraFewShot` is the ACTIVE overlay's own
 * approved `few_shot` items (learning/overlay.js's getActiveOverlay) —
 * `{question, plan}` pairs an operator approved after seeing them fix a real
 * miss. Appended AFTER ANALYTICS_FEW_SHOT_BLOCK (never interleaved with the
 * curated, stable examples above it — same prompt-cache-prefix reasoning
 * ANALYTICS_FEW_SHOT_BLOCK's own doc comment gives), capped at 12 items / an
 * estimated 500 tokens so a runaway learned set can never blow up every
 * planner call's cost. Greedy: items are taken in order until either cap
 * would be exceeded, then stops (never drops an earlier item to fit a later,
 * bigger one). No `extraFewShot` (or none of it fits) returns the exact same
 * ANALYTICS_SYSTEM_PROMPT constant — so this is a pure widening, never a
 * mutation of the base prompt.
 */
/**
 * `vocabLines` (Round 11, literature #6 "schema linking"): an optional short, ALREADY question-relevant
 * string (vocab/tenantVocab.js's schemaLinkedVocabLines) naming this tenant's own brand/document-type/
 * city values that matter for the question actually being asked — grounding the planner in what THIS
 * tenant's data contains instead of only the generic vocabulary every tenant's prompt otherwise shares.
 * Purely additive: never removes or narrows a choice from ANALYTICS_TOOL's own closed enum, and omitted
 * (every caller before this existed) returns byte-identical output.
 */
export function buildAnalyticsSystemPrompt({ extraFewShot, vocabLines } = {}) {
  let prompt = ANALYTICS_SYSTEM_PROMPT;
  if (typeof vocabLines === 'string' && vocabLines.trim()) {
    prompt = `${prompt}\n\nTHIS TENANT'S OWN DATA (schema linking — prefer these exact values when the question matches them): ${vocabLines.trim()}`;
  }
  if (!Array.isArray(extraFewShot) || !extraFewShot.length) return prompt;
  const lines = [];
  let tokens = 0;
  for (const ex of extraFewShot) {
    if (lines.length >= LEARNED_FEW_SHOT_MAX_ITEMS) break;
    if (!ex || typeof ex.question !== 'string' || !ex.question.trim() || !ex.plan) continue;
    const validated = validatePlan(ex.plan);
    if (!validated) continue;
    const line = `Q:"${ex.question}"->${JSON.stringify(validated)}`;
    const lineTokens = estimateTokens(line);
    if (tokens + lineTokens > LEARNED_FEW_SHOT_MAX_TOKENS) break;
    lines.push(line);
    tokens += lineTokens;
  }
  if (!lines.length) return prompt;
  return `${prompt}\n\nLEARNED EXAMPLES (operator-approved, same format as above):\n${lines.join('\n')}`;
}

/* ============================================================ cache namespace
 *
 * Reviewer NO-GO (2026-09-21, A2): analytics answers were being cached and
 * looked up under the SAME question_hash the retrieval+model path uses (both
 * computed as `hashQuestion(normalizeQuestion(question))` in api/ask.js) and
 * the SAME global corpus_stamp prompt-version mixed in by askCache.js's
 * `getCacheEntry` (that version is derived from the RETRIEVAL system prompt
 * + ANSWER_TOOL, not this file's). Two concrete bugs followed: (1) a question
 * previously answered and cached via retrieval, that the classifier now
 * routes to analytics, would have `getCacheEntry` return that OLD retrieval
 * answer (wrong shape, no aggregate math) as if it were a valid analytics
 * cache hit; (2) any future change to THIS file's prompt/schema/logic had no
 * way to bust old analytics cache rows, since the corpus_stamp it shared with
 * retrieval only reacts to retrieval's own prompt/schema changing.
 *
 * Fix: analytics gets its OWN prompt-version fingerprint (`ANALYTICS_PROMPT_
 * VERSION`, passed to askCache.js's `getCacheEntry` as `promptVersion` — see
 * that file) and its OWN namespaced hash space, computed by THESE functions,
 * never api/ask.js's shared `hashQuestion`. Two tiers:
 *   - `analyticsQuestionHash` — "analytics:" + the question text. Checked
 *     FIRST, before the Haiku planner call, so a repeated exact phrasing
 *     still costs nothing (the whole point of caching this at all).
 *   - `analyticsPlanHash` — "analytics-plan:" + the validated PLAN's own
 *     canonical JSON. Checked after a Tier-1 miss, once the plan is known —
 *     so two DIFFERENT phrasings that resolve to the SAME plan ("how many
 *     customers in Arizona" / "count customers in AZ") share one answer, and
 *     two DIFFERENT plans can never collide with each other's cached answer,
 *     because the hash IS a digest of the plan itself, not a guess at one.
 * See routes/analytics.js's runAnalyticsQuestion for how both tiers are used,
 * and askCache.js's getCacheEntry for the promptVersion parameter.
 */
// Bumped v1 -> v2 (2026-09-21, items 1+2): hasEmail/hasPhone added to the tool
// schema/prompt, so any plan cached under the old vocabulary must be
// invalidated (a cached "customers count" answer to "how many customers have
// an email on file" must never be served again now that the filter exists).
// Bumped v2 -> v3 (2026-09-21, round 6): a stale pre-fix cache row (e.g. the
// "49 customers." answer for a maintenance-due question) must never survive
// this deploy just because its promptVersion still matched — every prior
// analytics cache row is invalidated on deploy regardless of the new
// pre-cache guard above, which is the real fix; this is belt-and-suspenders.
// Bumped v3 -> v4 (Day 2 training plan, 2026-09-21): ANALYTICS_SYSTEM_PROMPT
// now carries the ANALYTICS_FEW_SHOT block — a real prompt change, so every
// prior cache row (planned under the few-shot-less prompt) must invalidate
// the same way v2's hasEmail/hasPhone bump and v3's belt-and-suspenders bump
// both already did.
// Bumped v4 -> v5 ("which units had service this month" live miss,
// 2026-09-21): two new few-shot examples were added to ANALYTICS_FEW_SHOT
// (another real prompt change) and the serviceVisits SQL now returns
// customer_name/model columns it never did before — any plan cached under
// the old vocabulary/shape must be invalidated the same way every prior bump
// already was.
// Bumped v6 -> v7 (100-question persona sample, 2026-09-22): FILTER_FIELDS
// grew hasDocType/lacksDocType (ANALYTICS_TOOL's own enum, so this is already
// covered by the tool-hash half of ANALYTICS_PROMPT_VERSION below — bumped
// anyway, belt-and-suspenders, matching v2/v3's own precedent) and the
// condition-override/cross-doc logic changed what a "missing condition" or
// "has X but no Y" question answers — a plan or answer cached under the old
// behavior must never be served again just because its own prompt text
// happened not to change.
export const ANALYTICS_VERSION = 'analytics-v10'; // v10 (R39): leftover-condition guard + exact counts past 500 rows (v9 (Team A): dateBasis + code-side age filter + no future service visits)
export const ANALYTICS_PROMPT_VERSION = createHash('sha256')
  .update(ANALYTICS_VERSION)
  .update(JSON.stringify(ANALYTICS_TOOL))
  .update(ANALYTICS_SYSTEM_PROMPT)
  .digest('hex')
  .slice(0, 12);

/** Mirrors api/ask.js's own normalizeQuestion exactly (trim/lowercase/
 *  collapse whitespace/strip trailing punctuation) — duplicated rather than
 *  imported so this _lib file has no dependency on the top-level endpoint
 *  file that already imports IT. Private: callers hash through the two
 *  functions below, never this directly. */
function normalizeQuestionForHash(q) {
  return String(q ?? '').trim().toLowerCase().replace(/\s+/g, ' ').replace(/[?!.]+$/, '');
}

function sha256Hex(s) {
  return createHash('sha256').update(String(s)).digest('hex');
}

/** Tier 1: namespaced by question text alone, so a REPEATED exact phrasing
 *  never even calls the Haiku planner. Never equal to api/ask.js's own
 *  `hashQuestion(normalizeQuestion(question))` for the same text — the
 *  "analytics:" prefix guarantees the two hash spaces can never collide. */
export function analyticsQuestionHash(question) {
  return sha256Hex(`analytics:${normalizeQuestionForHash(question)}`);
}

/** A validated plan's filters, sorted by (field, op) so two plans that carry
 *  the same filters in a different array order still canonicalize to the
 *  same string — this is what makes analyticsPlanHash a true digest of the
 *  PLAN, not of whatever order the model happened to list filters in. */
function canonicalPlanString(plan) {
  const filters = [...(plan?.filters ?? [])]
    .map((f) => ({ field: f.field, op: f.op, value: f.value }))
    .sort((a, b) => (a.field === b.field ? (a.op < b.op ? -1 : a.op > b.op ? 1 : 0) : a.field < b.field ? -1 : 1));
  return JSON.stringify({
    entity: plan?.entity ?? null,
    op: plan?.op ?? null,
    groupBy: plan?.groupBy ?? null,
    filters,
    timeRange: plan?.timeRange ?? null,
    limit: plan?.limit ?? null,
    // round 4 item 1: a plain "list customers" and a "biggest customer"
    // sortBy plan must never share a cache row — they run different SQL.
    sortBy: plan?.sortBy ?? null,
    // Team A: an "uploaded" count and a "by service date" count run different logic.
    dateBasis: plan?.dateBasis ?? null,
    // R19 (I2, h112/h113/h115): "biggest city" (top) and "fewest units" (bottom) share the same
    // entity/op/groupBy/filters — omitting this would let the two share one cache row and serve
    // each other's answer.
    superlative: plan?.superlative ?? null,
    // R19 (I2, task 5): a customer-scoped and a team-scoped question can produce the identical
    // entity/op/filters plan (no FILTER_FIELDS entry names "internal" vs "customer" audience at
    // all) — omitting this would let the two share a cache row and serve each other's (differently
    // audience-filtered) answer. Never set by the model — see routes/analytics.js's own
    // isTeamScopedQuestion call site, the same code-side-only convention as superlative/countDistinct.
    teamScoped: plan?.teamScoped ?? null,
    // E2 A4: "how many units in Mesa" and "how many customers in Mesa" build the same customers/count/city plan but count different things.
    ...(plan?.countUnits ? { countUnits: true } : {}),
  });
}

/** Tier 2: namespaced by the PLAN's own canonical JSON, so distinct plans can
 *  never collide (the hash IS a digest of the plan) and two differently-
 *  worded questions that resolve to the identical plan share one cached
 *  answer instead of paying for the same SQL twice. */
export function analyticsPlanHash(plan) {
  return sha256Hex(`analytics-plan:${canonicalPlanString(plan)}`);
}

/* ============================================================ month resolution
 *
 * Item 1 (2026-09-21 live miss): "how many jobs did we do in August" fell
 * through to retrieval. Root cause: the model was asked to fill `timeRange`
 * itself ("this month"/"last month"/a named month means timeRange" was the
 * only guidance) with no year math spelled out for a BARE month name, and a
 * bad/missing timeRange fails validatePlan's `^\d{4}(-\d{2}...)?$` shape check
 * and rejects the WHOLE plan -> null -> full fall-through, exactly like any
 * other invalid plan. Rather than trust the model's date arithmetic (the same
 * "the model never computes the real answer, code does" rule this file's
 * header already states for SQL and formatting), a literal month name/"this
 * month"/"last month" phrase in the QUESTION TEXT is resolved to an exact
 * YYYY-MM here, deterministically, from `today` — and routes/analytics.js
 * uses this to OVERRIDE whatever the model put in timeRange whenever the
 * question contains one of these phrases, so the model's only job is
 * recognizing that a time filter applies at all, never doing the year math.
 */
const MONTH_NAMES = [
  'january', 'february', 'march', 'april', 'may', 'june',
  'july', 'august', 'september', 'october', 'november', 'december',
];
// Round 5 item 2 (2026-09-21 reviewer NO-GO): the year capture only matched a
// bare "August 2023" — "August of 2023" and "August, 2023" (both real ways an
// owner phrases it) never captured a year at all, so a genuinely-provided
// year was silently dropped. "[\s,]+" swallows any run of spaces/commas
// between the month and the year, and an optional "of " before the digits.
const MONTH_NAME_RE = new RegExp(`\\b(${MONTH_NAMES.join('|')})\\b(?:[\\s,]+(?:of\\s+)?(\\d{4}))?`, 'i');
// R18 P4 (C3, time-window drop): "how many jobs have we done since january 1st" (h065) used to be
// caught by MONTH_NAME_RE below (it matches the bare word "january" anywhere in the sentence,
// "since" or not) and mis-read as a single "in January" MONTH, not a "from January 1st through
// today" RANGE — undercounting even that one misread month. A month name directly preceded by
// "since" names a starting DATE, never a bare single-month reference; resolveQuestionTimeRange
// bails (null) whenever this matches so resolveExtendedTimeRange's own since-month-name handling
// (below) gets it instead, the same day-grain range family "since <year>" already uses.
const SINCE_MONTH_RE = new RegExp(`\\bsince\\s+(${MONTH_NAMES.join('|')})\\b(?:\\s+(\\d{1,2})(?:st|nd|rd|th)?)?`, 'i');

function monthRange(year, month1to12) {
  const ym = `${year}-${String(month1to12).padStart(2, '0')}`;
  return { from: ym, to: ym };
}

/**
 * Resolves "in August" / "in August 2024" / "this month" / "last month" in
 * `question` to an exact {from, to} YYYY-MM timeRange, using `today` (an
 * ISO date/timestamp string) as "now". A bare month name with no year
 * resolves to that month in today's year — unless that month is still in
 * the FUTURE relative to today, in which case it must mean last year's
 * occurrence of it (an owner asking about "August" in March 2026 means
 * August 2025, not a month that hasn't happened yet). Returns null when the
 * question contains none of these phrases — callers then leave the model's
 * own timeRange (if any) untouched.
 */
export function resolveQuestionTimeRange(question, today) {
  const q = String(question ?? '').toLowerCase();
  const now = today ? new Date(today) : new Date();
  if (Number.isNaN(now.getTime())) return null;

  if (/\bthis month\b/.test(q)) return monthRange(now.getUTCFullYear(), now.getUTCMonth() + 1);
  if (/\blast month\b/.test(q)) {
    const m = now.getUTCMonth(); // 0-indexed current month
    return m === 0 ? monthRange(now.getUTCFullYear() - 1, 12) : monthRange(now.getUTCFullYear(), m);
  }
  // R18 P4: "since january 1st" — see SINCE_MONTH_RE's own doc comment; defer to
  // resolveExtendedTimeRange rather than misreading this as a bare month.
  if (SINCE_MONTH_RE.test(q)) return null;

  const m = q.match(MONTH_NAME_RE);
  if (!m) return null;
  const monthNum = MONTH_NAMES.indexOf(m[1].toLowerCase()) + 1;
  if (m[2]) return monthRange(Number(m[2]), monthNum);
  const currentMonth = now.getUTCMonth() + 1;
  const year = monthNum > currentMonth ? now.getUTCFullYear() - 1 : now.getUTCFullYear();
  return monthRange(year, monthNum);
}

/**
 * Live 100-question persona sample (2026-09-22), item 5 "TIME WINDOWS": this
 * week / last week / this quarter / last quarter / year to date|ytd / this
 * year / last year / since <year> / in the last N days|weeks|months / past N
 * ... — none of these are month-name phrases resolveQuestionTimeRange (above)
 * recognizes, and unlike a month they need DAY-grain bounds (a week or a
 * "since 2024" range never lines up on a calendar-month boundary). Kept as a
 * separate function (rather than folded into resolveQuestionTimeRange itself)
 * so that function's existing {from,to}-only return shape — and every eq()
 * test pinned to it — stays byte-for-byte unchanged; resolveAnyTimeRange
 * below is the single combined entry point every caller that needs BOTH
 * families (reconcileTimeRange, detectedConditions, the executor's zero-
 * result/count wording) actually uses.
 *
 * Returns {from, to, label} (day-grain YYYY-MM-DD) or null. `label` is prose
 * for the honest/zero-result wording ("this week", "Q2 2026", "since 2024",
 * "the last 30 days") — see routes/analytics.js's use of it in
 * formatAnalyticsAnswer's opts.
 */
export function resolveExtendedTimeRange(question, today) {
  const q = String(question ?? '').toLowerCase();
  const now = today ? new Date(today) : new Date();
  if (Number.isNaN(now.getTime())) return null;

  const iso = (d) => d.toISOString().slice(0, 10);
  const addDays = (d, n) => {
    const x = new Date(d);
    x.setUTCDate(x.getUTCDate() + n);
    return x;
  };
  const todayISO = iso(now);

  if (/\byear[\s-]?to[\s-]?date\b|\bytd\b/.test(q)) {
    return { from: `${now.getUTCFullYear()}-01-01`, to: todayISO, label: 'year to date' };
  }
  // R18 P4 (C3): "how many units warranty has expired so far this year" (h051) — year START
  // through TODAY, distinct from "this year" (below), which is the full Jan1-Dec31 calendar year
  // regardless of where today falls in it.
  if (/\bso\s+far\s+this\s+year\b/.test(q)) {
    const y = now.getUTCFullYear();
    return { from: `${y}-01-01`, to: todayISO, label: `so far in ${y}` };
  }
  // R18 P4 (C3): "how many warranties expire by the end of this calendar year" (h049) — TODAY
  // through Dec 31, a forward-looking window, distinct from "this year" (below), which also
  // includes everything already past since Jan 1.
  if (/\bby\s+(?:the\s+)?end\s+of\s+(?:this\s+)?(?:calendar\s+)?year\b|\bby\s+year[\s-]?end\b/.test(q)) {
    const y = now.getUTCFullYear();
    return { from: todayISO, to: `${y}-12-31`, label: `by the end of ${y}` };
  }
  // R18 P4 (C3): "how many units had their warranty expire in the past year" (h047) — a bare,
  // numberless "past year" (365 trailing days from today), never confused with the NUMBERED "in
  // the last N years" family (lastNMatch, below) or with "last year"/"this year" (a fixed Jan1-Dec31
  // calendar year) just below.
  if (/\b(?:in\s+the\s+|over\s+the\s+)?past\s+year\b/.test(q) && !/\d+\s*ye?a?rs?\b/.test(q)) {
    return { from: iso(addDays(now, -365)), to: todayISO, label: 'in the past year' };
  }
  // R21 M2 (Cluster 2, j040/j041: "before the summer this year" / "before the summer started this
  // year", j061: "before summer hit this year") — Jan 1 through May 31 of the CURRENT year, always
  // (the generator's own oracle SQL fixes the year as `extract(year from today)` unconditionally,
  // never "next year's summer hasn't happened yet, so use last year's" the way the plain season
  // handling further below does for a bare "this summer") — checked well before the bare "this
  // year"/"last year" checks below, both of which "before the summer this year" would otherwise
  // also satisfy first (it contains "this year" literally), and before seasonMatch's own "summer"
  // alternative, which would give the wrong (in-season, not before-it) range.
  if (/\bbefore\s+(?:the\s+)?summer\b/.test(q)) {
    const y = now.getUTCFullYear();
    return { from: `${y}-01-01`, to: `${y}-05-31`, label: `before summer ${y}` };
  }
  // Reviewer NO-GO (2026-09-22): Monday-anchored, not Sunday-anchored —
  // getUTCDay() is 0=Sunday..6=Saturday, so (getUTCDay()+6)%7 is the number
  // of days since the most recent Monday (0 on a Monday itself, 6 on a
  // Sunday). Verified: today 2026-09-22 (a Tuesday, getUTCDay()=2) -> offset
  // 1 -> this week starts 2026-09-21 (Monday); last week is then
  // 2026-09-14..2026-09-20.
  const mondayOffset = (now.getUTCDay() + 6) % 7;
  if (/\bthis week\b/.test(q)) {
    const start = addDays(now, -mondayOffset);
    return { from: iso(start), to: todayISO, label: 'this week' };
  }
  // R23 (D1, j055: "over the last week, how many service visits have we logged") — same TRAILING-
  // window reading "over the last quarter" already gets just below (a rolling 7 days ending today,
  // not the closed prior Mon-Sun calendar week bare "last week" means) — "over the last week"
  // contains the literal substring "last week", so this must be checked, and must win, BEFORE that
  // bare check. Verified directly against this corpus (scripts/golden/golden-export.json): the
  // closed calendar week for EXAM_TODAY=2026-09-25 (2026-09-14..2026-09-20) has zero visits at all,
  // while the trailing 7 days (2026-09-18..2026-09-25) has exactly the oracle's own expected 27 —
  // the same "over the last N" rolling idiom as "over the last quarter"/bare "past week" elsewhere
  // in this resolver, not the calendar-aligned one.
  if (/\bover\s+the\s+last\s+week\b/.test(q)) {
    return { from: iso(addDays(now, -7)), to: todayISO, label: 'over the last week' };
  }
  if (/\blast week\b/.test(q)) {
    const thisStart = addDays(now, -mondayOffset);
    const lastStart = addDays(thisStart, -7);
    const lastEnd = addDays(thisStart, -1);
    return { from: iso(lastStart), to: iso(lastEnd), label: 'last week' };
  }
  if (/\bthis quarter\b/.test(q)) {
    const qStartMonth = Math.floor(now.getUTCMonth() / 3) * 3;
    const from = `${now.getUTCFullYear()}-${String(qStartMonth + 1).padStart(2, '0')}-01`;
    return { from, to: todayISO, label: `in Q${qStartMonth / 3 + 1} ${now.getUTCFullYear()}` };
  }
  // R21 M2 (Cluster 2, j044/j045: "over the last quarter" / "in the past quarter") — a TRAILING
  // 3-calendar-months window ending today, NOT the same thing as bare "last quarter" just below
  // (the previous full Jan/Apr/Jul/Oct-aligned calendar quarter). "over the last quarter" contains
  // the literal substring "last quarter", so this must be checked, and must win, BEFORE that bare
  // check — the generator's own oracle (field-phrasing-4.json) is unambiguous: `>= today - interval
  // '3 months' AND <= today`, matched here with a calendar-month subtraction (not day-count) so it
  // agrees with Postgres's `interval '3 months'` exactly, including on month-length differences.
  if (/\bover\s+the\s+last\s+quarter\b|\b(?:in\s+the\s+|over\s+the\s+)?past\s+quarter\b/.test(q)) {
    const from = new Date(now);
    from.setUTCMonth(from.getUTCMonth() - 3);
    return { from: iso(from), to: todayISO, label: 'in the past quarter' };
  }
  if (/\blast quarter\b/.test(q)) {
    const curQStart = Math.floor(now.getUTCMonth() / 3) * 3;
    let lastQStart = curQStart - 3;
    let year = now.getUTCFullYear();
    if (lastQStart < 0) {
      lastQStart += 12;
      year -= 1;
    }
    const from = `${year}-${String(lastQStart + 1).padStart(2, '0')}-01`;
    const endMonth = lastQStart + 2; // 0-indexed last month of that quarter
    const to = iso(new Date(Date.UTC(year, endMonth + 1, 0))); // last day of that month
    return { from, to, label: `in Q${lastQStart / 3 + 1} ${year}` };
  }
  if (/\bthis year\b/.test(q)) {
    const y = now.getUTCFullYear();
    return { from: `${y}-01-01`, to: `${y}-12-31`, label: `in ${y}` };
  }
  // R21 M2 (Cluster 2, j042/j043: "since the start of last year" / "since last year began") —
  // OPEN-ENDED from Jan 1 of last year through today (no upper calendar-year bound at all, per the
  // generator's own oracle SQL: `>= make_date(year-1,1,1)` with no `<=`), unlike bare "last year"
  // just below, which is the closed Jan1-Dec31 calendar year one year back. Contains the literal
  // substring "last year", so must be checked first (same trailing-quarter idiom above).
  // nlNormalize.js's fuzzy-correct table (outside this round's file ownership) has no domain entry
  // for "start" and mis-corrects "start" -> "star" (edit distance 1, same false-correction shape
  // its own doc comment documents for "serviced"/"fewest") whenever "of" follows it here, turning
  // "since the start of last year" into "since the star of last year" before this ever runs — `sta\w*`
  // accepts either spelling rather than depending on that fix landing in nlNormalize.js itself.
  // R21 M2 (Cluster 1, C1 — j004/j006/j009/j013/j017/j019 and others): "since last January" is this
  // exam's own paraphrase for the SAME open-ended window as "since the start of last year"/"since
  // last year began" just above — Jan 1 of last calendar year through today (confirmed via every
  // C1 id's identical oracle SQL, `>= make_date(year-1,1,1)`) — NOT the ordinary "since <month
  // name>" reading (SINCE_MONTH_RE, below) a bare "since January" gets, which means the most recent
  // January that has already passed (this year's, unless it hasn't happened yet). Checked first so
  // it never falls through to that bare-month path.
  if (/\bsince\s+last\s+january\b/.test(q)) {
    const y = now.getUTCFullYear() - 1;
    return { from: `${y}-01-01`, to: todayISO, label: `since the start of ${y}` };
  }
  if (/\bsince\s+(?:the\s+sta\w*\s+of\s+)?last\s+year(?:\s+began)?\b/.test(q)) {
    const y = now.getUTCFullYear() - 1;
    return { from: `${y}-01-01`, to: todayISO, label: `since the start of ${y}` };
  }
  if (/\blast year\b/.test(q)) {
    const y = now.getUTCFullYear() - 1;
    return { from: `${y}-01-01`, to: `${y}-12-31`, label: `in ${y}` };
  }
  const sinceMatch = q.match(/\bsince\s+(\d{4})\b/);
  if (sinceMatch) {
    return { from: `${sinceMatch[1]}-01-01`, to: todayISO, label: `since ${sinceMatch[1]}` };
  }
  // R21 M2 (Cluster 2, j046/j047 "within the past 5 years"/"in the last 5 years", j050/j051
  // "within the past 2 years"/"in the last 2 years"): the unit list had no "year(s)" at all (only
  // day/week/month), and no "within"/"within the past"/"within the last" prefix — either gap sent
  // these straight past this whole resolver to a fallback with no date filter at all. Both added
  // here rather than as a second function so every caller of this one resolver gets them for free.
  // R21 M2 (i093 regression guard): the bare "within" prefix must NOT match "within N days OF
  // <an event>" ("within 30 days of the install date", "within 14 days of a previous visit") —
  // that names a gap between two dates on the SAME record/pair of records (warrantyRegistrationDays,
  // CROSS_VISIT_RELATION_RE's own territory), never a window measured back from TODAY. Only "within
  // the last/past N <unit>" (no trailing "of ...") is a today-relative window; a bare "within N
  // <unit>" immediately followed by "of" is excluded via the negative lookahead so this resolver
  // never invents a spurious {from,to} for a question a dedicated same-record detector already owns.
  // R23 (D1, fp-5 k151/k155: "in the past six months, how many jobs have we been out on", "in the
  // last two weeks, how many jobs have we logged") — the number was digits-only, so a spelled-out
  // small number fell through this whole resolver with NO date filter at all, silently returning
  // the all-time total instead of either the intended window or a graceful defer-to-model — a
  // confident-wrong answer, not a safe miss. WORD_TO_N covers the range a dispatcher would plausibly
  // spell out in speech (one..twelve); anything larger is realistically always typed as a digit.
  const WORD_TO_N = { one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10, eleven: 11, twelve: 12 };
  const lastNMatch = q.match(
    /\b(?:within\s+the\s+last|within\s+the\s+past|within|in\s+the\s+last|last|past)\s+(\d+|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve)\s+(day|days|week|weeks|month|months|year|years)\b(?!\s+of\b)/
  );
  if (lastNMatch) {
    const n = /^\d+$/.test(lastNMatch[1]) ? Number(lastNMatch[1]) : WORD_TO_N[lastNMatch[1]];
    const unit = lastNMatch[2];
    let fromDate;
    let unitLabel;
    if (unit.startsWith('day')) {
      fromDate = addDays(now, -n);
      unitLabel = 'day';
    } else if (unit.startsWith('week')) {
      fromDate = addDays(now, -n * 7);
      unitLabel = 'week';
    } else if (unit.startsWith('month')) {
      fromDate = new Date(now);
      fromDate.setUTCMonth(fromDate.getUTCMonth() - n);
      unitLabel = 'month';
    } else {
      fromDate = new Date(now);
      fromDate.setUTCFullYear(fromDate.getUTCFullYear() - n);
      unitLabel = 'year';
    }
    return { from: iso(fromDate), to: todayISO, label: `in the last ${n} ${unitLabel}${n === 1 ? '' : 's'}` };
  }
  // R21 M2 (Cluster 2, j054: "how many jobs have we been out on in the past week") — a bare,
  // numberless "past week" (trailing 7 days from today), same idiom as the numberless "past year"
  // handling above; guarded off any NUMBERED "past N weeks" (already lastNMatch's job, checked
  // first) so this never double-fires.
  if (/\b(?:in\s+the\s+|over\s+the\s+)?past\s+week\b/.test(q) && !/\d+\s*weeks?\b/.test(q)) {
    return { from: iso(addDays(now, -7)), to: todayISO, label: 'in the past week' };
  }
  // R18 P4 (C3): "any warranties expiring in the next 90 days" (h048) — the forward-looking
  // mirror of lastNMatch just above (TODAY forward, not TODAY backward).
  const nextNMatch = q.match(/\b(?:in\s+the\s+next|next)\s+(\d+)\s+(day|days|week|weeks|month|months)\b/);
  if (nextNMatch) {
    const n = Number(nextNMatch[1]);
    const unit = nextNMatch[2];
    let toDate;
    let unitLabel;
    if (unit.startsWith('day')) {
      toDate = addDays(now, n);
      unitLabel = 'day';
    } else if (unit.startsWith('week')) {
      toDate = addDays(now, n * 7);
      unitLabel = 'week';
    } else {
      toDate = new Date(now);
      toDate.setUTCMonth(toDate.getUTCMonth() + n);
      unitLabel = 'month';
    }
    return { from: todayISO, to: iso(toDate), label: `in the next ${n} ${unitLabel}${n === 1 ? '' : 's'}` };
  }
  // R18 P4 (C3): "how many jobs have we done since january 1st" (h065) — a month name right after
  // "since" names a starting DATE (see SINCE_MONTH_RE's own doc comment, above
  // resolveQuestionTimeRange), never a bare month reference. No day given defaults to the 1st (the
  // common "since <month>" == "since the start of <month>" reading); a date that would fall in the
  // future means last year's occurrence, not one that hasn't happened yet (same rule
  // resolveQuestionTimeRange's own bare-month-name handling already follows).
  const sinceMonthMatch = q.match(SINCE_MONTH_RE);
  if (sinceMonthMatch) {
    const monthNum = MONTH_NAMES.indexOf(sinceMonthMatch[1].toLowerCase()) + 1;
    const day = sinceMonthMatch[2] ? Number(sinceMonthMatch[2]) : 1;
    let year = now.getUTCFullYear();
    let from = new Date(Date.UTC(year, monthNum - 1, day));
    if (from.getTime() > now.getTime()) {
      year -= 1;
      from = new Date(Date.UTC(year, monthNum - 1, day));
    }
    return { from: iso(from), to: todayISO, label: `since ${sinceMonthMatch[1]} ${day}` };
  }
  // R18 P4 (C3): "how many service visits did we log this past summer" (h067) / "how many jobs
  // have we done this spring" (h069) — a season word resolves to its 3-month calendar range.
  // `referenceYear` picks the most recent occurrence of that season that isn't still in the
  // future: if the season's own end month has already passed (or the season is the one we're
  // currently in), it's THIS year's occurrence; otherwise it's last year's (the same "don't name a
  // month/season that hasn't happened yet" rule resolveQuestionTimeRange's bare-month handling
  // already follows). Winter's cross-year span (Dec of one year into Feb of the next) is handled by
  // anchoring `referenceYear` to the FEBRUARY end, same idea, just with the start month a year
  // earlier — not exercised by any known question today, so treat as best-effort.
  const SEASON_MONTHS = { winter: [12, 1, 2], spring: [3, 4, 5], summer: [6, 7, 8], fall: [9, 10, 11], autumn: [9, 10, 11] };
  const seasonMatch = q.match(/\b(?:this\s+past|this|last|past)\s+(winter|spring|summer|fall|autumn)\b/);
  if (seasonMatch) {
    const months = SEASON_MONTHS[seasonMatch[1].toLowerCase()];
    const isWinter = months[0] === 12;
    const currentMonth = now.getUTCMonth() + 1;
    const currentYear = now.getUTCFullYear();
    const endMonth = months[months.length - 1];
    const inSeasonNow = isWinter ? (currentMonth === 12 || currentMonth <= 2) : months.includes(currentMonth);
    let referenceYear = currentYear;
    if (!inSeasonNow && endMonth > currentMonth) referenceYear = currentYear - 1;
    const startYear = isWinter ? referenceYear - 1 : referenceYear;
    const from = `${startYear}-${String(months[0]).padStart(2, '0')}-01`;
    const lastDay = new Date(Date.UTC(referenceYear, endMonth, 0)).getUTCDate();
    const to = `${referenceYear}-${String(endMonth).padStart(2, '0')}-${String(lastDay).padStart(2, '0')}`;
    return { from, to, label: seasonMatch[0] };
  }
  return null;
}

/** Combined entry point: resolveQuestionTimeRange's own month-name/this-
 *  month/last-month families first (labeled via monthRangeLabel, defined
 *  further below — forward-referenced here since it's a plain function
 *  declaration, hoisted), then resolveExtendedTimeRange's day-grain families.
 *  Returns {from, to, label} or null. Used wherever BOTH families need to be
 *  recognized as one capability (reconcileTimeRange, detectedConditions'
 *  own 'month' bit, and the executor's count/zero-result wording) — never by
 *  validatePlan, which only ever sees the stripped {from,to} a caller pulls
 *  out of this. */
export function resolveAnyTimeRange(question, today) {
  // R34: calendar spans (specific day, Q1 2026, the 2010s, between/before/after <year>, bare "in 2020", abbreviated month + year)
  // that no family below recognized and so silently dropped the window - see timeSpans.js.
  const span = resolveCalendarSpan(question, today);
  if (span && !span.invalid) return span;
  // R21 M2 (Cluster 1/C1): "since last January" must resolve to the OPEN-ENDED "since the start of
  // last year" window (see resolveExtendedTimeRange's own "since last january" case, just below),
  // never resolveQuestionTimeRange's own plain month-name reading of "last January" (a single
  // closed month, the most recent January that's passed — the right reading for a bare "last
  // January" with no "since", but wrong here: this exam's own oracle SQL is identical for "since
  // last January" and "since the start of last year"). Checked first, narrowly, so no OTHER
  // "since <month>"/bare month-name phrasing is affected.
  if (/\bsince\s+last\s+january\b/i.test(String(question ?? ''))) {
    return resolveExtendedTimeRange(question, today);
  }
  const base = resolveQuestionTimeRange(question, today);
  if (base) return { from: base.from, to: base.to, label: monthRangeLabel(base) };
  return resolveExtendedTimeRange(question, today);
}

const VALID_TIME_PART_RE = /^\d{4}(-\d{2}(-\d{2})?)?$/;

/**
 * Round 5 item 2: decides whether the model's own `timeRange` (raw tool_use
 * input, pre-validation) should be trusted as-is, or overridden by
 * resolveQuestionTimeRange's deterministic reading of the question text. The
 * model's timeRange wins ONLY when it is well-formed AND names a year that is
 * actually written in the question — i.e. the model read something real off
 * the page that our simple month-name regex has no way to know about (a plan
 * combining a month with a non-current year the question explicitly gave).
 * Every other case (the question names no year at all, or the model's
 * timeRange is malformed/missing) defers to the deterministic override,
 * exactly as before — see resolveQuestionTimeRange's own doc comment for why
 * the model's date math is not trusted by default. Pure, so this is testable
 * with no model call — see routes/analytics.js's planAnalyticsQuestion for
 * where the raw tool_use input is actually produced.
 */
export function reconcileTimeRange(rawTimeRange, question, today) {
  // resolveAnyTimeRange (item 5, 2026-09-22) also recognizes this week/last
  // week/this quarter/last quarter/YTD/this year/last year/since <year>/the
  // last N days|weeks|months, on top of resolveQuestionTimeRange's original
  // month-name families — only {from,to} is ever kept here (never `label`,
  // which validatePlan would strip anyway; see resolveAnyTimeRange's own
  // doc comment for who actually reads `label`).
  const overrideFull = resolveAnyTimeRange(question, today);
  const override = overrideFull ? { from: overrideFull.from, to: overrideFull.to } : null;
  if (!override) return rawTimeRange ?? undefined;

  const from = String(rawTimeRange?.from ?? '');
  const validShape =
    rawTimeRange &&
    typeof rawTimeRange === 'object' &&
    VALID_TIME_PART_RE.test(from) &&
    (rawTimeRange.to == null || VALID_TIME_PART_RE.test(String(rawTimeRange.to)));
  const yearMatch = /^(\d{4})/.exec(from);
  const yearInQuestion = yearMatch && new RegExp(`\\b${yearMatch[1]}\\b`).test(String(question ?? ''));
  if (validShape && yearInQuestion) return rawTimeRange;
  return override;
}

/**
 * Live miss (2026-09-21): the owner asked Donovan live "which units had
 * services this month" and got no usable answer. Root cause: entity choice
 * for a "did this get serviced" question was left entirely to the model —
 * exactly the kind of judgment call resolveQuestionTimeRange (above) already
 * refuses to leave to the model for DATES, for the same reason. `equipment`/
 * `customers` carry no service_date column at all, so a plan that picked
 * either one either got rejected downstream (no matching filter/column) or,
 * worse, silently ignored the timeRange and answered with EVERY row — the
 * data itself doesn't matter here; the entity choice must never depend on
 * the model getting it right. `serviceVisits` (backed by the
 * extractions.field_key = 'service_date' rows — see buildAnalyticsSQL) is
 * the ONLY entity whose rows are actually keyed by when the work happened, so
 * any question shaped like "<units/equipment/customers/...> <had/got/were/
 * received> service(d)" or "<did/do> we service" or naming "service call(s)"
 * outright is forced to entity 'serviceVisits' regardless of what the model
 * returned — see planAnalyticsQuestion (routes/analytics.js), which applies
 * this the same way it applies reconcileTimeRange, before validatePlan ever
 * runs. `service(?:d)?` (not just "service") so this still matches whether or
 * not nlNormalize's fuzzy-typo pass "corrects" a genuine "serviced" back to
 * "service" first (see EXTRA_DOMAIN_WORDS in nlNormalize.js, which now keeps
 * "serviced" in the vocabulary so that correction stops happening at all —
 * this regex is written to not depend on either behavior).
 */
const SERVICE_VISITS_OVERRIDE_RE =
  /\b(?:had|got|were|received)\s+service(?:d|s)?\b|\b(?:did|do)\s+we\s+service\b|\bwe\s+service(?:d)?\b|\bservice\s+calls?\b/i;

// R23 (D2, k186): "which manufacturers do we service, across every unit on the books" — the SAME
// "do we service" = "cover"/"work on" ambiguity GEO_WORD_RE's own doc comment just below already
// documents for a place name ("do we service Nevada"), just for the DIMENSION itself (which
// manufacturers/technicians do we service/cover) rather than a location. Scoped to the bare
// dimension noun only ("manufacturer(s)"/"brand(s)"/"technician(s)"/"tech(s)") — a SPECIFIC brand
// NAME (BRAND_RE's own Trane/Carrier/... vocabulary) still means a real, time-scoped service visit
// ("which Trane units did we service this month", SERVICE_VISITS_LIVE_MISSES' own pinned shape) and
// is deliberately left alone.
const COVERAGE_DIMENSION_WORD_RE = /\b(?:manufacturers?|brands?|technicians?|techs?)\b/i;

/** True for any question this session's live-miss cluster named — exported
 *  so scripts/verify-analytics.mjs can pin the exact shapes down directly.
 *
 *  Round 15 (A) BUG FIX ("do we service anything in Nevada" answered "You
 *  have 317 service visits." — coverage, not existence): "do/did we service"
 *  is ALSO the ordinary English verb for "cover this area" ("do we service
 *  Nevada", "do we service anything out there"), a genuine coverage/existence
 *  question about CUSTOMERS, never a service-VISIT event — and serviceVisits
 *  has no geo dimension at all (ENTITY_SUPPORTED_FIELDS, routes/analytics.js)
 *  to honor a location this shape names anyway. A state/city/county/zip word
 *  right there in the question is the deciding signal: every one of the
 *  SERVICE_VISITS_LIVE_MISSES phrasings this override exists for names a
 *  TIME window or a unit/customer, never a place, so excluding a geo-bearing
 *  sentence here costs that cluster nothing. */
export function isServiceVisitsQuestion(question) {
  const q = String(question ?? '');
  if (!SERVICE_VISITS_OVERRIDE_RE.test(q)) return false;
  if (GEO_WORD_RE.test(q) || ZIP_VALUE_RE.test(q) || ZIP_CODE_WORD_RE.test(q)) return false;
  if (COVERAGE_DIMENSION_WORD_RE.test(q)) return false;
  return true;
}

/**
 * The forced {entity, op} for a question isServiceVisitsQuestion recognizes,
 * or null. `op` is 'count' for a "how many" question, 'list' for every other
 * phrasing ("which"/"what"/"list ...") — the same count-vs-list distinction
 * every other entity already gets from the model, just decided deterministically
 * here instead of trusted from the model's own `op` choice, for the same
 * "never depend on the model getting it right" reason the entity itself is
 * forced. Never returns filters/timeRange — planAnalyticsQuestion layers
 * reconcileTimeRange's own deterministic timeRange on top of this separately,
 * and drops whatever filters the model may have guessed (this shape's 7 known
 * phrasings never need one).
 */
export function resolveServiceVisitsOverride(question) {
  if (!isServiceVisitsQuestion(question)) return null;
  // Round 15 (A): "did we do any service calls last month" is existence-
  // shaped (isExistenceQuestion, below — hoisted), not a request to enumerate
  // rows; forcing 'count' here (same as an explicit "how many") lets
  // formatAnalyticsAnswer's plain count branch produce a numeric fact that
  // R7's own existenceWrap (routes/analytics.js's applyExistenceShape) can
  // read, and its zero-result serviceVisits branch already leads with a
  // literal "No ..." either way — never a bare, unlabelled row list for a
  // yes/no question.
  const q = String(question ?? '');
  const op = /\bhow many\b/i.test(q) || isExistenceQuestion(q) ? 'count' : 'list';
  return { entity: 'serviceVisits', op };
}

/**
 * "older than 10 years" / "newer than 5 years old" / "units over 15 years old" / "between 10 and
 * 15 years old" -> an age-threshold filter computed HERE from today's date, never by the model
 * (Team A, 2026-09-24: "how many customers have a unit newer than 5 years old" answered 10 where
 * the units installed since 2021 gave 18 — the planner did its own year arithmetic and disagreed
 * with itself on the boundary).
 *
 * R21 M2 (Cluster 3, j141-j144) attempted a day-precise installDate rewrite here (`installDate <=
 * today - N years`, matching field-phrasing-4.json's own oracle SQL for "over/under N years old")
 * — REVERTED after it regressed 17+ previously-correct, long-pinned ids across exam.json
 * (counts-age-0003/0004, hvac-owner-0001/0002/0026/0027/0035/0080, breadth-multi-hop-001-004/020/024,
 * breadth-existence-018, breadth-persona-011): every one of THOSE oracles instead computes a bare
 * CALENDAR-YEAR cutoff (`installYear < thisYear - N`, verified directly against their own oracle SQL
 * — see e.g. counts-age-0003-canonical/hvac-owner-0035-canonical), including several that ALSO use
 * "over/under N years old" phrasing with no "than" at all (hvac-owner-0035) — so the two conventions
 * cannot be told apart by wording; they are simply two different exam-generation rounds' oracles that
 * disagree on the same real-world phrasing. field-phrasing-4.json's own C5 cluster is documented as a
 * MEASURED FLOOR, not a target (r21_blind4_clusters.json), while the exam.json ids are the corpus's
 * long-standing, load-bearing majority convention — so year-based (matching 17+ pinned ids) is kept
 * as the single-threshold behavior, and j141/j142/j143 (which want the day-precise reading) are left
 * as an acknowledged, unresolvable-without-textual-signal gap rather than risking a new regression.
 * The "between X and Y years old" shape (AGE_BETWEEN_RE, below) has no such conflict — no ORIGINAL
 * exam.json id uses it at all — so it keeps the day-precise installDate reading (j144's own oracle),
 * a pure addition with zero regression risk.
 *   older/over N years   -> installYear <  (thisYear - N)
 *   newer/under N years  -> installYear >= (thisYear - N)
 *   between X and Y years (X < Y) -> installDate <= (today - X years) AND installDate > (today - Y years)
 * Returns {field, op, value}, an array of two such filters (the "between" shape), or null. Callers
 * replace any installYear/installDate filter the model produced with this (routes/analytics.js).
 */
// Round 14 (K3): "order" is deliberately accepted as the SAME word as
// "older" here — nlNormalize.js's own general fuzzy-typo corrector (VOCAB,
// built from ENTITY_SYNONYMS' own "purchase order(s)" phrase) silently
// mangles a genuine "older than 10 years" into "order than 10 years" before
// this ever runs (edit distance 1: o-l-d-e-r vs o-r-d-e-r), for EVERY caller
// of resolveAgeFilter — model-planned or deterministic alike, since both
// read the same already-normalized question text. Rather than special-case
// this in nlNormalize.js's own general vocabulary (outside this round's
// file ownership), "order" is accepted here as one more spelling of
// "older" — the same "duplicate the small fix locally" idiom this file
// already uses for typo'd trigger words elsewhere (see e.g.
// SINGULAR_NAMED_RECORD_RE's own "instbll"/"mainttenance" alternatives).
// Round 14 (K3): "than" is now optional ("over 10 years old" names the same
// condition as "older than 10 years" with no "than" at all), and "over"/
// "under" are accepted as one more spelling of "older"/"newer" respectively —
// the same real English paraphrase resolveAgeFilter already treats
// "older"/"order" as. Also fixes a pre-existing bug: "younger than N years"
// was falling into the OLDER branch below (only the literal word "newer" was
// ever checked), giving the exact opposite of the asked-for direction.
// "ye+ars?" (one-or-more e) rather than a plain "years?" tolerates a doubled-
// vowel typo ("yeears") the same general way — never hardcoded to this one
// exam spelling, just the shape of a repeated-letter slip.
// "yeasr" (a transposed-last-two-letters typo of "years") tolerated the same
// general way as "yeears" above — one more shape of the same common slip.
const AGE_THAN_RE = /\b(older|order|over|newer|younger|under)\s+(?:than\s+)?(\d{1,2})\s*(?:ye+a(?:rs?|sr)|yrs?)(?:\s+old)?\b/i;
// R21 M2 (Cluster 3, j144): "between 10 and 15 years old" — checked BEFORE AGE_THAN_RE since it
// contains no older/newer/over/under direction word at all and would otherwise match nothing.
const AGE_BETWEEN_RE = /\bbetween\s+(\d{1,2})\s+and\s+(\d{1,2})\s*(?:ye+a(?:rs?|sr)|yrs?)(?:\s+old)?\b/i;
const NEWER_DIRECTION_WORDS = new Set(['newer', 'younger', 'under']);

function ageCutoffISO(now, years) {
  const d = new Date(now);
  d.setUTCFullYear(d.getUTCFullYear() - years);
  return d.toISOString().slice(0, 10);
}

export function resolveAgeFilter(question, today) {
  const q = String(question ?? '');
  const now = today ? new Date(today) : new Date();
  if (Number.isNaN(now.getTime())) return null;
  const between = AGE_BETWEEN_RE.exec(q);
  if (between) {
    const lo = Number(between[1]);
    const hi = Number(between[2]);
    const [younger, older] = lo <= hi ? [lo, hi] : [hi, lo];
    return [
      { field: 'installDate', op: 'lte', value: ageCutoffISO(now, younger) },
      { field: 'installDate', op: 'gt', value: ageCutoffISO(now, older) },
    ];
  }
  const m = AGE_THAN_RE.exec(q);
  if (!m) return null;
  // R32 (owner decision 2026-09-30, ADJUDICATION.md "R32"): exact-date age everywhere. "older/over N years" = installed on or
  // before today - N years; "newer/under N years" = installed after it. A year-only / year-month install date is compared
  // conservatively by matchesFilter (never guessed into a day). Supersedes the R21 calendar-year reading.
  const cutoff = ageCutoffISO(now, Number(m[2]));
  return NEWER_DIRECTION_WORDS.has(m[1].toLowerCase())
    ? { field: 'installDate', op: 'gt', value: cutoff }
    : { field: 'installDate', op: 'lte', value: cutoff };
}

/** "August 2026" from a validated plan's {from: '2026-08', to: '2026-08'} —
 *  used to word a count answer as "N jobs in August 2026" (item 1) instead of
 *  a bare "You have N jobs.". Only fires for a single-month range (from ===
 *  to); a genuine multi-month range ("since 2024") gets no such label and
 *  falls back to the plain count wording. */
const MONTH_LABELS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];
export function monthRangeLabel(timeRange) {
  if (!timeRange?.from || timeRange.from !== timeRange.to) return null;
  const m = /^(\d{4})-(\d{2})$/.exec(timeRange.from);
  if (!m) return null;
  const idx = Number(m[2]) - 1;
  if (idx < 0 || idx > 11) return null;
  return `${MONTH_LABELS[idx]} ${m[1]}`;
}

/** True when a timeRange's bounds are full YYYY-MM-DD dates (item 5's
 *  extended windows) rather than the original YYYY-MM month-grain shape —
 *  the executor (routes/analytics.js) uses this to decide whether to compare
 *  a row's exact date or its truncated month against the range. */
export function timeRangeIsDayGrain(timeRange) {
  const s = String(timeRange?.from ?? timeRange?.to ?? '');
  return /^\d{4}-\d{2}-\d{2}$/.test(s);
}

/**
 * Item 5: day-grain windows (this week, since 2024, the last 30 days, ...)
 * need the row's own exact date compared against the range, never its
 * truncated month — comparing '2026-09-10' against a month-grain '2026-09'
 * bound already works (documents/serviceVisits' existing month filtering),
 * but a WEEK-grain range needs day precision or every day in the month would
 * wrongly match. `row` is {date, month} — date is the row's own YYYY-MM-DD
 * (or null if never extracted), month its YYYY-MM truncation.
 */
export function withinTimeRange(row, timeRange) {
  if (!timeRange) return true;
  if (timeRangeIsDayGrain(timeRange)) {
    const d = row?.date ?? null;
    if (!d) return false;
    if (timeRange.from && d < timeRange.from) return false;
    if (timeRange.to && d > timeRange.to) return false;
    return true;
  }
  const m = row?.month ?? '';
  if (timeRange.from && m < timeRange.from.slice(0, 7)) return false;
  if (timeRange.to && m > timeRange.to.slice(0, 7)) return false;
  return true;
}

/**
 * Validate + normalize the model's raw tool_use input against the closed
 * vocabulary. Returns a clean plan object, or null if ANYTHING is outside the
 * vocabulary — the whole plan is rejected rather than silently dropping one
 * bad filter, because a silently-dropped filter changes what question is
 * actually being answered without anyone knowing.
 */
export function validatePlan(raw) {
  const p = raw && typeof raw === 'object' ? raw : null;
  if (!p) return null;
  if (!ENTITIES.includes(p.entity)) return null;
  if (!OPS.includes(p.op)) return null;
  if (p.op === 'groupBy' && !GROUP_BY_FIELDS.includes(p.groupBy)) return null;
  const groupBy = p.op === 'groupBy' ? p.groupBy : undefined;

  const rawFilters = Array.isArray(p.filters) ? p.filters : [];
  const filters = [];
  for (const f of rawFilters) {
    if (!f || typeof f !== 'object') return null;
    if (!FILTER_FIELDS.includes(f.field)) return null;
    if (!FILTER_OPS.includes(f.op)) return null;
    if (f.value === undefined || f.value === null || f.value === '') return null;
    if (f.op === 'in' && !Array.isArray(f.value)) return null;
    if (f.field === 'warrantyStatus' && !WARRANTY_STATUSES.includes(String(f.value).toLowerCase())) return null;
    if (BOOLEAN_FILTER_FIELDS.includes(f.field)) {
      // hasEmail/hasPhone: customers-only, boolean-only, op "eq" only — a
      // closed enough shape that "in"/"gt"/etc make no sense and are rejected
      // rather than silently coerced. Accepts true/false or the strings
      // "true"/"false" (Haiku's tool_use JSON occasionally stringifies a
      // boolean argument) and normalizes to a real boolean either way.
      if (p.entity !== 'customers' || f.op !== 'eq') return null;
      const s = String(f.value).toLowerCase();
      if (f.value !== true && f.value !== false && s !== 'true' && s !== 'false') return null;
      filters.push({ field: f.field, op: f.op, value: f.value === true || s === 'true' });
      continue;
    }
    if (DOC_TYPE_FILTER_FIELDS.includes(f.field)) {
      // hasDocType/lacksDocType: customers-only, op "eq" only, value a real
      // canonical document type id — see this constant's own doc comment.
      if (p.entity !== 'customers' || f.op !== 'eq') return null;
      if (!DOCUMENT_TYPE_IDS.has(String(f.value))) return null;
      filters.push({ field: f.field, op: f.op, value: String(f.value) });
      continue;
    }
    if (SERVICE_TYPE_FILTER_FIELDS.includes(f.field)) {
      // hasServiceType/lacksServiceType (R18 P4, C2/C4): customers-only, op "eq" only, value one
      // of SERVICE_TYPE_VALUES — same closed shape as hasDocType/lacksDocType above, just against
      // extractions.service_type instead of documents.document_type. Case-insensitive match,
      // stored in its own canonical casing (a model or detector might hand back "repair"
      // lowercased).
      // R21 M2 (Cluster 1/C1): 'equipment' added alongside 'customers' — detectBrandCityServiceTypeSince
      // (detPlan.js) is the only producer of an equipment-entity hasServiceType filter (never the
      // model; ANALYTICS_TOOL's schema has no such property for entity 'equipment'), matching the
      // oracle's own per-UNIT count for that shape rather than the per-customer one.
      // R32: 'serviceVisits' too — a visit's OWN service_type (buildAnalyticsSQL's serviceVisits branch carries it; routes/analytics.js's
      // ENTITY_SUPPORTED_FIELDS.serviceVisits already whitelists it). Without this a typed visit count could never validate.
      if ((p.entity !== 'customers' && p.entity !== 'equipment' && p.entity !== 'serviceVisits') || f.op !== 'eq') return null;
      const canonical = SERVICE_TYPE_VALUES.find((v) => v.toLowerCase() === String(f.value).toLowerCase());
      if (!canonical) return null;
      filters.push({ field: f.field, op: f.op, value: canonical });
      continue;
    }
    if (DATA_QUALITY_BOOLEAN_FIELDS.includes(f.field)) {
      // Round 15 (A): boolean-only, op "eq" only, entity restricted per
      // DATA_QUALITY_FIELD_ENTITY (one entity, or one of a short allowed
      // list) — same closed shape as hasEmail/hasPhone above, just not
      // hard-coded to customers.
      const allowed = DATA_QUALITY_FIELD_ENTITY[f.field];
      const entityOk = Array.isArray(allowed) ? allowed.includes(p.entity) : allowed === p.entity;
      if (!entityOk || f.op !== 'eq') return null;
      const s = String(f.value).toLowerCase();
      if (f.value !== true && f.value !== false && s !== 'true' && s !== 'false') return null;
      filters.push({ field: f.field, op: f.op, value: f.value === true || s === 'true' });
      continue;
    }
    if (f.field === 'permitScope' || f.field === 'permitCity') {
      if (p.entity !== 'documents' || f.op !== 'eq' || typeof f.value !== 'string') return null;
      if (f.field === 'permitScope' && !['commercial', 'residential'].includes(f.value)) return null;
      filters.push({ field: f.field, op: f.op, value: f.value });
      continue;
    }
    if (f.field === 'agreementEnd') {
      // D4: the end DATE of a maintenance agreement's term (YYYY-MM-DD); documents only; direction-ful comparisons only.
      if (p.entity !== 'documents' || !['eq', 'gte', 'lte', 'gt', 'lt'].includes(f.op) || !/^\d{4}-\d{2}-\d{2}$/.test(String(f.value))) return null;
      filters.push({ field: f.field, op: f.op, value: String(f.value) });
      continue;
    }
    if (f.field === 'warrantyExpires') {
      // R18 P4 (C3): a raw YYYY-MM-DD (or YYYY-MM/YYYY) date-range test on the unit's own
      // warranty.expires — equipment/warranties only, gte/lte/eq only (a direction-less
      // date comparison; "in"/"contains" make no sense for a single date bound).
      if ((p.entity !== 'equipment' && p.entity !== 'warranties') || !['gte', 'lte', 'eq'].includes(f.op)) return null;
      if (!/^\d{4}(-\d{2}(-\d{2})?)?$/.test(String(f.value))) return null;
      filters.push({ field: f.field, op: f.op, value: String(f.value) });
      continue;
    }
    filters.push({ field: f.field, op: f.op, value: f.value });
  }

  let timeRange;
  if (p.timeRange && typeof p.timeRange === 'object') {
    const { from, to } = p.timeRange;
    const okFrom = from == null || /^\d{4}(-\d{2}(-\d{2})?)?$/.test(String(from));
    const okTo = to == null || /^\d{4}(-\d{2}(-\d{2})?)?$/.test(String(to));
    if (!okFrom || !okTo) return null;
    if (from || to) timeRange = { from: from ?? null, to: to ?? null };
  }

  let limit = DEFAULT_LIMIT;
  if (p.limit != null) {
    const n = Number(p.limit);
    if (!Number.isFinite(n) || n < 1) return null;
    limit = Math.min(Math.trunc(n), MAX_LIMIT);
  }

  // "who's our biggest customer" (round 4, item 1) — only meaningful for
  // customers/list; an out-of-vocabulary value rejects the WHOLE plan, same
  // as any other field. Always caps to TOP_CUSTOMERS_LIMIT regardless of any
  // `limit` the model also set — "top 10" is what was asked, not "top 500".
  let sortBy;
  if (p.sortBy != null) {
    if (INSTALL_DATE_SORT_FIELDS.includes(p.sortBy)) {
      // g133/g138: equipment ranked by installation_date — same "only
      // meaningful for one entity+op combo" gate as the customers case
      // below, just for 'equipment'/'list' instead of 'customers'/'list'.
      if (p.entity !== 'equipment' || p.op !== 'list') return null;
      sortBy = p.sortBy;
      limit = Math.min(limit, INSTALL_DATE_EXTREME_LIMIT);
    } else if (WARRANTY_REG_DATE_SORT_FIELDS.includes(p.sortBy)) {
      if (p.entity !== 'equipment' || p.op !== 'list') return null;
      sortBy = p.sortBy;
      limit = Math.min(limit, INSTALL_DATE_EXTREME_LIMIT);
    } else if (SORT_FIELDS.includes(p.sortBy)) {
      if (p.entity !== 'customers' || p.op !== 'list') return null;
      sortBy = p.sortBy;
      limit = Math.min(limit, TOP_CUSTOMERS_LIMIT);
    } else {
      return null;
    }
  }

  // Team A: which date a documents time window is about — set by code from the question wording (never the model).
  const dateBasis = p.dateBasis === 'uploaded' || p.dateBasis === 'service' ? p.dateBasis : undefined;

  // Round 14 (K3): "how many different zip codes do we cover" — a groupBy
  // plan's DISTINCT group-value count, never the per-group breakdown a plain
  // groupBy answers with (see formatAnalyticsAnswer's own use of this flag).
  // Never set by the model (ANALYTICS_TOOL's schema has no such property, so
  // the model's own tool_use JSON can never carry it) — only detPlan.js's
  // detectDistinctDimensionCount produces this, code-side, the same way
  // dateBasis above is code-side-only.
  const countDistinct = p.countDistinct === true && p.op === 'groupBy' ? true : undefined;

  // R19 (I2, h112/h113/h115): "the biggest city" / "the fewest units" — same code-side-only
  // convention as countDistinct just above (ANALYTICS_TOOL's schema has no such property, so a
  // model plan can never carry this; only detPlan.js's detectGroupBySuperlative sets it).
  const superlative = (p.superlative === 'top' || p.superlative === 'bottom') && p.op === 'groupBy' ? p.superlative : undefined;

  // R21 M2 (Cluster 3, j148/j149 "how old is the oldest/newest unit ... in years"): same code-side-
  // only convention as countDistinct/superlative above — only detPlan.js's detectInstallDateExtreme
  // sets this, and only alongside a real installDateAsc/Desc sortBy.
  const ageInYears = p.ageInYears === true && INSTALL_DATE_SORT_FIELDS.includes(sortBy) ? true : undefined;

  // R23 (D2, k186/k187): "which manufacturers do we service" / "list every technician ... in the
  // system" — the DIMENSION's own distinct VALUES, printed as a plain list (never the per-group
  // counts a bare groupBy answers with, and never just the single number countDistinct answers
  // with) — see formatAnalyticsAnswer's own use of this flag. Same code-side-only convention as
  // countDistinct/superlative above (ANALYTICS_TOOL's schema has no such property) — only
  // detPlan.js's detectDistinctDimensionList sets this.
  const distinctList = p.distinctList === true && p.op === 'groupBy' ? true : undefined;

  // R23 (D2, k139): "has Denise Ford done more jobs than Ray Sutton" — a technician HEAD-TO-HEAD
  // yes/no comparison, resolved via the SAME plain per-technician 'count' plan/execution path a
  // single named technician already uses (routes/analytics.js's own dateless-technician-row
  // correction only ever applies when the plan is NOT a groupBy and DOES carry a `technician`
  // filter — exactly this shape — so both sides count the same way the individually-passing
  // per-technician totals do, never the groupBy/superlative join that h115/k141 document as
  // undercounting some technicians). Same code-side-only convention as the flags above — only
  // detPlan.js's detectTechnicianHeadToHead sets this, and only alongside a real 'in' filter naming
  // exactly those two technicians.
  let headToHead;
  if (p.headToHead && typeof p.headToHead === 'object' && p.op === 'count' && p.entity === 'serviceVisits') {
    const left = String(p.headToHead.left ?? '').trim();
    const right = String(p.headToHead.right ?? '').trim();
    if (left && right) {
      headToHead = {
        left, right,
        leftLabel: String(p.headToHead.leftLabel ?? left),
        rightLabel: String(p.headToHead.rightLabel ?? right),
      };
    }
  }

  return {
    entity: p.entity, op: p.op, groupBy, filters, timeRange, limit, sortBy,
    ...(dateBasis ? { dateBasis } : {}), ...(countDistinct ? { countDistinct } : {}),
    ...(superlative ? { superlative } : {}), ...(ageInYears ? { ageInYears } : {}),
    ...(distinctList ? { distinctList } : {}), ...(headToHead ? { headToHead } : {}),
  };
}

/* =================================================================== geo */

/** "Arizona"/"AZ"/"az" -> "AZ"; a bare 2-letter code passed through
 *  uppercased; anything else returned uppercased as a best-effort code. Never
 *  guesses a state from nothing. */
const STATE_NAME_TO_CODE = { arizona: 'AZ' };

export function normalizeStateValue(raw) {
  const s = String(raw ?? '').trim().toLowerCase();
  if (!s) return null;
  if (STATE_NAME_TO_CODE[s]) return STATE_NAME_TO_CODE[s];
  if (/^[a-z]{2}$/.test(s)) return s.toUpperCase();
  return String(raw).trim().toUpperCase();
}

/** 2-letter state code from a free-text address's trailing "..., AZ 85234" or
 *  "...AZ 85234" (no comma). Also recognizes a spelled-out "Arizona" tail.
 *
 *  Geo parity fix (2026-09-25, scorecard geo counts 45/19 vs oracle 44/18): this must be the EXACT same
 *  extraction the scorecard's own oracle SQL runs (see test-docs/scorecard/exam.json's counts-geo/comparisons
 *  questions and scripts/verify-geo-parity.mjs), not just something close. The oracle's own regex is
 *  case-INSENSITIVE on the 2-letter code (a lowercase or mixed-case "az 85224" still resolves to AZ) — this
 *  used to require uppercase only, silently reading such a customer's state as unknown (excluded from every
 *  state/city count and breakdown) while the oracle correctly counted it, an app/oracle disagreement in
 *  exactly the direction that produces a mismatched total. Also, like the oracle, a bare trailing state with
 *  no zip only counts right after a comma with nothing else following (no zip, no extra text) — never a
 *  same-string state+zip match without a comma unless the code sits directly before the zip. */
export function deriveState(address) {
  const s = String(address ?? '');
  // Oracle pattern 1: a 2-letter code (either case) directly before a 5(+4)-digit ZIP at the very end of the
  // whole address string, preceded by start-of-string or any non-letter character (works with or without a
  // comma before the state — "Tempe AZ 85281" and "Tempe, AZ 85281" both match).
  const m = s.match(/(?:^|[^A-Za-z])([A-Za-z]{2})\s*\d{5}(?:[\s-]*\d{4})?\s*$/);
  if (m) return m[1].toUpperCase();
  // Oracle pattern 2: a bare 2-letter code as the very last thing in the string, right after a comma, with no
  // ZIP at all ("40 Pine Ln, Gilbert, AZ").
  const m2 = s.match(/,\s*([A-Za-z]{2})\s*$/);
  if (m2) return m2[1].toUpperCase();
  if (/\barizona\b/i.test(s)) return 'AZ';
  return null;
}

/** 5-digit ZIP from a free-text address (a 9-digit ZIP+4 is truncated to its
 *  first 5, the USPS delivery-area digits county lookups key off).
 *
 *  Geo parity fix (2026-09-25): the ZIP+4 suffix separator matches the oracle's own definition
 *  (test-docs/scorecard/exam.json's "how many different zip codes" oracle) — zero or more spaces/dashes, not a
 *  literal dash only. "...AZ 85205-1234" (dash), "...AZ 85205 1234" (space) and "...AZ 852051234" (no
 *  separator at all) all resolve to "85205" on both sides now; only the dash form used to. */
export function deriveZip(address) {
  const m = String(address ?? '').match(/\b(\d{5})(?:[\s-]*\d{4})?\s*$/);
  return m ? m[1] : null;
}

/** ZIP -> county, via the 3-digit default plus 5-digit exceptions in
 *  zip-county.json. Returns null (never a guess) for a ZIP outside the AZ
 *  850-865 range this table covers. */
export function countyForZip(zip) {
  const z = String(zip ?? '').trim();
  if (!/^\d{5}$/.test(z)) return null;
  if (zipCounty.azZipExceptions[z]) return zipCounty.azZipExceptions[z];
  const prefix = z.slice(0, 3);
  return zipCounty.azZip3Default[prefix] ?? null;
}

/** city (+ optional state) -> county, via the bundled fallback tables. AZ
 *  cities are checked first (this product's home state); a US city outside
 *  AZ falls back to usCityCounty, keyed "city|state" — an unrecognized city
 *  returns null rather than a guess. */
export function countyForCity(city, state) {
  const c = String(city ?? '').trim().toLowerCase();
  if (!c) return null;
  if (zipCounty.azCityCounty[c] && (!state || normalizeStateValue(state) === 'AZ')) {
    return zipCounty.azCityCounty[c];
  }
  const st = state ? normalizeStateValue(state).toLowerCase() : null;
  if (st) {
    const hit = zipCounty.usCityCounty[`${c}|${st}`];
    if (hit) return hit.county;
  }
  // No state given (or it didn't match) — try any US entry for this city name.
  for (const [key, v] of Object.entries(zipCounty.usCityCounty)) {
    if (key.startsWith(`${c}|`)) return v.county;
  }
  return zipCounty.azCityCounty[c] ?? null;
}

/** Full derivation from a raw service_address: {city, state, zip, county}.
 *  Each field is independently best-effort and any of them may be null —
 *  callers bucket a null county as "Unknown", never as 0/omitted. */
export function deriveGeo(address) {
  const city = deriveCity(address);
  const state = deriveState(address);
  const zip = deriveZip(address);
  let county = zip ? countyForZip(zip) : null;
  if (!county && city) county = countyForCity(city, state);
  return { city, state, zip, county };
}

export const UNKNOWN_BUCKET = 'Unknown';

/* ============================================================ filter matching
 *
 * Pure predicate matching, applied client-side (in JS) to already-fetched
 * rows for every field the SQL layer can't cleanly express as a single
 * parameterized column comparison (city/county/state/zip are all derived from
 * one free-text address column; warrantyStatus is a computed tier, not a
 * column). The SQL builder (below) still narrows what's fetched wherever a
 * field maps directly to one column — this is the closing check that makes
 * the closed vocabulary authoritative regardless of what SQL narrowed.
 */
function coerceNumber(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

/** hasEmail/hasPhone read the row's own `email`/`phone` property (its
 *  presence/non-blankness), never a literal `row.hasEmail` field — see
 *  shapeCustomerRow (routes/analytics.js), which is the only row shape that
 *  carries these two properties at all. */
const HAS_FIELD_ROW_KEY = { hasEmail: 'email', hasPhone: 'phone' };

/** Round 15 (A, data-quality): unlike HAS_FIELD_ROW_KEY above (a raw string
 *  column, presence/non-blankness decides "has"), every DATA_QUALITY_BOOLEAN_FIELDS
 *  field reads a REAL boolean the row already carries, computed once at shape
 *  time (routes/analytics.js) — some from a plain column's presence, some
 *  (installDateInFuture, hasCustomerLink/hasAnyDocument via a correlated-
 *  subquery column) from something a raw-string presence check could never
 *  express correctly. One row key per field, same name. */
const DATA_QUALITY_ROW_KEY = Object.fromEntries(DATA_QUALITY_BOOLEAN_FIELDS.map((f) => [f, f]));

// R18 P4 (C3): warrantyExpires is a raw date string (YYYY-MM-DD, sometimes YYYY-MM/YYYY) —
// lexicographic order agrees with calendar order at whatever precision is on file, the same
// convention installDateInFuture/queryInstallDateExtreme (routes/analytics.js) already rely on for
// every other date-shaped string field in this corpus, so a plain string compare is correct here
// too (never coerceNumber's numeric parse, which would just see NaN for a date string).
const DATE_STRING_FIELDS = new Set(['warrantyExpires', 'installDate', 'agreementEnd']);

export function matchesFilter(row, filter) {
  const { field, op, value } = filter;
  // R35: 'covered' (not expired) is active OR expiring.
  if (field === 'warrantyStatus' && (op === 'eq' || op === 'neq') && String(value).toLowerCase() === 'covered') {
    const hit = WARRANTY_COVERED_STATUSES.has(String(row.warrantyStatus ?? ''));
    return op === 'eq' ? hit : !hit;
  }
  if (field in HAS_FIELD_ROW_KEY) {
    const raw = row[HAS_FIELD_ROW_KEY[field]];
    const has = raw != null && String(raw).trim() !== '';
    return has === (value === true);
  }
  if (field in DATA_QUALITY_ROW_KEY) {
    return Boolean(row[DATA_QUALITY_ROW_KEY[field]]) === (value === true);
  }
  const actual = row[field];
  if (DATE_STRING_FIELDS.has(field)) {
    if (actual === null || actual === undefined || actual === '') return false;
    let a = String(actual);
    const b = String(value);
    if (op === 'eq') return a === b;
    if (op === 'neq') return a !== b;
    // R32: a year-only / year-month install date is never guessed into a day. "Older" (lt/lte) needs the LATEST day it could
    // be to still qualify; "newer" (gt/gte) needs the EARLIEST. Full dates and warrantyExpires are compared as before.
    if (field === 'installDate' && a.length < 10 && /^\d{4}(-\d{2})?$/.test(a)) {
      const late = op === 'lt' || op === 'lte';
      a = a.length === 4 ? `${a}-${late ? '12-31' : '01-01'}` : `${a}-${late ? '31' : '01'}`;
    }
    if (op === 'gt') return a > b;
    if (op === 'gte') return a >= b;
    if (op === 'lt') return a < b;
    if (op === 'lte') return a <= b;
    return false;
  }
  if (op === 'in') {
    const arr = Array.isArray(value) ? value : [value];
    return arr.some((v) => matchesFilter(row, { field, op: 'eq', value: v }));
  }
  if (actual === null || actual === undefined) return false;
  if (op === 'eq' || op === 'neq') {
    const a = String(actual).toLowerCase();
    const b = String(value).toLowerCase();
    return op === 'eq' ? a === b : a !== b;
  }
  if (op === 'contains') return String(actual).toLowerCase().includes(String(value).toLowerCase());
  const an = coerceNumber(actual);
  const bn = coerceNumber(value);
  if (an === null || bn === null) return false;
  if (op === 'gt') return an > bn;
  if (op === 'gte') return an >= bn;
  if (op === 'lt') return an < bn;
  if (op === 'lte') return an <= bn;
  return false;
}

export function matchesAllFilters(row, filters) {
  return (filters ?? []).every((f) => matchesFilter(row, f));
}

/* =================================================================== SQL builder
 *
 * Pure: entity -> {sql, params}. Whitelisted columns and operators only — the
 * model never contributes a single character of SQL text, only the `plan`
 * object validatePlan already checked against the closed vocabulary above.
 * Every string embedded here is a fixed column/table name from this file, not
 * user or model input; every actual VALUE goes in as a $N parameter.
 *
 * Only filters that map to ONE real column are pushed into the WHERE clause
 * (a cheap, safe narrowing); the rest (city/county/state/zip/warrantyStatus/
 * month/technician-on-equipment) are left for matchesAllFilters/groupKey to
 * apply in JS after the fetch — see the module comment above. This keeps the
 * SQL small and testable as a fixture (scripts/verify-analytics.mjs) with no
 * database, while still means the model itself never determines what SQL
 * text runs — only which of these fixed, pre-written statements is used and
 * which already-whitelisted column each $N binds to.
 */
const TENANT_SQL = "tenant_id = (current_setting('app.tenant_id', true))::uuid";

// field -> a single real column expression, for the entity(ies) it applies to.
const SQL_COLUMN = {
  customers: { customerName: "data->>'customer_name'" },
  equipment: {
    brand: "data->>'manufacturer'",
    model: "data->>'model'",
    equipmentType: "data->>'equipment_type'",
    refrigerant: "data->>'refrigerant'",
  },
  documents: { documentType: 'document_type' },
};

/** hasEmail/hasPhone (item 2): not a plain column comparison (there is no
 *  value to bind — "IS NOT NULL AND <> ''" takes no parameter), so these are
 *  handled separately from pushColumnFilter/SQL_COLUMN below rather than
 *  forced into that shape. Column names are fixed text from this file, never
 *  model input, exactly like every other column expression in this file. */
const HAS_FIELD_COLUMN = { hasEmail: "data->>'email'", hasPhone: "data->>'phone'" };

const SQL_OP = { eq: '=', neq: '<>', contains: 'ILIKE', gt: '>', gte: '>=', lt: '<', lte: '<=' };

function pushColumnFilter(where, params, column, filter) {
  if (filter.op === 'in') {
    const arr = Array.isArray(filter.value) ? filter.value : [filter.value];
    const placeholders = arr.map((v) => {
      params.push(String(v));
      return `$${params.length}`;
    });
    where.push(`${column} IN (${placeholders.join(', ')})`);
    return;
  }
  const sqlOp = SQL_OP[filter.op];
  if (!sqlOp) return; // not SQL-expressible (e.g. contains handled below) — left to JS
  if (filter.op === 'contains') {
    params.push(`%${filter.value}%`);
    where.push(`${column} ILIKE $${params.length}`);
    return;
  }
  params.push(String(filter.value));
  where.push(`${column} ${sqlOp} $${params.length}`);
}

/**
 * R19 (I2, task 5): "how many service tickets for X" / "how many documents on file for X" is a
 * question about the CUSTOMER's own record, never one about internal/team-only paperwork — that is
 * the default audienceFilterSql (api/_lib/audience/sql.js) already assumes for every OTHER adopter
 * (search/store.js, search/knowledge.js). A question explicitly ABOUT the internal side of the
 * business ("internal memos", "notes for the team/techs/dispatch", "team-only documents") is the
 * one carve-out — narrow and closed-vocabulary on purpose, same discipline as every other detector
 * in this file: a miss here just means "assume customer-scoped" (the safe default), never a guess
 * that widens what a customer answer can see.
 *
 * R23 (D2): this used to be a second, OLDER copy of the same regex (`for\s+(?:the\s+)?(?:team|
 * techs?|...)` — "the" optional) that R23 D1 already fixed once in fastPath.js's own copy (requiring
 * a literal "the" so a business's own name — "Crew Electric", "Dispatch Solutions Inc" — is never
 * mistaken for a team/dispatch reference; see that file's own doc comment) without ever coming back
 * to unify this file's copy with it, so the two had quietly drifted apart. Re-exporting fastPath.js's
 * own function here (never a second, hand-duplicated regex) means a future narrowing/widening of
 * this vocabulary only ever needs to happen once. Verified behavior-safe against every existing
 * pinned case in this file's own test suite (scripts/verify-analytics.mjs) before making this swap —
 * see that file's own isTeamScopedQuestion checks, all still passing unchanged.
 */
export { isTeamScopedQuestion } from './fastPath.js';

/**
 * R39: the exact COUNT(*) for a BARE plan (no filters, no time window) on customers / equipment / documents - the shapes where fetching rows only to count them
 * is wasted work and, past SCAN_LIMIT, wrong. Same WHERE (tenant, merged_into, audience) as the row query in buildAnalyticsSQL. Null for any other plan.
 */
export function buildAnalyticsCountSQL(plan, { audienceClause = 'TRUE' } = {}) {
  audienceClause = `(${audienceClause}) AND ${notPrivateSql('d')}`; // People / HR papers are never counted
  if (!plan || plan.op !== 'count' || plan.timeRange || (plan.filters ?? []).length || plan.sortBy) return null;
  if (plan.entity === 'customers') return { sql: `SELECT count(*)::int AS n FROM entities WHERE entity_type = 'customer' AND merged_into IS NULL AND ${TENANT_SQL}`, params: [] };
  if (plan.entity === 'equipment' || plan.entity === 'warranties') return { sql: `SELECT count(*)::int AS n FROM entities WHERE entity_type = 'equipment' AND merged_into IS NULL AND ${TENANT_SQL}`, params: [] };
  if (plan.entity === 'documents') return { sql: `SELECT count(*)::int AS n FROM documents d WHERE ${TENANT_SQL} AND (${audienceClause})`, params: [] };
  return null;
}

/** @returns {{sql: string, params: any[]}}
 *  @param opts.audienceClause  a WHERE-safe SQL fragment (audienceFilterSql, api/_lib/audience/sql.js)
 *    AND-ed into the `documents`-touching branches below — 'TRUE' (its default) is a no-op, so every
 *    existing caller that doesn't pass it keeps its exact current behavior. R19 (I2, task 5): the
 *    caller (routes/analytics.js) builds this once per request from documentsHaveAudience's own
 *    migration-tolerance probe and isTeamScopedQuestion above — this file stays pure/no-I/O and never
 *    probes the schema itself. */
export function buildAnalyticsSQL(plan, { audienceClause = 'TRUE', rowLimit = SCAN_LIMIT } = {}) {
  audienceClause = `(${audienceClause}) AND ${notPrivateSql('d')}`; // People / HR papers are never counted or listed
  const where = [TENANT_SQL];
  const params = [];
  const columnsFor = SQL_COLUMN[plan.entity === 'warranties' ? 'equipment' : plan.entity] ?? {};
  for (const f of plan.filters ?? []) {
    if (f.field in HAS_FIELD_COLUMN) {
      const col = HAS_FIELD_COLUMN[f.field];
      where.push(f.value ? `(${col} IS NOT NULL AND ${col} <> '')` : `(${col} IS NULL OR ${col} = '')`);
      continue;
    }
    const col = columnsFor[f.field];
    if (col) pushColumnFilter(where, params, col, f);
  }

  if (plan.entity === 'customers') {
    return {
      // Round 15 (A): has_any_document (data-quality: "customers with no
      // documents on file at all") — a correlated EXISTS-style scalar
      // subquery, same tenant scope as the outer query, same idiom the
      // documents branch's own service_date lookup already uses below. Any
      // direct link at all counts (any document type), unlike hasDocType/
      // lacksDocType (DOC_TYPE_FILTER_FIELDS) which name one specific type.
      sql: `SELECT id, customer_number, data->>'customer_name' AS customer_name,
                   data->>'service_address' AS service_address,
                   data->>'email' AS email, data->>'phone' AS phone, updated_at,
                   (EXISTS (SELECT 1 FROM document_entity_links l
                             JOIN documents d ON d.id = l.document_id AND d.${TENANT_SQL} AND ${notPrivateSql("d")}
                             WHERE l.entity_id = entities.id AND l.${TENANT_SQL} AND (${audienceClause}))) AS has_any_document,
                   -- R18 P4 (C4, negation, h134): "how many customers have zero equipment on
                   -- file" — the customers-side mirror of has_any_document just above.
                   (EXISTS (SELECT 1 FROM entities e
                             WHERE e.entity_type = 'equipment' AND e.merged_into IS NULL
                               AND e.customer_id = entities.id AND e.${TENANT_SQL})) AS has_any_equipment,
                   -- R20 (J3, i011): "how many properties do we have more than one unit installed
                   -- at" — the same correlated subquery as has_any_equipment just above, counted
                   -- instead of merely checked for existence.
                   ((SELECT count(*) FROM entities e
                             WHERE e.entity_type = 'equipment' AND e.merged_into IS NULL
                               AND e.customer_id = entities.id AND e.${TENANT_SQL}) > 1) AS has_multiple_units
              FROM entities
             WHERE entity_type = 'customer' AND merged_into IS NULL AND ${where.join(' AND ')}
             ORDER BY updated_at DESC
             LIMIT ${Math.max(1, Math.trunc(Number(rowLimit)) || SCAN_LIMIT)}`,
      params,
    };
  }
  if (plan.entity === 'equipment' || plan.entity === 'warranties') {
    return {
      // Round 15 (A): serial_number added for the hasSerial data-quality
      // filter ("units missing a serial number") — every other column here
      // already existed for a different reason (model/manufacturer for
      // brand/model filters, installation_date for age/installYear,
      // warranty for warrantyStatus) and now also feeds hasModel/
      // hasInstallDate/installDateInFuture (shapeEquipmentRow,
      // routes/analytics.js) — no new column needed for those.
      sql: `SELECT id, customer_id, data->>'model' AS model, data->>'manufacturer' AS manufacturer,
                   data->>'equipment_type' AS equipment_type, data->>'tonnage' AS tonnage,
                   data->>'refrigerant' AS refrigerant, data->>'installation_date' AS installation_date,
                   data->>'serial_number' AS serial_number,
                   data->>'service_address' AS service_address, data->'warranty' AS warranty, updated_at
              FROM entities
             WHERE entity_type = 'equipment' AND merged_into IS NULL AND ${where.join(' AND ')}
             ORDER BY updated_at DESC
             LIMIT ${Math.max(1, Math.trunc(Number(rowLimit)) || SCAN_LIMIT)}`,
      params,
    };
  }
  if (plan.entity === 'documents') {
    // Item 1 (2026-09-21 live miss): "how many jobs/documents/invoices did we
    // do IN AUGUST" means the month the WORK happened, not the month the
    // paper was uploaded — documents.created_at is upload time and has no
    // reliable relationship to it (a job done in August scanned in October
    // would be missed entirely; an old backlog batch-uploaded in August would
    // be wrongly counted). extractions.field_key = 'service_date' (see
    // extractFields.js FIELD_SPECS) is the real job/service date; documents
    // itself has no such column (see M3-config/01-create-schema.sql), so it
    // is pulled via a correlated scalar subquery, same tenant scope as the
    // outer query, most-recent value per document. shapeDocumentRow (below)
    // falls back to created_at only for a document with no service_date
    // extraction at all, so a doc-count with no time filter is unaffected.
    // Round 15 (A): has_customer_link (data-quality: "documents aren't linked
    // to any customer") — the same DIRECT document_entity_links -> customer
    // link the frontend itself treats as "linked" (see routes/integrity.js's
    // loadUnlinkedCandidates doc comment on why this is the one link that
    // counts, not a transitive one via a linked unit's own customer_id).
    // D4: only an agreement-end question needs the agreement term and the linked customer's name.
    const permitCols = (plan.filters ?? []).some((f) => f.field === 'permitScope' || f.field === 'permitCity')
      ? `,
                   (SELECT string_agg(pg.text, E'\\n' ORDER BY pg.page_no) FROM document_pages pg
                     WHERE pg.document_id = d.id AND pg.${TENANT_SQL}) AS permit_text`
      : '';
    const agreementCols = (plan.filters ?? []).some((f) => f.field === 'agreementEnd')
      ? `,
                   (SELECT a.value FROM extractions a
                     WHERE a.document_id = d.id AND a.field_key = 'agreement_term' AND a.${TENANT_SQL}
                     ORDER BY a.created_at DESC LIMIT 1) AS agreement_term,
                   (SELECT c.data->>'customer_name' FROM document_entity_links l2
                      JOIN entities c ON c.id = l2.entity_id AND c.entity_type = 'customer' AND c.merged_into IS NULL AND c.${TENANT_SQL}
                     WHERE l2.document_id = d.id AND l2.${TENANT_SQL}
                     ORDER BY l2.created_at DESC LIMIT 1) AS agreement_customer`
      : '';
    return {
      sql: `SELECT d.id, d.document_type, d.original_filename, d.created_at,
                   (SELECT x.value FROM extractions x
                     WHERE x.document_id = d.id AND x.field_key = 'service_date' AND x.${TENANT_SQL}
                     ORDER BY x.created_at DESC LIMIT 1) AS service_date,
                   (EXISTS (SELECT 1 FROM document_entity_links l
                             JOIN entities ce ON ce.id = l.entity_id AND ce.entity_type = 'customer' AND ce.merged_into IS NULL AND ce.${TENANT_SQL}
                            WHERE l.document_id = d.id AND l.${TENANT_SQL})) AS has_customer_link,
                   -- R20 (J3, i020/i021): "how many purchase orders have we cut to Baker
                   -- Distributing" — the vendor named on a purchase order (or vendor bill), pulled
                   -- the same correlated-scalar way as service_date just above.
                   (SELECT v.value FROM extractions v
                     WHERE v.document_id = d.id AND v.field_key = 'vendor_name' AND v.${TENANT_SQL}
                     ORDER BY v.created_at DESC LIMIT 1) AS vendor${agreementCols}${permitCols}
              FROM documents d
             WHERE ${where.join(' AND ')} AND (${audienceClause})
             ORDER BY d.created_at DESC
             LIMIT ${Math.max(1, Math.trunc(Number(rowLimit)) || SCAN_LIMIT)}`,
      params,
    };
  }
  // serviceVisits: two field_keys off `extractions`, merged in JS (routes/analytics.js) —
  // no single row here carries both service_date and technician, so this returns
  // the base set (service_date rows); the executor runs a second, identically
  // shaped query for field_key = 'technician' and joins by document_id itself.
  //
  // Live miss (2026-09-21, "which units had service this month"): a bare
  // service_date row names no unit or customer at all — "which units/
  // customers had service this month" had nothing to list. Two cheap
  // correlated scalar subqueries, both tenant-scoped identically to the outer
  // query and to the documents branch's own service_date lookup above: the
  // document's linked CUSTOMER entity (via document_entity_links — a document
  // can link to a customer and/or equipment entity; entity_type = 'customer'
  // picks only the customer one, so a document also linked to an equipment
  // entity can never fan this out into two rows) for the customer's name, and
  // the document's own 'model' extraction for the unit. Most-recent-row-wins
  // (ORDER BY ... DESC LIMIT 1) on both, same idiom as service_date itself.
  return {
    // ROOT CAUSE of every live service-visit miss up to 2026-09-21: this
    // SELECT used to read `x.stage`, but `stage` is a documents column —
    // extractions has none (M3-config/01) — so Postgres rejected the query
    // and runAnalyticsQuestion's catch fell through to retrieval for EVERY
    // serviceVisits plan. Mock-db tests never executed real SQL, so it was
    // invisible offline. Columns here are checked against the schema file by
    // scripts/verify-analytics.mjs now.
    sql: `SELECT x.document_id, x.value, x.confidence,
                 (SELECT c.data->>'customer_name'
                    FROM document_entity_links l
                    JOIN entities c ON c.id = l.entity_id AND c.entity_type = 'customer'
                                   AND c.merged_into IS NULL AND c.${TENANT_SQL}
                   WHERE l.document_id = x.document_id AND l.${TENANT_SQL}
                   ORDER BY l.created_at DESC LIMIT 1) AS customer_name,
                 (SELECT m.value FROM extractions m
                   WHERE m.document_id = x.document_id AND m.field_key = 'model' AND m.${TENANT_SQL}
                   ORDER BY m.created_at DESC LIMIT 1) AS model,
                 -- R21 (L3): "how many trane jobs/visits have we done" and "how many preventive
                 -- maintenance/repair visits" both name a per-VISIT attribute (the job's own brand,
                 -- the job's own service_type) that this row never carried before, so filtering a
                 -- serviceVisits plan by either one always failed filtersSupported (routes/
                 -- analytics.js) and silently fell through to the model-backed agent even though
                 -- detectAnalyticsPlan (detPlan.js) already built the right filter. Same correlated-
                 -- scalar idiom as the model subquery just above, tenant-scoped identically.
                 (SELECT mf.value FROM extractions mf
                   WHERE mf.document_id = x.document_id AND mf.field_key = 'manufacturer' AND mf.${TENANT_SQL}
                   ORDER BY mf.created_at DESC LIMIT 1) AS manufacturer,
                 (SELECT st.value FROM extractions st
                   WHERE st.document_id = x.document_id AND st.field_key = 'service_type' AND st.${TENANT_SQL}
                   ORDER BY st.created_at DESC LIMIT 1) AS service_type,
                 -- D20: what KIND of paper this "visit" is (service ticket, invoice, work order, ...) so the answer can say what was counted.
                 (SELECT dt.document_type FROM documents dt WHERE dt.id = x.document_id AND dt.${TENANT_SQL}) AS document_type
            FROM extractions x
           WHERE x.field_key = 'service_date' AND ${TENANT_SQL} AND ${notPrivateIdSql('x.document_id')}
           ORDER BY x.value DESC
           LIMIT ${Math.max(1, Math.trunc(Number(rowLimit)) || SCAN_LIMIT)}`,
    params: [],
  };
}

/* =================================================================== formatting
 *
 * Deterministic text — NO second model call. Everything the user reads here
 * is composed from real counts/rows, in code, per the brief's design.
 */

/** Bucket rows by the plan's groupBy field into an ordered [{key, count}]
 *  list (largest first, "Unknown" always last regardless of count so a real
 *  place always outranks the leftover bucket at a glance). `keyOf` extracts
 *  the group key from one already-shaped row (see routes/analytics.js). */
export function groupRows(rows, keyOf) {
  const counts = new Map();
  for (const r of rows) {
    const k = keyOf(r) ?? UNKNOWN_BUCKET;
    counts.set(k, (counts.get(k) ?? 0) + 1);
  }
  const entries = [...counts.entries()];
  entries.sort((a, b) => {
    if (a[0] === UNKNOWN_BUCKET) return 1;
    if (b[0] === UNKNOWN_BUCKET) return -1;
    return b[1] - a[1] || a[0].localeCompare(b[0]);
  });
  return entries.map(([key, count]) => ({ key, count }));
}

/**
 * R7 guardrail (R7_MEASURE item 2, "yes/no shape"): "Do we have any Ruud units?" / "Are there any unpaid
 * invoices?" / "Is there a maintenance agreement on file for anyone?" / "Did we do any service calls last
 * month?" are existence (yes/no) questions in the exam's grading (compareYesNo, api/_lib/scorecard/compare.js) —
 * it reads only the first few words of the answer, so a technically-correct-but-generic "You have 0 pieces of
 * equipment." reads as an affirmative default and fails a real "no". `existenceWrap` below adds an explicit
 * Yes/No lead-in for exactly this question shape — applied by ask.js/routes/analytics.js's own
 * applyExistenceShape to the OUTGOING response text only (never baked into the count-op formatter or the
 * cached answer itself — see existenceWrap's own doc comment for why). Never for an ordinary "how many" — those
 * keep their plain wording, and a false-positive match here only adds a "Yes,"/"No," lead-in a plain
 * count-comparison ignores. */
// R18 (H1, breadth-data-quality-023): "any" added alongside we/there/you/our shop — "Are any
// serial numbers used by more than one unit?" is the same existence shape (compareYesNo reads the
// leading Yes/No cue exactly like the other four lead-ins already here), just naming the subject
// right after the verb instead of "we/there/you". Checked against the exam's own full "is/are any"
// question set — every other match is a rubric question the analytics existence-wrap never runs
// for, so this can't flip an already-passing plain count.
export const EXISTENCE_QUESTION_RE = /^\s*(?:do|does|is|are|did|have|has)\s+(?:we|there|you|our\s+shop|any)\b/i;
export function isExistenceQuestion(question) {
  return EXISTENCE_QUESTION_RE.test(String(question ?? ''));
}
/** "You have 3 pieces of equipment." -> "Yes, you have 3 pieces of equipment."; a zero count -> "No, ...".
 *  Idempotent: a text that already starts with "Yes,"/"No," is returned unchanged, so this is safe to apply
 *  as a post-processing step over a cached answer without ever double-wrapping it — see routes/analytics.js's
 *  own applyExistenceShape, which applies this AFTER a Tier-1/Tier-2 cache lookup rather than baking it into
 *  the cached `data` itself (two differently-shaped questions — "how many Ruud units" / "do we have any Ruud
 *  units" — can resolve to the identical cached plan, and only one of them wants the Yes/No lead-in). */
export function existenceWrap(text, exists) {
  const t = String(text ?? '');
  if (!t || /^(?:yes|no),\s/i.test(t)) return t;
  return `${exists ? 'Yes' : 'No'}, ${t.charAt(0).toLowerCase()}${t.slice(1)}`;
}

const ENTITY_NOUN = {
  customers: (n) => `customer${n === 1 ? '' : 's'}`,
  equipment: (n) => `piece${n === 1 ? '' : 's'} of equipment`,
  documents: (n) => `document${n === 1 ? '' : 's'}`,
  serviceVisits: (n) => `service visit${n === 1 ? '' : 's'}`,
  warranties: (n) => `unit${n === 1 ? '' : 's'}`,
};

// R19 (I2, h112/h113/h115): exported so routes/analytics.js's formatGroupBySuperlativeAnswer can
// name the extreme group's own dimension the same way every plain groupBy breakdown already does,
// rather than a second hand-copied label table that could quietly drift from this one.
export const GROUP_LABEL = {
  city: 'city', county: 'county', state: 'state', zip: 'ZIP', brand: 'brand',
  documentType: 'document type', month: 'month', technician: 'technician', warrantyStatus: 'warranty status',
};

/** "September 3, 2026" from a YYYY-MM-DD service_date value, "September 2026"
 *  from a bare YYYY-MM one, or the raw string as a last resort — used only by
 *  the serviceVisits zero-result wording below. Never throws on a garbled
 *  value; it just falls back to printing whatever was there. */
function formatServiceDateLabel(rawDate) {
  const s = String(rawDate ?? '').trim();
  const full = /^(\d{4})-(\d{2})-(\d{2})/.exec(s);
  if (full) {
    const idx = Number(full[2]) - 1;
    if (idx >= 0 && idx <= 11) return `${MONTH_LABELS[idx]} ${Number(full[3])}, ${full[1]}`;
  }
  const monthOnly = /^(\d{4})-(\d{2})$/.exec(s);
  if (monthOnly) {
    const idx = Number(monthOnly[2]) - 1;
    if (idx >= 0 && idx <= 11) return `${MONTH_LABELS[idx]} ${monthOnly[1]}`;
  }
  return s || 'an unknown date';
}

/** Cap on how many groupBy/list rows go into `facts` — the client's "compact
 *  table" (see AnswerCard/FactGrid). Anything past this is summarized in
 *  `text` as "... and N more" rather than growing the response without bound.
 *  Reviewer NO-GO (2026-09-21, round 2, gap 2): 12 was too low for a live
 *  "which customers have Trane units" style answer ("18 customers — showing
 *  the first 12" cut off a third of them) — raised to 50, still bounded, and
 *  FactGrid's GroupTable (src/components/FactGrid.tsx) stays a compact
 *  one-line-per-row table at 50 rows exactly as it already did at 12.
 *  Round 14 (K3): raised again to 200 — a real, ordinary "list customers
 *  missing an email address" (data-hygiene) truncated a genuine 60-customer
 *  answer down to 50 shown, silently dropping 10 real names off a plain list
 *  answer with no "narrow this down" filter involved at all. 200 still keeps
 *  this a bounded, compact table (a shop this small — the golden tenant's
 *  own largest entity population is 132 equipment records — never has a
 *  plain unfiltered list bigger than that), just no longer truncates the
 *  ordinary case. */
export const MAX_FACT_ROWS = 200;

/**
 * @param plan       the validated plan
 * @param opts.total total rows the executor scoped to the filters, BEFORE
 *                    LIMIT is applied — used for the "(of N in Arizona)"-style
 *                    parenthetical when a filter narrowed the population.
 * @param opts.groups groupRows() output, for op 'groupBy'.
 * @param opts.rows   individual matched rows (already shaped {label, value,
 *                    entityId?}), for op 'list'.
 * @param opts.sum    the computed total, for op 'sum'.
 * @param opts.unfilteredTotal total for the SAME entity with no filters at
 *                    all — powers the ambiguity rule (0 results -> tell them
 *                    what DOES exist) and the "(of 31 in Arizona)" framing.
 * @param opts.broaderLabel/broaderGroups  for the ambiguity rule (rule 5):
 *                    when a named filter value matches zero rows, name what
 *                    the tenant's data actually has instead.
 */

/** "Customers with an email on file" / "Customers missing a phone number" —
 *  item 2 (2026-09-21): a hasEmail/hasPhone-filtered count needs a fact label
 *  that says WHICH condition was counted, not the generic "Customers" a plain
 *  count gets. Both filters together ("have an email and a phone") join with
 *  "and". Returns null when neither filter is present, so callers fall back
 *  to the generic noun-based label. */
function customerContactFactLabel(entity, filters) {
  if (entity !== 'customers') return null;
  const parts = [];
  const email = (filters ?? []).find((f) => f.field === 'hasEmail');
  const phone = (filters ?? []).find((f) => f.field === 'hasPhone');
  if (email) parts.push(email.value ? 'with an email on file' : 'missing an email address');
  if (phone) parts.push(phone.value ? 'with a phone number on file' : 'missing a phone number');
  return parts.length ? `Customers ${parts.join(' and ')}` : null;
}

/** "Carrier units" instead of the generic "Pieces of equipment" — a
 *  brand-filtered equipment/warranties count should name the brand it was
 *  actually filtered to. Returns null when no brand filter (eq/in) is
 *  present, so callers fall back to the generic noun-based label. */
function brandFactLabel(entity, filters) {
  if (entity !== 'equipment' && entity !== 'warranties') return null;
  const f = (filters ?? []).find((x) => x.field === 'brand' && (x.op === 'eq' || x.op === 'in'));
  if (!f) return null;
  const brand = Array.isArray(f.value) ? f.value[0] : f.value;
  return brand ? `${brand} units` : null;
}

/** Team A (2026-09-24): service visits dated after today (typos or scheduled visits) are excluded from "jobs we did" /
 *  "last service" answers; say so instead of silently dropping them. */
export function formatAnalyticsAnswer(plan, opts) {
  const out = formatAnalyticsAnswerBase(plan, opts);
  const n = Number(opts?.futureVisitCount) || 0;
  if (plan.entity === 'serviceVisits' && n > 0 && out && typeof out.text === 'string') {
    return { ...out, text: `${out.text} (${n} record${n === 1 ? '' : 's'} dated after today ${n === 1 ? 'was' : 'were'} left out - likely typos or scheduled visits.)` };
  }
  return out;
}

/** D20: "22 service tickets, 3 work orders, 2 inspection reports (every document with a service date counts as a visit)" - what a
 *  service-visit count is made of, so a 27-visit answer is never mistaken for 27 service tickets. null when no row carries a type. */
export function serviceVisitBasisNote(rows) {
  const counts = new Map();
  for (const r of rows ?? []) {
    if (!r?.documentType) continue;
    const label = documentTypeLabel(r.documentType).toLowerCase();
    counts.set(label, (counts.get(label) ?? 0) + 1);
  }
  if (!counts.size) return null;
  const parts = [...counts.entries()].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0])).map(([label, n]) => `${n} ${label}${n === 1 ? '' : 's'}`);
  return `counted from every document with a service date: ${parts.join(', ')}`;
}

/** "end in 2026" / "end between 2026 and 2027" / "run through 2027 or later" ... from a plan's agreementEnd bounds. */
function agreementEndPhrase(filters) {
  const lower = filters.find((f) => f.op === 'gte' || f.op === 'gt');
  const upper = filters.find((f) => f.op === 'lte' || f.op === 'lt');
  const yr = (f) => f.value.slice(0, 4);
  const yearStart = (f) => f.op === 'gte' && f.value.slice(5) === '01-01';
  const yearEnd = (f) => f.op === 'lte' && f.value.slice(5) === '12-31';
  if (lower && upper) {
    if (yearStart(lower) && yearEnd(upper)) return yr(lower) === yr(upper) ? `end in ${yr(lower)}` : `end between ${yr(lower)} and ${yr(upper)}`;
    return `end between ${lower.value} and ${upper.value}`;
  }
  if (lower) return lower.op === 'gte' && lower.value.slice(5) === '12-31' ? `run through ${yr(lower)} or later` : lower.op === 'gt' && lower.value.slice(5) === '12-31' ? `end after ${yr(lower)}` : `end ${lower.op === 'gt' ? 'after' : 'on or after'} ${lower.value}`;
  if (upper) return yearEnd(upper) ? `end in ${yr(upper)} or earlier` : upper.op === 'lt' && upper.value.slice(5) === '01-01' ? `end before ${yr(upper)}` : `end ${upper.op === 'lt' ? 'before' : 'on or before'} ${upper.value}`;
  return 'end on the date asked';
}

function formatAnalyticsAnswerBase(plan, opts) {
  const {
    total = 0, groups = [], rows = [], sum = null, unfilteredTotal = null, broaderGroups = null,
    mostRecentServiceVisit, timeRangeLabel = null,
  } = opts ?? {};
  let noun = (ENTITY_NOUN[plan.entity] ?? (() => plan.entity))(total);
  // R3 loop r38: a bare doc-type count names the type ("27 maintenance agreements"), not "documents".
  if (plan.entity === 'documents' && plan.op === 'count' && !timeRangeLabel) {
    const dt = (plan.filters ?? []).filter((f) => f.field === 'documentType');
    if (dt.length === 1 && dt[0].op === 'eq' && typeof dt[0].value === 'string' && (plan.filters ?? []).length === 1 && dt[0].value !== 'other') {
      const lbl = String(documentTypeLabel(dt[0].value) ?? '').toLowerCase();
      if (lbl) noun = `${lbl}${total === 1 ? '' : 's'}`;
    }
  }

  // R23 (D2, k139): technician head-to-head yes/no — `rows` is already scoped (by plan.filters'
  // `technician in [left, right]`) to just these two people's own visits (dateless-row correction
  // included, same as any other single-named-technician count — see validatePlan's own doc comment
  // on why this is never the groupBy/superlative path); split it back apart here by each row's own
  // `technician` value to get each side's real count, so a genuine TIE is reported as "No" (neither
  // one has done MORE than the other) rather than falling back to a bare, always-truthy single count.
  if (plan.op === 'count' && plan.headToHead) {
    const { left, right, leftLabel, rightLabel } = plan.headToHead;
    const leftLower = left.toLowerCase();
    const rightLower = right.toLowerCase();
    const leftCount = rows.filter((r) => String(r.technician ?? '').toLowerCase() === leftLower).length;
    const rightCount = rows.filter((r) => String(r.technician ?? '').toLowerCase() === rightLower).length;
    // R24 review: a side with no jobs on file may simply not be a technician here (a misspelling, a
    // non-name) — never state "X has 0 jobs" as a comparison; say what's missing instead.
    if (leftCount === 0 || rightCount === 0) {
      const missing = [leftCount === 0 ? left : null, rightCount === 0 ? right : null].filter(Boolean).join(' or ');
      return {
        kind: 'answer',
        text: `I don't have any jobs on file for ${missing}, so I can't compare them.`,
        facts: [], sources: [], confidence: 1, verifiedCount: 0, unverifiedCount: 0, closest: [],
      };
    }
    const yes = leftCount > rightCount;
    const text = `${yes ? 'Yes' : 'No'}, ${left} has ${leftCount} job${leftCount === 1 ? '' : 's'} on file and ${right} has ${rightCount} job${rightCount === 1 ? '' : 's'} on file.`;
    return {
      kind: 'answer', text,
      facts: [
        { label: leftLabel, value: String(leftCount), sources: [] },
        { label: rightLabel, value: String(rightCount), sources: [] },
      ],
      sources: [], confidence: 1, verifiedCount: 0, unverifiedCount: 0, closest: [],
    };
  }

  // "who's our biggest customer" (round 4, item 1) — a ranked list, not a
  // filtered/counted one; its own wording so the answer reads as a ranking
  // ("Your top 3 customers by equipment count:") rather than a bare count.
  if (plan.sortBy) {
    const measure = plan.sortBy === 'documentCount' ? 'document count' : 'equipment count';
    const text = total === 0
      ? 'No customers on file yet.'
      : `Your top ${total} customer${total === 1 ? '' : 's'} by ${measure}: ${rows.map((r) => `${r.label} (${r.value})`).join(', ')}.`;
    return {
      kind: 'answer', text,
      facts: rows.map((r) => ({ label: r.label, value: r.value ?? '—', entityId: r.entityId, sources: [] })),
      sources: [], confidence: 1, verifiedCount: 0, unverifiedCount: 0, closest: [],
    };
  }

  // Zero-result wording for a timeRange'd serviceVisits question (2026-09-21
  // "which units had service this month" cluster): the owner's account
  // genuinely has zero service visits in the asked-about range, and a bare
  // "0 service visits match that" (or, worse, a fall-through to retrieval's
  // "Nothing in your records answers that") is technically true but useless.
  // An honest zero needs the same kind of context the geo ambiguity rule
  // below gives a named filter that matched nothing: when the most recent
  // visit actually WAS. mostRecentServiceVisit is only ever passed for entity
  // 'serviceVisits' (see executeAnalyticsPlan, routes/analytics.js) — null
  // means the tenant has no service visits on file at all, ever; an object
  // names the single most recent one (rows are already fetched sorted DESC by
  // date, so this costs no extra query).
  if (plan.entity === 'serviceVisits' && plan.timeRange && total === 0 && mostRecentServiceVisit !== undefined) {
    // Item 5 (2026-09-22): timeRangeLabel covers the extended day-grain
    // windows (this week, since 2024, ...) formatAnalyticsAnswer itself has
    // no way to reverse-engineer from {from,to} alone — see
    // resolveAnyTimeRange's own doc comment. Falls back to the original
    // month-only label when the caller didn't pass one (e.g. a plan whose
    // timeRange came from the model's own well-formed, year-matching guess).
    // timeRangeLabel (item 5, 2026-09-22) already carries its own connector
    // word where one reads naturally ("in Q2 2026", "since 2024") and none
    // where it doesn't ("this week", "year to date") — never re-prefixed
    // with "in " here. The bare monthRangeLabel fallback (no connector of
    // its own) keeps needing one, exactly as before this existed.
    const monthLabel = monthRangeLabel(plan.timeRange);
    const scope = timeRangeLabel ? ` ${timeRangeLabel}` : monthLabel ? ` in ${monthLabel}` : '';
    const text = mostRecentServiceVisit
      ? `No service visits${scope}. The most recent one on file is ` +
        `${formatServiceDateLabel(mostRecentServiceVisit.date)}` +
        `${mostRecentServiceVisit.customer ? ` (${mostRecentServiceVisit.customer})` : ''}.`
      : 'No service visits on file yet.';
    return { kind: 'answer', text, facts: [], sources: [], confidence: 1, verifiedCount: 0, unverifiedCount: 0, closest: [] };
  }

  // ---- ambiguity rule (design point 5): a named filter matched zero rows,
  // but the tenant does have data for this entity elsewhere -> say so instead
  // of a bare "0". ----
  if (total === 0 && plan.filters?.length && broaderGroups?.length) {
    const named = broaderGroups.slice(0, 4).map((g) => `${g.key} (${g.count})`).join(', ');
    const text = plan.countUnits
      ? `0 units match that — your units' customers are in ${named}${broaderGroups.length > 4 ? ', and others' : ''}.`
      : `0 ${noun} match that — your ${plan.entity} are in ${named}${broaderGroups.length > 4 ? ', and others' : ''}.`;
    return { kind: 'answer', text, facts: [], sources: [], confidence: 1, verifiedCount: 0, unverifiedCount: 0, closest: [] };
  }

  // D4: "which maintenance agreements expire in 2026" / "how many run through 2027" - worded from the end-year condition itself.
  // D8: "how many commercial permits" / "which residential permits are in Chandler" - worded from the scope/city conditions themselves.
  const permitScopeF = plan.entity === 'documents' ? (plan.filters ?? []).find((f) => f.field === 'permitScope') : null;
  const permitCityF = plan.entity === 'documents' ? (plan.filters ?? []).find((f) => f.field === 'permitCity') : null;
  if ((permitScopeF || permitCityF) && (plan.op === 'count' || plan.op === 'list')) {
    const where = `${permitScopeF ? `${permitScopeF.value} ` : ''}permit${total === 1 ? '' : 's'}${permitCityF ? ` issued by the City of ${titleCaseWords(permitCityF.value)}` : ''}`;
    const text = total === 0 ? `No ${where} on file.` : `${total} ${where} on file.`;
    const facts = plan.op === 'count'
      ? [{ label: 'Permits', value: String(total), sources: [] }]
      : rows.slice(0, MAX_FACT_ROWS).map((r) => ({ label: r.permitNumber ? `Permit ${r.permitNumber}` : r.value, value: [r.permitCity ? `City of ${titleCaseWords(r.permitCity)}` : null, r.permitScopeText].filter(Boolean).join(' - ') || r.value, sources: [] }));
    return { kind: 'answer', text, facts, sources: [], confidence: 1, verifiedCount: 0, unverifiedCount: 0, closest: [] };
  }

  const endFilters = plan.entity === 'documents' ? (plan.filters ?? []).filter((f) => f.field === 'agreementEnd') : [];
  if (endFilters.length && (plan.op === 'count' || plan.op === 'list')) {
    const phrase = agreementEndPhrase(endFilters);
    const single = total === 1;
    const text = total === 0
      ? `No maintenance agreements ${phrase}.`
      : `${total} maintenance agreement${single ? '' : 's'} ${single ? phrase.replace(/^end\b/, 'ends').replace(/^run\b/, 'runs') : phrase}.`;
    const facts = plan.op === 'count'
      ? [{ label: 'Maintenance agreements', value: String(total), sources: [] }]
      : rows.slice(0, MAX_FACT_ROWS).map((r) => ({ label: r.customerName || r.value, value: r.agreementTerm ? `term ${r.agreementTerm}` : r.value, sources: [] }));
    return { kind: 'answer', text, facts, sources: [], confidence: 1, verifiedCount: 0, unverifiedCount: 0, closest: [] };
  }

  // E2 A4: the question counts UNITS (not the customers they belong to): say which thing was counted, and how many customers it spans.
  if (plan.op === 'count' && plan.countUnits && plan.entity === 'customers' && opts?.unitCount != null) {
    const n = opts.unitCount;
    const where = unitScopePhrase(plan.filters);
    const text = n === 0
      ? `No units are on file ${where || 'at those customers'} (${total} customer${total === 1 ? '' : 's'} matched, none with a unit on file).`
      : `You have ${n} unit${n === 1 ? '' : 's'}${where ? ` ${where}` : ''}, at ${total} customer${total === 1 ? '' : 's'} (counted units, not customers).`;
    return { kind: 'answer', text, facts: [{ label: 'Units', value: String(n), sources: [] }], sources: [], confidence: 1, verifiedCount: 0, unverifiedCount: 0, closest: [] };
  }
  if (plan.op === 'count') {
    const of = unfilteredTotal != null && unfilteredTotal !== total ? ` (of ${unfilteredTotal} total)` : '';
    // Item 1: "N jobs in August 2026" style, once there's a real single-month
    // range to name — otherwise the plain "You have N X" wording. Item 5
    // (2026-09-22): timeRangeLabel covers the extended day-grain windows
    // ("this week", "year to date", "since 2024", ...) the same way — see
    // the serviceVisits zero-result branch above for why it's never
    // re-prefixed with "in " here.
    const monthLabel = monthRangeLabel(plan.timeRange);
    // Team A: a documents time window says which date it counted by ("by upload date" / "by service date").
    const basis = plan.entity === 'documents' && plan.dateBasis && plan.timeRange ? ` (${dateBasisPhrase(plan.dateBasis)})` : '';
    const scopedText = timeRangeLabel
      ? `${total} ${noun} ${timeRangeLabel}${basis}${of}.`
      : monthLabel
        ? `${total} ${noun} in ${monthLabel}${basis}${of}.`
        : null;
    // Team A: customers counted through their units ("customers with a unit newer than 5 years") also name the unit count.
    const unitsNote = plan.entity === 'customers' && opts?.unitCount != null && opts.unitCount !== total
      ? ` (${opts.unitCount} matching unit${opts.unitCount === 1 ? '' : 's'} across them)` : '';
    let text = scopedText ?? `You have ${total} ${noun}${of}${unitsNote}.`;
    // D20: a "service visit" here is any document carrying a service date, not only a service ticket - say what was counted.
    if (plan.entity === 'serviceVisits' && total > 0) {
      const note = serviceVisitBasisNote(rows);
      if (note) text = text.replace(/\.$/, ` - ${note}.`);
    }
    const label =
      customerContactFactLabel(plan.entity, plan.filters) ??
      brandFactLabel(plan.entity, plan.filters) ??
      noun[0].toUpperCase() + noun.slice(1);
    return {
      kind: 'answer', text,
      facts: [{ label, value: String(total), sources: [] }],
      sources: [], confidence: 1, verifiedCount: 0, unverifiedCount: 0, closest: [],
    };
  }

  if (plan.op === 'sum') {
    const formatted = Number.isFinite(sum) ? sum.toLocaleString('en-US', { style: 'currency', currency: 'USD' }) : '0';
    const text = `${formatted} across ${total} ${noun}.`;
    return {
      kind: 'answer', text,
      facts: [{ label: 'Total', value: formatted, sources: [] }],
      sources: [], confidence: 1, verifiedCount: 0, unverifiedCount: 0, closest: [],
    };
  }

  if (plan.op === 'groupBy' && plan.countDistinct) {
    // Round 14 (K3): "how many different zip codes do we cover" — the
    // DISTINCT group-value count, never the per-group breakdown below (which
    // would bury the one number this question actually asked for inside a
    // long list and, worse, put the WRONG number first in `text` — the total
    // ROW count, not the distinct-group count).
    const distinctCount = groups.length;
    const label = GROUP_LABEL[plan.groupBy] ?? plan.groupBy;
    return {
      kind: 'answer', text: `You have ${distinctCount} different ${label}${distinctCount === 1 ? '' : 's'}.`,
      facts: [{ label: `Distinct ${label}s`, value: String(distinctCount), sources: [] }],
      sources: [], confidence: 1, verifiedCount: 0, unverifiedCount: 0, closest: [],
    };
  }

  if (plan.op === 'groupBy' && plan.distinctList) {
    // R23 (D2, k186/k187): "which manufacturers do we service" / "list every technician ... in the
    // system" — the plain distinct VALUES themselves (never a per-group count breakdown, and never
    // just the single distinct-count number countDistinct answers with just above). The "Unknown"
    // bucket (an unassigned/blank value) is never a real, nameable value on file, so it's dropped
    // here exactly like formatGroupBySuperlativeAnswer (routes/analytics.js) already excludes it
    // from ever being picked as an extreme group.
    const named = groups.filter((g) => g.key !== UNKNOWN_BUCKET);
    const label = GROUP_LABEL[plan.groupBy] ?? plan.groupBy;
    const text = named.length
      ? `You have ${named.length} ${label}${named.length === 1 ? '' : 's'} on file: ${named.map((g) => g.key).join(', ')}.`
      : `No ${label}s on file.`;
    return {
      kind: 'answer', text,
      facts: named.map((g) => ({ label, value: g.key, sources: [] })),
      sources: [], confidence: 1, verifiedCount: 0, unverifiedCount: 0, closest: [],
    };
  }

  if (plan.op === 'groupBy') {
    const shown = groups.slice(0, MAX_FACT_ROWS);
    const rest = groups.length - shown.length;
    const breakdown = shown.map((g) => `${g.key} ${g.count}`).join(', ');
    const of = unfilteredTotal != null && unfilteredTotal !== total ? ` (of ${unfilteredTotal} total)` : '';
    const more = rest > 0 ? `, and ${rest} more ${GROUP_LABEL[plan.groupBy] ?? plan.groupBy}${rest === 1 ? '' : 's'}` : '';
    const text = `You have ${total} ${noun}${of} by ${GROUP_LABEL[plan.groupBy] ?? plan.groupBy}: ${breakdown}${more}.`;
    return {
      kind: 'answer', text,
      facts: shown.map((g) => ({ label: g.key, value: String(g.count), sources: [] })),
      sources: [], confidence: 1, verifiedCount: 0, unverifiedCount: 0, closest: [],
    };
  }

  // op === 'list'
  const shown = rows.slice(0, MAX_FACT_ROWS);
  const rest = total - shown.length;
  // Reviewer NO-GO (2026-09-21, round 2, gap 2): "and N more" past the cap,
  // matching groupBy's own phrasing above, instead of a bare "showing the
  // first N" that never said how many were left out.
  const text = total === 0
    ? `No ${noun} match that.`
    : rest > 0
      ? `${total} ${noun} — showing ${shown.length}, and ${rest} more.`
      : `${total} ${noun}.`;
  return {
    kind: 'answer', text,
    facts: shown.map((r) => ({ label: r.label, value: r.value ?? '—', entityId: r.entityId, sources: [] })),
    sources: [], confidence: 1, verifiedCount: 0, unverifiedCount: 0, closest: [],
  };
}

/** True brand-name filter value normalizes to a known BRAND_RULES key (or, if
 *  unrecognised, is at least compared case-insensitively as raw text) — used
 *  by routes/analytics.js so "Trane"/"trane"/"TRANE" all match the same rows
 *  regardless of how the manufacturer field was printed on the paperwork. */
export function brandMatches(manufacturerRaw, filterValue) {
  const normalized = normalizeBrand(manufacturerRaw);
  const target = normalizeBrand(filterValue) ?? String(filterValue ?? '').trim().toLowerCase();
  if (normalized && normalized === target) return true;
  return String(manufacturerRaw ?? '').trim().toLowerCase() === String(filterValue ?? '').trim().toLowerCase();
}

/** installYear from a raw installation_date extraction value (YYYY-MM-DD,
 *  YYYY-MM, or any string starting with a 4-digit year) — or null. */
export function installYearOf(installationDate) {
  const m = String(installationDate ?? '').match(/^(\d{4})/);
  return m ? Number(m[1]) : null;
}

/**
 * warrantyStatus bucket ('active'|'expiring'|'expired'|'unknown') — a PURE
 * function of the unit's coverage EXPIRY date only, matching the exam
 * oracle's own definition byte-for-byte (test-docs/scorecard/exam.json's
 * warranty-status CASE expression): unknown when there's no parseable
 * expiry, expired when it's in the past, expiring when it's 0-365 days out,
 * active otherwise.
 *
 * R16 D2 audit item 1 BUG FIX (2026-09-26): this used to go through
 * warrantyRules.alertTier(), which folds in a SEPARATE, registration-
 * paperwork-deadline signal ('unregistered-window-closing', fired whenever
 * the registration deadline — not the coverage expiry — is <=30 days out)
 * ahead of the expiry bucket, by design, for the reminders/alerts UI
 * (warranty-attention.js/notify.js/outreach.js still call alertTier()
 * directly and are UNCHANGED by this fix — that surface still needs and
 * gets the registration-window signal). Routing THIS "what's the coverage
 * status" question through that same tier silently recoded "active,
 * registration paperwork due soon" as "expiring" — a unit installed in
 * 2021 with a 10-year term (expires 2031, ~5 years out) but an unregistered
 * 60-day window closing in 3 weeks came back 'expiring', wrong by
 * ~1800 days, on every warranty count/list/rollup/ranking/customer-file/
 * graph-node consumer that reuses this one function (see this file's own
 * module header and rollups/refresh.js, rankings.js, compose.js,
 * agent/tools.js, customerFile.js, graph/query.js — none of those
 * reimplement the bucket, so fixing it here fixes every one of them).
 *
 * The registration deadline remains available, unchanged, as its own signal
 * — never folded into this bucket again — via alertTier() directly (still
 * 'unregistered-window-closing') or registrationActionNeededOf() below, a
 * plain boolean wrapper for a caller that just wants "is registration
 * paperwork due soon" without the full tier enum.
 */
export function warrantyStatusOf(warranty, today) {
  if (!isPlausibleToday(today)) return 'unknown';
  const expires = warranty?.expires;
  if (!isValidYmd(expires)) return 'unknown';
  const days = daysBetween(today, expires);
  if (days === null) return 'unknown';
  if (days < 0) return 'expired';
  if (days <= 365) return 'expiring';
  return 'active';
}

/**
 * A distinct, separate-from-coverage flag: is this unit's REGISTRATION
 * paperwork deadline (not its coverage expiry) closing within 30 days with
 * nothing on file yet? This is exactly warrantyRules.alertTier()'s own
 * 'unregistered-window-closing' tier, named here for a caller that wants a
 * plain boolean without reasoning about the full tier enum — it composes
 * ALONGSIDE warrantyStatusOf's coverage bucket (a unit can be
 * registrationActionNeeded AND warrantyStatusOf === 'active' at the same
 * time, which is exactly the case this fix corrects for).
 */
export function registrationActionNeededOf(warranty, today) {
  return alertTier(warranty, today) === 'unregistered-window-closing';
}


/** "in Mesa" / "in Maricopa County" / "in AZ" / "in zip 85201" / "made by Trane": the scope words of a unit count, built from the plan's own filters. */
export function unitScopePhrase(filters) {
  const bits = [];
  for (const f of filters ?? []) {
    if (f.op !== 'eq') continue;
    if (f.field === 'city') bits.push(`in ${f.value}`);
    else if (f.field === 'county') bits.push(`in ${String(f.value).replace(/ county$/i, '')} County`);
    else if (f.field === 'state') bits.push(`in ${String(f.value).length <= 2 ? String(f.value).toUpperCase() : f.value}`);
    else if (f.field === 'zip') bits.push(`in zip ${f.value}`);
    else if (f.field === 'brand') bits.push(`made by ${f.value}`);
  }
  return bits.join(' ');
}
