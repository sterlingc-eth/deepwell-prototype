/**
 * Donovan self-learning loop, Tier 2 Part A (handoffs/DONOVAN_TRAINING_PLAN_2026-09-21.md):
 * thin wrappers around the platform-level (no tenant_id — see M3-config/
 * 26-donovan-learning.sql's own doc comment) SECURITY DEFINER functions that
 * read/write donovan_proposals/donovan_learned. Same idiom as
 * api/_lib/missDigest.js's own store calls: a plain getPool() connection (no
 * withTenant — nothing here is scoped to a tenant), one console.warn the
 * first time a call fails (migration not applied yet), and an empty/false
 * return rather than a throw from then on.
 *
 * This file is the only place in the codebase that writes to
 * donovan_proposals/donovan_learned directly — everything else (the pure
 * validation/verification engine, api/ask.js's overlay consumption) goes
 * through here or through learning/overlay.js's own read-only loader.
 */
import { getPool, withTenant } from '../recordsStore.js';

let warned = false;
function warnOnce(context, err) {
  if (warned) return;
  warned = true;
  console.warn(`donovan-learning: ${context} failed (M3-config/26-donovan-learning.sql may not be applied yet):`, err?.message);
}

/** Every active learned row, as {id, kind, key, value, created_at} — `id` is
 *  what a caller (api/review.js's learningDeactivate) sends back to
 *  deactivateLearned below. Empty array (never a throw) when the migration
 *  hasn't been applied yet. */
export async function listActiveLearned() {
  try {
    const { rows } = await getPool().query('SELECT * FROM learning_list_active()');
    return rows;
  } catch (err) {
    warnOnce('learning_list_active', err);
    return [];
  }
}

/** Inserts one proposal row. Returns its new id, or null on failure (table/
 *  function missing, or any other DB error) — never throws. */
export async function insertProposal({ kind, payload, evidence, verification, status, reason }) {
  try {
    const { rows } = await getPool().query(
      'SELECT learning_insert_proposal($1,$2,$3,$4,$5,$6) AS id',
      [
        kind,
        JSON.stringify(payload ?? {}),
        JSON.stringify(evidence ?? {}),
        JSON.stringify(verification ?? {}),
        status ?? 'pending',
        reason ?? null,
      ]
    );
    return rows[0]?.id ?? null;
  } catch (err) {
    warnOnce('learning_insert_proposal', err);
    return null;
  }
}

/** Lists proposals, most recent first, optionally filtered by `status`
 *  ('pending'/'approved'/'rejected'/'auto_rejected'/'auto_approved'). Empty
 *  array on failure. */
export async function listProposals({ status = null, limit = 100 } = {}) {
  try {
    const { rows } = await getPool().query('SELECT * FROM learning_list_proposals($1,$2)', [status, limit]);
    return rows;
  } catch (err) {
    warnOnce('learning_list_proposals', err);
    return [];
  }
}

/** One proposal by id, or null (not found, or the migration/function isn't
 *  applied yet). Used by api/review.js's learningDecide to RE-VERIFY a
 *  proposal's stored kind/payload against the CURRENT routing bank before
 *  approving it — a proposal can go stale between being proposed and an
 *  operator clicking Approve. */
export async function getProposal(id) {
  try {
    const { rows } = await getPool().query('SELECT * FROM learning_get_proposal($1)', [id]);
    return rows[0] ?? null;
  } catch (err) {
    warnOnce('learning_get_proposal', err);
    return null;
  }
}

/** Records an operator's (or the nightly job's auto-approve/auto-reject)
 *  decision on one proposal. An 'approved'/'auto_approved' decision also
 *  atomically writes the corresponding donovan_learned row (see
 *  learning_decide, M3-config/26). Returns true only when the proposal was
 *  actually found and updated; false on any failure, including a bad id. */
export async function decideProposal(id, status, decidedBy) {
  try {
    const { rows } = await getPool().query('SELECT learning_decide($1,$2,$3) AS ok', [id, status, decidedBy ?? null]);
    return Boolean(rows[0]?.ok);
  } catch (err) {
    warnOnce('learning_decide', err);
    return false;
  }
}

/** Same as decideProposal, plus a human-readable `reason` note on the row (M3-config/48's
 *  learning_decide_reason — learning_decide itself never touches the `reason` column). Used for the
 *  ROUND 14 capability_gap auto-resolve ("fixed — answered now") — see learning/replay.js's
 *  autoResolveCapabilityGaps. Falls back to plain decideProposal (losing only the note, never the
 *  status change) when migration 48 is not applied yet, so this never regresses to "does nothing". */
export async function decideProposalWithReason(id, status, decidedBy, reason) {
  try {
    const { rows } = await getPool().query('SELECT learning_decide_reason($1,$2,$3,$4) AS ok', [id, status, decidedBy ?? null, reason ?? null]);
    return Boolean(rows[0]?.ok);
  } catch (err) {
    warnOnce('learning_decide_reason', err);
    return decideProposal(id, status, decidedBy);
  }
}

/** Retires one learned row (sets active=false) without deleting it — the
 *  overlay loader (learning/overlay.js) only ever reads active=true rows, so
 *  this is how a bad learned item gets turned off without losing the
 *  history. Returns true only when a row was actually found and updated. */
export async function deactivateLearned(learnedId) {
  try {
    const { rows } = await getPool().query('SELECT learning_deactivate($1) AS ok', [learnedId]);
    return Boolean(rows[0]?.ok);
  } catch (err) {
    warnOnce('learning_deactivate', err);
    return false;
  }
}

/* ------------------------------------------------------------- exam gate (Workstream A, optional
 * M3-config/34-learning-exam-gate.sql)
 * Without that migration, recordExamResult/insertGapPromotion/listGapPromotions are no-ops (false/[])
 * — the gate itself still runs and still decides, it just cannot persist WHY (examGate.js's own doc
 * comment). Same "warn once, degrade" idiom as every other optional-migration function in this file. */

/** Records one proposal's exam-gate before/after result (migration 34's exam_before/exam_after/
 *  exam_sample/exam_run_id columns) — via a SECURITY DEFINER function, since donovan_proposals carries
 *  zero direct-write policies (see 26-donovan-learning.sql's own header). Returns true only when the
 *  row was found and updated. */
export async function recordExamResult(id, { examBefore, examAfter, examSample, examRunId } = {}) {
  try {
    const { rows } = await getPool().query(
      'SELECT learning_record_exam_result($1,$2,$3,$4,$5) AS ok',
      [id, JSON.stringify(examBefore ?? {}), JSON.stringify(examAfter ?? {}), Number.isFinite(examSample) ? Math.trunc(examSample) : null, examRunId ?? null]
    );
    return Boolean(rows[0]?.ok);
  } catch (err) {
    warnOnce('learning_record_exam_result', err);
    return false;
  }
}

/** One audit row per gap-cluster-or-otherwise proposal the exam gate actually promoted — an ordinary
 *  TENANT-scoped table (FORCE RLS + a tenant-isolation policy, same shape as donovan_learned_tenant),
 *  written through the caller's own withTenant connection like any other per-tenant write. `ctxArg` is
 *  whichever tenant's own exam data validated the promotion (normally the founder/operator tenant). */
export async function insertGapPromotion(ctxArg, { proposalId, kind, capability, examBefore, examAfter, examSample }) {
  try {
    await withTenant(ctxArg, (db) => db.raw(
      `INSERT INTO donovan_gap_promotions (tenant_id, proposal_id, kind, capability, exam_before, exam_after, exam_sample)
       VALUES ((current_setting('app.tenant_id', true))::uuid, $1, $2, $3, $4::jsonb, $5::jsonb, $6)`,
      [proposalId ?? null, kind, capability ?? null, JSON.stringify(examBefore ?? {}), JSON.stringify(examAfter ?? {}), Number.isFinite(examSample) ? Math.trunc(examSample) : 0]
    ));
    return true;
  } catch (err) {
    warnOnce('donovan_gap_promotions insert', err);
    return false;
  }
}

/** Up to `limit` of this tenant's own gap-promotion audit rows, newest first. Empty array on failure
 *  (migration not applied, or no rows yet). */
export async function listGapPromotions(ctxArg, { limit = 50 } = {}) {
  try {
    const { rows } = await withTenant(ctxArg, (db) => db.raw(
      `SELECT * FROM donovan_gap_promotions WHERE tenant_id = (current_setting('app.tenant_id', true))::uuid ORDER BY created_at DESC LIMIT $1`,
      [Math.max(1, Math.min(200, Math.trunc(limit) || 50))]
    ));
    return rows;
  } catch (err) {
    warnOnce('donovan_gap_promotions list', err);
    return [];
  }
}

/* ------------------------------------------------------------------ recipes
 * M3-config/29-donovan-recipes.sql (OPTIONAL): 'recipe' proposals/learned rows. Without that
 * migration these return empty/false and Donovan simply keeps its old behaviour. */

/** Every recipe proposal (any status) for one normalized question, newest first. */
export async function findRecipes(question) {
  try {
    const { rows } = await getPool().query('SELECT * FROM learning_find_recipes($1)', [String(question ?? '')]);
    return rows;
  } catch (err) {
    warnOnce('learning_find_recipes', err);
    return [];
  }
}

/** Replaces a still-PENDING recipe proposal's payload/evidence (a re-observation). */
export async function updateRecipeProposal(id, payload, evidence) {
  try {
    const { rows } = await getPool().query('SELECT learning_update_proposal($1,$2,$3) AS ok', [id, JSON.stringify(payload ?? {}), JSON.stringify(evidence ?? {})]);
    return Boolean(rows[0]?.ok);
  } catch (err) {
    warnOnce('learning_update_proposal', err);
    return false;
  }
}
