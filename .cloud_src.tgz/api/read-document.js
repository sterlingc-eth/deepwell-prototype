import { armResponseDeadline } from "./_lib/util/deadline.js";
import { denyAuth } from "./_lib/auth.js";
import { handleCors, handleError } from "./_lib/claude.js";
import { ingestDocument, recordIngestFailure, isTransientError, isValidDocumentId } from "./_lib/readDocument.js";
import { isQueueEnabled, enqueueDocument, shouldRequeue } from "./_lib/queue.js";
import { withTenant } from "./_lib/recordsStore.js";
import { requireAuthOrKey, assertScope } from "./_lib/apiKeyAuth.js";
import { limit, assertModelBudget, sendModelBudgetExceeded } from "./_lib/rateLimit.js";
import { assertActiveBilling } from "./_lib/plan.js";

/**
 * POST /api/read-document
 * body: { documentId, sync?: boolean, extract?: boolean }
 *
 * -> queued:  202 { documentId, queued: true }
 * -> inline:  200 { documentId, pages, method, queued: false }
 *
 * Step two of ingestion, and the bridge between the two stores: pull the bytes
 * back out of R2, turn them into text, and write that text into Postgres as
 * document_pages rows. /api/ask then searches those rows.
 *
 * Not to be confused with /api/extract, which is a different job: this one
 * transcribes a whole stored document into searchable page text; that one reads
 * the page text back and pulls canonical fields out of it. Both are needed;
 * they are separate routes on purpose, and the queue chains them.
 *
 * Two modes, and which one runs is decided by configuration, not by the caller:
 *
 *   queue on  (INNGEST_EVENT_KEY set) — hand the document to Inngest and return
 *     202 immediately. The browser polls /api/document-status. This is what
 *     makes a 200-document drop survivable: each document is a durable run that
 *     retries on its own, and nothing is bounded by one 60-second request.
 *
 *   queue off (no key) — do the work inline and return 200, exactly as this
 *     endpoint behaved before the queue existed. Deploying this change with no
 *     Inngest configuration therefore changes nothing, which is the point.
 *
 * `sync: true` forces inline regardless, for scripts and verification runs that
 * want the result rather than a promise of one.
 *
 * Plain text and CSV are decoded directly; there is no reason to pay a model to
 * read a file that is already text. PDFs and images go to Claude, which reads
 * scanned pages as well as digital ones — an HVAC office's documents are mostly
 * phone photos of equipment plates and faxed warranty cards, so OCR that only
 * handled clean PDFs would miss most of the corpus.
 */
export const config = {
  api: { bodyParser: { sizeLimit: "16kb" } },
  maxDuration: 60,
};

export default async function handler(req, res) {
  if (req.method === "OPTIONS") return handleCors(res, req).status(204).end();
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
  armResponseDeadline(res, 52_000); // maxDuration is 60s

  let auth;
  try {
    auth = await requireAuthOrKey(req);
    assertScope(auth, "ingest");
  } catch (err) {
    return denyAuth(res, err);
  }

  if (!(await limit(req, res, auth, "ingest"))) return; // 429 already written

  // `force: true` re-reads a document that already has pages (after a
  // transcription fix, say). Only honored on the inline path so the queue's
  // idempotency guard keeps protecting bulk imports from double-paying.
  const { documentId, sync = false, extract = true, force = false } = req.body ?? {};
  if (typeof documentId !== "string" || !documentId) {
    return res.status(400).json({ error: "documentId is required" });
  }
  // Checked here (not just inside ingestDocument) so a malformed id never
  // reaches enqueueDocument either — the queued path has no other guard
  // before Inngest, and 500ing a document into existence in Inngest's retry
  // history is worse than a clean 400 up front.
  if (!isValidDocumentId(documentId)) {
    return res.status(400).json({ error: "documentId must be a uuid" });
  }

  const ctx = { tenantKey: auth.tenantId, tenantName: auth.orgId ?? auth.tenantId };

  // HARD GATE (Reviewer NO-GO, 2026-09-21): a tenant with no active
  // subscription must not be able to spend a real Anthropic-billed model
  // call reading a document — checked here, before EITHER path below
  // (queued or inline, including `force: true`), since the queued path
  // never calls assertModelBudget itself in this file (queue.js does its
  // own budget check once Inngest picks the run up, which is too late to
  // stop a 'none'/'canceled' tenant from having successfully enqueued it).
  // Fails CLOSED — see assertActiveBilling's own doc comment.
  const billingGate = await assertActiveBilling(ctx);
  if (!billingGate.allowed) {
    return handleCors(res, req).status(billingGate.status).json({ error: billingGate.error, ...(billingGate.url ? { url: billingGate.url } : {}) });
  }

  // ---- queued ------------------------------------------------------------
  if (isQueueEnabled() && !sync) {
    try {
      // R30 M7: a nonce on the Inngest event id ONLY for an explicit re-queue of a dead run (see shouldRequeue);
      // an automatic duplicate keeps the fixed id and is deduped. The row lookup is best effort.
      let requeueNonce = null;
      try {
        const row = await withTenant(ctx, (db) => db.getDocument(documentId));
        if (shouldRequeue(row, { explicit: req.body?.requeue === true || force === true })) requeueNonce = Date.now().toString(36);
      } catch (lookupErr) {
        console.error("read-document: requeue check failed (using the deduped id):", lookupErr?.message);
      }
      await enqueueDocument({
        documentId,
        tenantKey: auth.tenantId,
        tenantName: auth.orgId ?? auth.tenantId,
        userId: auth.userId,
        autoExtract: extract !== false,
        requeueNonce,
      });
      // `extract` tells the browser whether a second stage is coming. Without
      // it the poller would call the document finished the moment the read
      // step set extracted_at, and report zero fields on a document whose
      // extraction had not started yet.
      return handleCors(res, req)
        .status(202)
        .json({ documentId, queued: true, extract: extract !== false });
    } catch (error) {
      // Inngest being unreachable must not cost the user their upload. Fall
      // through and do it inline; a slow ingest beats a lost one.
      console.error("Enqueue failed, running inline:", error?.message);
    }
  }

  // ---- inline ------------------------------------------------------------
  try {
    // B1 (2026-09-19 adversarial audit): the queue's Inngest wrapper has
    // always checked the daily model-spend budget before spending it (see
    // queue.js) — this inline path (the documented DEFAULT when
    // INNGEST_EVENT_KEY/INNGEST_SIGNING_KEY are unset, or a `sync: true`
    // caller) never did, so a deployment running without the queue had NO
    // budget enforcement on ingestion at all. Checked before ingestDocument
    // regardless of this document's content type (plain text costs no model
    // call either way, but knowing that would mean fetching its bytes just to
    // find out — cheaper and simpler to check once, unconditionally, exactly
    // like the queue's own check does).
    await assertModelBudget(ctx);
    const result = await ingestDocument(ctx, documentId, { userId: auth.userId, force: force === true });
    return handleCors(res, req).status(200).json({ ...result, queued: false });
  } catch (error) {
    if (error?.name === "ModelBudgetExceededError") {
      return sendModelBudgetExceeded(handleCors(res, req), error);
    }
    // Recording a failure is a one-way door on this path: the browser polls
    // document-status and treats any extract_error as terminal, so a document
    // stamped here is a document the technician is told to give up on. That is
    // the right answer for a file we genuinely cannot read, and the wrong one
    // for a rate limit that clears in four seconds — which is the single most
    // likely thing to happen when someone drops a folder of 200 files on a
    // deployment running ingestion inline. Transient failures are reported as
    // retryable and left OFF the document.
    const transient = isTransientError(error);

    if (error?.name === "IngestError") {
      // markExtracted already ran, inside ingestDocument itself, for both the
      // unsupported-type case (415) and the no-readable-text case (422) — see
      // readDocument.js. Recording it again here would just overwrite the
      // same message with itself, so both are skipped; everything else still
      // needs it so the document does not sit at 'received' silently.
      if (error.status !== 415 && error.status !== 422 && !transient) {
        await recordIngestFailure(ctx, documentId, error);
      }
      return handleCors(res, req).status(error.status ?? 400).json({ error: error.message });
    }

    if (transient) {
      console.error("Transient ingest failure, not recorded:", error?.message);
      const out = handleCors(res, req);
      out.setHeader("Retry-After", "10");
      return out.status(503).json({
        error: "Busy right now — this document has not been read yet. Try again in a moment.",
        retryable: true,
      });
    }

    await recordIngestFailure(ctx, documentId, error);
    return handleError(res, error, req, { tenantId: auth.tenantId, documentId });
  }
}
