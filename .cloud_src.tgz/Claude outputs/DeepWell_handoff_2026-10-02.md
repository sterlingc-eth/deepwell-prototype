# DeepWell handoff — start here in a new conversation (2 Oct 2026)

Paste this into a new chat in the DeepWell project, or just say "read claude/HANDOFF_2026-10-02.md".

## Where things stand
- **Donovan exam:** 1,704 questions · 1,596 answered without AI · 1,576 correct · 0 wrong · 12 need AI.
- **Delivered to the repo folder this session (push if not yet pushed):** company/team wording (R37), "Team" plan name + roadmap section (R38–39), streamlined website (R40), speed fixes for 50,000 documents (R41), staff import tool (R43), website inquiry form (R44).
- **Load test:** 50,000 documents on a real Neon test branch `loadtest-50k`; after fixes Customers list 15–20 ms, Donovan page lookup about 100 ms. The branch is still there (about 15 cents a month) — delete when no longer needed.
- **Agent crew:** Sentinel (errors hourly + security Thursdays), Lighthouse (ops hourly), The Loop (hourly Donovan), Forge, Compass, Sprint, Radar, Brandy (finance, daily), Isaac (business, daily), Atlas (engineering plan, Tue/Fri). Charters: `claude/crew/CREW_CHARTERS.md`. Roster page: artifact "DeepWell Agent Crew". Costs and profit: artifact "DeepWell Profit Plan".
- **Books to read when a topic comes up:** `claude/crew/BRANDY_FINANCE_BOOK.md`, `ISAAC_BUSINESS_BOOK.md`, `ATLAS_ENGINEERING_PLAN.md`, `SENTINEL_SECURITY_BOOK.md`; round notes `claude/ROUND37…ROUND44`.

## Sterling's to-do list
1. Push the latest changes in GitHub Desktop.
2. Neon, paste in order: `65-scale-donovan-and-customers.sql`, `66-staff-import-override.sql`; optional `61-support-assistant.sql` (tighter spam limits for chat and the inquiry form).
3. Send a test inquiry from the live site; confirm the email to hello@ and the visitor confirmation both arrive.
4. Stripe: rename product "DeepWell Shop" to "DeepWell Team" (do not re-run the Stripe setup script first).
5. The Loop still stops every hour because no repo folder is attached to it: in the desktop app, attach the deepwell-prototype folder to The Loop, Forge, Compass and Sprint.
6. Security, this week (about 3 hours; steps in Sentinel's book): Voyage training opt-out, Neon history to 7 days, DMARC + Google DKIM, two-step sign-in + recovery codes on the six accounts that can read customer data, Anthropic spend limit, rotate keys that appeared in screenshots.
7. Anthropic: ask for a higher limit and turn on auto-reload (can take a week).
8. Import tool: first real run should be a small test folder on the test company (runbook: `handoffs/IMPORT_RUNBOOK.md`).

## Decisions waiting on Sterling
- Approve the flat setup fee by size (free up to 5,000 documents, $750, $1,950, $3,500), waived with a year of Crew or Fleet?
- Reprice Records Rescue for paper (about $0.22 a page with a scanning partner)?
- Google Drive: one-time import included, ongoing sync on Crew and above?
- Have Atlas spec batch processing (about half the AI reading cost on big imports)?
- Branch scoping: build now with the suggested defaults, or after the first customer?

## Working rules (unchanged)
Cheapest model that does the job; never push or run git in the owner's folder; never read secrets; no SQL on the live database (the load test on the test branch was a one-time exception Sterling approved); agents are read-only on vendor dashboards; files are delivered to the repo folder only after the base files match.
