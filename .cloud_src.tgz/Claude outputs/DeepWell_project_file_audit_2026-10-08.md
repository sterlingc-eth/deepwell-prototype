# DeepWell project files: what can be deleted (audit 2026-10-08)

Every document in the project was opened and read by an audit agent (220 documents) and the 17 code patches were judged by the coordinator. Nothing has been deleted. Three superseded patch files were emptied to free space because the project was at 1.91 of 2.00 million and running teams could no longer save.

## Summary

| Verdict | Files | Approx. size |
|---|---|---|
| Safe to delete now | 105 | 784,260 |
| Delete after the current rounds finish | 10 | 30,650 |
| Needs your decision first | 17 | 138,400 |
| Keep: only record of a decision or finding | 7 | 102,000 |
| Keep: in use | 98 | 1,186,500 |

## Safe to delete now

| File | Why |
|---|---|
| AI_INTEGRATION_PLAN.md | Sept 11 prototype planning doc; Ask and extraction are now built and it is superseded. |
| BUILD1_INTEGRATION_2026-10-05.md | Integration finished; page counter, office files and uploadTypes are on main. |
| BUILD_QUEUE_STATUS_ELECTRICAL.md | One-line status of a build run; BUILD2QA_ELECTRICAL_PROGRESS holds the current state. |
| CODE_REVIEW_DONOVAN_2026-10-03_REVIEWER_NOTES.md | Raw reviewer notes behind CODE_REVIEW_DONOVAN; the combined report carries the findings and ranking. |
| CODE_REVIEW_PHONE_WEBSITE_2026-10-03_APPENDIX.md | Raw reviewer reports; every finding is carried in the combined phone and website review. |
| CONVERSATION_V1.2_START_SUMMARY.md | Sept 11 prototype session summary; superseded by later milestones. |
| DEEPWELL_PRODUCT_REDESIGN_V2.md | Sept 10 prototype redesign, superseded by the Sept 12 Ask decision and later milestones. |
| DESIGN_SYSTEM_IMPLEMENTATION_PROGRESS.md | Navy and copper prototype progress log, superseded by the forest-green brand decision of Sept 12. |
| DONOVAN_CAPABILITY_AB_COORD_REVIEW.md | Review round 1 of the capability patch; its defects were fixed and review 2 supersedes it. |
| DONOVAN_CAPABILITY_AB_COORD_REVIEW_2.md | Review round 2 of the capability patch; superseded by DONOVAN_CAPABILITY_AB_REPORT, whose denial rule is on main. |
| DONOVAN_CAPABILITY_STATUS.md | Run status log for capability rounds; the latest state is in DONOVAN_CAPABILITY_AB_REPORT. |
| DONOVAN_FALLBACK_PROMPT_2026-09-23.md | One-off recovery prompt for a fresh chat; the agent loop it asked for is in main (api/_lib/agent/loop.js, tools.js, shape.js). |
| DONOVAN_FIX_ROUND_2026-10-03.md | Finished Oct 3 fix round; amountWords and docFieldAsk are on main and later Donovan rounds through R41 supersede it. |
| DONOVAN_LITERATURE_REVIEW_2026-09-26.md | Top-10 items were built in R10-R11 or superseded; no current doc found citing it. |
| DONOVAN_LIVE_TEST_2026-10-07.md | Earlier live run, superseded by DONOVAN_LIVE_RETEST; its open points are repeated there. |
| DONOVAN_NIGHTLY_REPORT_FORGE.md | Report of finished Forge fix round; fix is on main. |
| DONOVAN_NIGHTLY_STATUS.md | Status line of a finished fix round; rephrase.js and the fix are on main. |
| DONOVAN_PREMIER_BUILD_2026-09-24.md | Delivered build report; phases 1-5 (scorecard, search, financials, escalation) are in main. |
| DONOVAN_R16_INNOVATION_RESEARCH.md | Top three ideas shipped in R17; the remaining ideas are unbuilt and have no owner decision. |
| DONOVAN_R40_REPRO_2026-10-07.md | Diagnosis notes for the R40 hotfix, which is on main; the defects described are its targets. |
| DONOVAN_R40_STATUS.md | Status log of the R40 hotfix run; its open items live in DONOVAN_ROUND40_HOTFIX (not in this batch). |
| DONOVAN_RECORDS_REPORT_TEAM1.md | Losing parallel round 1 build; patch not used; findings duplicated in the ORIGINAL round 1 report and REPORT_R2. |
| DONOVAN_RECORDS_REPORT_TEAM2.md | Losing parallel round 1 build; its patch was not used; process note only. |
| DONOVAN_RESEARCH_BRIEF_2026-10-08.md | One-off brief for the finished RESEARCH-R1 run. |
| DONOVAN_RESEARCH_DEEP_TRACKS_2026-10-08.md | Owner's instructions for a finished research run; the run is over. |
| DONOVAN_RESEARCH_STATUS.md | Status log of finished research runs; all four tracks marked DONE. |
| DONOVAN_ROUND10_2026-09-26.md | Delivered round; knowledge graph and contextual retrieval shipped (api/_lib/graph). |
| DONOVAN_ROUND11_2026-09-26.md | Delivered round; graph, entity merge, decomposition, claim checks and semantic cache are in main. |
| DONOVAN_ROUND12_2026-09-26.md | Delivered round; smart names and zero-touch intake are in main (api/_lib/naming, api/_lib/intake/autofill.js). |
| DONOVAN_ROUND13_2026-09-26.md | Delivered round; sentence citations, intake queue, grid view and faster startup are in main (api/_lib/citations/sentences.js). |
| DONOVAN_ROUND14_2026-09-26.md | Delivered round; provider-outage honesty and suggestions are in main; owner steps are historical. |
| DONOVAN_ROUND15_2026-09-26.md | Delivered round; its generalization questions became the field-phrasing exam in R16. |
| DONOVAN_ROUND16_2026-09-26.md | Delivered round; the address policy is in fastPathQuery.js and in the memory decisions file. |
| DONOVAN_ROUND17_2026-09-26.md | Delivered round; proactive insights and the offline upload queue are in main (scripts/offline-queue-harness). |
| DONOVAN_ROUND18_2026-09-27.md | Undelivered nightly version, explicitly superseded by ROUND18_INTERACTIVE; its patch must not be applied. |
| DONOVAN_ROUND18_INTERACTIVE_2026-09-27.md | Delivered round report that supersedes the nightly R18 patch; the work is in main. |
| DONOVAN_ROUND35_2026-10-03.md | Finished nightly check with no code changes; superseded by rounds R36-R41 now in the product. |
| DONOVAN_ROUND37_2026-10-05.md | No-change nightly round; numbers folded into the roadmap. |
| DONOVAN_ROUND38_2026-10-05.md | Round 38 shipped: tenant generators and vocabCount.js are on main; history only. |
| DONOVAN_ROUND39_2026-10-06.md | Round 39 shipped: leftover.js and verify-r39 script are on main; named identifiers ROW_FETCH_CAP and unknownbrand not found. |
| DONOVAN_ROUND8_2026-09-26.md | Delivered round; job costing and the data-export button are in main; owner steps are historical. |
| DONOVAN_ROUNDS19-20_2026-09-27.md | Delivered round report; its code is in main (api/_lib/router/classifyAll.js, followup/). Kept as history only. |
| DONOVAN_V2_RESEARCH_AGENT_2026-09-25.md | Delivered: the agent loop, tools and knowledge work are in main (api/_lib/agent/loopV2.js). |
| DeepWell_Days2-3_Assembly_Complete.md | Sept 9 prototype assembly report; superseded. |
| FEATURE_SCOPING_STATUS.md | Two status lines of a finished scoping run; specs and queue hold the output. |
| FINANCIALS_DESIGN_2026-09-21.md | Built: 22-document-financials.sql, FinancialStrip and FinancialsCard are on main; design is implemented. |
| FORGE_DEEPDIVE_STATUS.md | One-line status of a finished deep dive; the deep dive document holds the content. |
| FORGE_PROMISES_ROWS_2026-10-07.md | Raw per-phrasing output of the promise bank; regenerable with the script on main; summary kept in FORGE_DEEPDIVE. |
| HILTON_ARRIVAL_BRIEF.md | One-off onboarding brief for Hilton's Sept 13 arrival; its M2 status is long superseded. |
| INTEGRATION_2026-10-03.md | Superseded by BUILD1_INTEGRATION_2026-10-05; code on main. |
| INTEGRATION_COMPLETE_SUMMARY.md | Sept 9 prototype completion report for the Corey demo; superseded. |
| INTERACTION_DESIGN_COMPLETE.md | Sept 10 prototype interaction specs for screens that were since replaced. |
| LEAD_ARCHITECT_BRIEF.md | Sept 10 prototype build brief for a Sept 15 demo that has passed. |
| LIMIT_TEST_DESKTOP_WEB_2026-10-03_RAW_FINDINGS.md | Raw desktop tester, web and reviewer notes; findings are carried in LIMIT_TEST_DESKTOP_WEB. |
| LIMIT_TEST_DONOVAN_2026-10-03.md | One-off Donovan limit test; its date fix and permanent test sets are on main (verify:lt-donovan) and the fix round covered most findings. |
| LIMIT_TEST_MOBILE_2026-10-03.md | First full phone run; results are carried forward into LIMIT_TEST_PHONE, which keeps the open items. |
| LIMIT_TEST_WEBSITE_REVIEW_2026-10-03.md | Independent review of the website limit test; its findings and replacement wording are carried in LIMIT_TEST_WEBSITE. |
| LIMIT_TEST_WEBSITE_TESTER_A_2026-10-03.md | Raw tester notes for the website test; findings and open items are carried in LIMIT_TEST_WEBSITE. |
| LOGO_DESIGN.html | Stray upload: content is a TypeScript barrel export, not a logo design. |
| M3_INFRASTRUCTURE_SETUP.md | Pre-flight account checklist; accounts and M3 build are done (M3-config 01-39 and r2.js on main). |
| M3_PLAN.md | Build plan for M3, which is substantially on main (M3-config 01-39, r2.js, tenant deletion and billing code). |
| MOBILE_DISTRIBUTION_2026-09-25.md | Shipped: the public/get install page and QR code are in main. |
| MOBILE_PWA_2026-09-25.md | Shipped: the /m PWA with Ask, Scan and Docs tabs is in main (public/m/sw.js); status doc only. |
| MOBILE_ROUND_2026-10-05.md | No-change scheduled round; nothing delivered. |
| MOBILE_ROUND_2026-10-06.md | No-op scheduled round; nothing changed or delivered. |
| OFFICE_FILES_BUILD_2026-10-03.md | Office-file reader and allow-list are on main (api/_lib/office, uploadTypes). One-off build record; its open decisions are carried here. |
| OFFICE_FILES_REVIEW_2026-10-03.md | Review of the office-files build; F1-F4 and F6 fixes verified on main (api/_lib/office present, fixtures .gitignore is files/). Superseded by the build doc. |
| OnSiteSearchScreen.tsx | Stray upload: filename says TSX but content is CSS; not a document. |
| PACKS_SLICE1A_2026-10-02.md | Finished slice; resolver.js with packsForTenant and invalidatePacksCache is on main. |
| PAGE_COUNTER_REVIEW_2026-10-03.md | Reviewer report for the page counter; its conditions were applied in PAGE_COUNTER_FIX and migration 67 is on main. |
| PATCH_DONOVAN_CAPABILITY_AB.patch | Capability round 3 is live on main |
| PATCH_DONOVAN_NIGHTLY.patch | Forge rephrase fix is live on main |
| PATCH_DONOVAN_RECORDS.patch | Round 1, superseded; already emptied |
| PATCH_DONOVAN_RECORDS_TEAM1.patch | Unused round 1 variant; already emptied |
| PATCH_DONOVAN_RECORDS_TEAM2.patch | Rejected round 1 variant; already emptied |
| PATCH_MOBILE_2026-10-03.manifest.txt | Manifest md5s match main exactly (ShareButton.tsx, MobileAnswer.tsx); patch applied. |
| PATCH_SECURITY_R1.patch | Security fixes are live on main |
| PATCH_UX_2026-10-06.manifest.txt | Manifest for a patch already applied on main. |
| PREMIUM_DESIGN_DELIVERABLES.md | Navy and copper design deliverables for the prototype; superseded and cites docs not in the project. |
| PROMO_VIDEO_PROMPT.md | One-off master prompt for a promo render; the run is over. |
| R12_PRODUCT_RESEARCH_2026-09-26.md | Research whose top-12 list is shipped in R12-R13 or superseded; kept for history only. |
| R23_WEB_RESEARCH_2026-09-28.md | One-off research for a paid test that has passed; ranked items superseded by later Donovan rounds and research docs. |
| RADAR_2026-10-02.md | Superseded by RADAR_2026-10-06 and 10-08; its top three items are tracked in LOOP_BACKLOG. |
| RADAR_2026-10-06.md | Daily radar run with nothing new; no decision or work depends on it. |
| RADAR_2026-10-07.md | One-day web scan; nothing actionable now. |
| README_INDEX.md | Index of a one-time Sept 13 export to another system; holds no decisions or status. |
| ROUND28_SUPPORT_BOT_SITE_2026-09-29.md | Round delivered; the support assistant is in main (api/_lib/support) and handoffs/SUPPORT_ASSISTANT_R28.md is the reference. |
| SECURITY_DEEPTEST_BRIEF_2026-10-07.md | One-off test brief for security round 1; round finished and the report covers it. |
| SECURITY_DEEPTEST_STATUS.md | One-line status of finished security round 1; the report carries the findings. |
| SITE_INDUSTRIES_2026-10-06.md | Five industry pages with motion are on main (motion tokens verified); report is finished history. |
| SITE_MOTION_2026-10-07.md | Home-page motion patch; index.html on main already has the play-once motion classes. |
| SITE_NEWPAGES_2026-10-06.md | Four industry pages are on main and who.html links to them; report is finished history. |
| STERLING_DEPLOYMENT_GUIDE.md | Sept 11 walkthrough for deploying the early prototype; superseded by the current deployment. |
| UX_ROUND2_2026-09-29.md | No-audit status doc written while the device was offline; superseded by UX_ROUND8_2026-10-08, and the typo case now has end-to-end tests. |
| UX_ROUND7_2026-10-06.md | Round finished; its harness patch is already on main (backend.mjs line 60). |
| VERIFY_GATE_TRIAGE_2026-10-02.md | Finished test-gate triage; test-file fixes applied; only the scorecard generator drift remains. |
| WEBSITE_REPOSITION_2026-10-02.md | Delivered: origin/main index.html already carries the neutral copy, for example "Made for any business with paperwork". |
| animation-implementation-day2-3-summary.md | Sept 9 prototype animation summary for screens since replaced. |
| crew/ISAAC_GRANT_SEARCH_2026-10-06.md | Superseded by ISAAC_GRANT_SEARCH_NM; Arizona programs are dead and its other items are carried into the NM doc. |
| crew/ISAAC_MONDAY_BRIEF_2026-10-03.md | One-off brief for the Monday 10/05 presentation; that run is over. |
| deepwell-financial-model-cycle-1.md | Sept 8 financial model with $99, $299 and $999 tiers, superseded by later pricing work. |
| deepwell-technical-strategy-cycle3.md | AWS, Textract and Weaviate architecture superseded by the Neon and R2 stack; CAC and pricing sections superseded. |
| deepwell-test-scenarios.md | Sept 9 synthetic Corey field-test scenarios; superseded by test-docs/question-bank and docs/EVAL_QUESTIONS.md. |
| download | Stray upload: a Tailwind config from the prototype, not a document. |
| index.css | Stray upload: content is a React component (SearchResult), not CSS. |

## Delete after the current rounds finish (still being read by a running team or pending verification)

| File | Why |
|---|---|
| DONOVAN_LIVE_CONSISTENCY_2026-10-08.md | Live test notes of an earlier build; its 10 x 3 questions feed the records verify suite and are addressed by rounds 1-2. |
| DONOVAN_RECORDS_COORD_REVIEW_1.md | Round 1 verification; superseded by round 2 (on origin/main); records the choice of ORIGINAL over TEAM1. |
| DONOVAN_RECORDS_COORD_REVIEW_2.md | Round 2 verification; round 2 is on origin/main (api/_lib/records/lane.js, ask.js); superseded by R3 work. |
| DONOVAN_RECORDS_FIRST_BRIEF_2026-10-08.md | One-off brief for records round 1; built and on origin/main (api/_lib/records/lane.js, DONOVAN_RECORDS_FIRST). |
| DONOVAN_RECORDS_REPORT.md | Round 1 report superseded by round 2, which is on origin/main (records lane). |
| DONOVAN_RECORDS_STATUS.md | Running status log of finished records rounds; latest state is recorded in REPORT_R3. |
| EMAIL_TO_FILE_BRIEF_2026-10-07.md | One-off build brief for the email-to-file run; run finished and the report supersedes it. |
| EMAIL_TO_FILE_STATUS.md | Status log line of a finished, NOT-CLEAN run; the report holds the same facts. |
| PATCH_DONOVAN_RECORDS_R2.patch | Live on main; the running round 3 team still reads it |
| RADAR_2026-10-08.md | One-off daily radar output; nothing actionable; backlog unchanged. |

## Needs your decision first

| File | Why | What is open |
|---|---|---|
| BUILD2E_RANGE_LANE_HELD.patch | Held on purpose; needs a decision | - |
| Corey_Interview_Guide.md | Interview script with no answers recorded; findings may live in a document not in this batch. | Owner: confirm whether Corey call notes exist elsewhere before deleting the guide. |
| DONOVAN_CAPABILITY_PROMPT_2026-10-07.md | One-time run prompt for the capability round; its Part C pilot work (coffee shop, dog shelter) has no record elsewhere. | Owner decides whether pilot work (question lists, pilot guides, per-pilot document lists) is still wanted; if yes keep this prompt, if no delete. |
| DONOVAN_LIVE_RETEST_2026-10-08.md | Live re-test notes; several defects appear in no other list. | Owner: copy open items (how-to "mark paid" answered with data; 24 s grace-period dead end; Carrier/Trane read as names; "Sorensen" customer data) into a tracker, then delete. |
| DONOVAN_RECORDS_REPORT_R2.md | Round 2 final report; round 2 shipped, but its open-defect list lives only here and partly in the R3 report. | Owner: decide whether to carry the open defects (multi-fact, shop-wide aggregates, "who owes me" declines, "list invoices from 2026") into a live list before deleting. |
| LIMIT_TEST_BACKEND_2026-10-03.md | One-off Donovan and back-end limit test; several Donovan defects may still reproduce on main and this file is the only list of them. | Owner must confirm which still reproduce: dates/amounts written differently, short invoice numbers, yes/no comparisons, count of 500, lead-in words, same-name money, SQL definer functions. |
| LIMIT_TEST_WEBSITE_TESTER_B_2026-10-03.md | Raw tester notes; the 117-question chat table exists only in this file and its defects are summarised in LIMIT_TEST_WEBSITE. | Owner decides whether to keep the chat table as a test record; open chat defects C-01 to C-08 (HIPAA/GDPR answered as SOC 2, 'Yes.' to No questions, refusals) are in LIMIT_TEST_WEBSITE. |
| OFFICE_FILES_WORDING_CHANGES_2026-10-03.md | Word/Excel wording changes: index.html lacks the new text on main; help-doc edits unverified. | Owner approves or reverts the five website wording hunks (index.html, industry pages); then this log can go. |
| PAGE_COUNTER_FIX_2026-10-03.md | Migration 67 and counter code are on main, but nothing here or in the repo records whether the SQL was run on Neon. | Owner must confirm M3-config/67 was run and the post-SQL checks passed (this file is then the only copy of them); Rescue decision and read-then-delete hole still open. |
| PATCH_BUILD1_WEBSITE_WORDING.patch | Website wording: needs owner approval or already applied; not yet checked | - |
| PATCH_INTEGRATION_WEBSITE_WORDING_2026-10-03.patch | Website wording; not yet checked | - |
| PATCH_MOBILE_2026-10-03.patch | Not yet checked against main | - |
| PATCH_PAGE_COUNTER_RESCUE_OPTIONAL_2026-10-03.patch | Optional; owner decision on Rescue still open | - |
| PATCH_UX_2026-10-06.patch | Not yet checked against main | - |
| REQUIREMENTS_TRACEABILITY.md | Sept 13 M2-era scorecard still labelled source of truth; many rows (dashboards, exports, email intake) are stale. | Owner decides: refresh this scorecard against main, or delete it. |
| deepwell-hvac-ecosystem-analysis.md | Sept 9 go-to-market and integration roadmap; its $150 pricing conflicts with later pricing work. | Owner decides whether the integration order (Drive, FieldEdge, ServiceTitan, Jobber) and channel plan are still the roadmap, then keep or delete. |
| hvac-workflow-research-synthesis.md | Secondary-source workflow research (not customer research) behind the MVP moments; may still justify roadmap items. | Owner decides whether it still backs roadmap work; the contractor validation steps it lists have no recorded outcome. |

## Keep: only record of a decision or finding (move the open items somewhere current before ever deleting)

| File | Why | What is open |
|---|---|---|
| DISCOVERY_WARRANTY_WORKFLOW.md | Only record of Richie's customer discovery: registration workflow and unprompted interest in extended-warranty reminders. | Richie questions: are registration confirmations kept, brands and portals used, units per month, who acts on reminders. |
| LIMIT_TEST_ISOLATION_LIMITS_2026-10-03.md | Only record of open security findings from the isolation test; the FK-ownership and support-log fixes are on main. | Open: SECURITY DEFINER functions lack caller checks; read-scope API keys reach export; stale-role window; site copy vs support emergency path; merge-tenant bypasses document cap. |
| PRODUCT_DECISION_ASK_INTERFACE.md | Only written record of the binding Ask-first and ingestion-discipline decision and the no-"AI" copy rule. | - |
| SECURITY_DEEPTEST_REPORT_2026-10-07.md | Only record of open security findings (fail-open limits, DB role grants, RLS gap, suspected live-data preview exposure); not yet decided by owner. | Owner decides: fail-open vs fail-closed limits; whether preview deployments use the live database; DB role grants; FORCE RLS migration; platform AI spend ceiling. |
| START_HERE_NEXT_SESSION.md | Superseded by HANDOFF_2026-10-02, but the only written record of the owner's duplicate-merge data rule. | Move the merge rule (name, address, phone and email must agree; near-misses go to review) and open items (Google OAuth verification, customer-journey walkthrough, promo video) into a current doc, then delete. |
| STORAGE_COST_AND_PRIVACY_PLAN.md | Only written rationale for the Neon plus R2 storage choice (zero egress, no vector DB), with sources. | Re-check vendor pricing before any further account changes, as the doc itself says. |
| deepwell-mvp-feature-spec.md | Only written record of the EPA 608, AZ and NV licensing and retention notes and the Corey go/no-go gates; scope itself is superseded. | - |

## Keep: in use

| File | Why |
|---|---|
| ALACARTE_R31.md | Add-on pricing strategy cited by Atlas and the handoff; the add-ons are not built (no warrantyDesk module on main). |
| ANIMATION_RESEARCH_PROMPT_MOTION_2026-10-06.md | Research cited by the pending polish-round decisions; ideas only, no code. |
| BUILD2QA_ADDING_TRADES_DESIGN.md | Open design proposal for multi-trade companies; nothing built; awaiting owner decision. |
| BUILD2QA_ELECTRICAL_PROGRESS.md | Electrical lane on build2 is not clean after seven loops; not on main; open low items remain. |
| BUILD2QA_PLUMBING_PROGRESS.md | Plumbing lane on build2 not clean after six loops; screen-change requests not applied. |
| BUILD2QA_PROPERTY_PROGRESS.md | Property lane on build2 still NOT-CLEAN after ten review loops; open shared requests and low items remain. |
| BUILD2QA_REPORT.md | Only record of open loop-3 defects in build2 plumbing and property; not clean. |
| BUILD2QA_TEST_MAP.md | Feature-by-feature test map for the separate end-to-end test team; still needed. |
| BUILD2_INDUSTRIES_2026-10-05.md | Build 2 stage 2E partial report; not clean and not on main. |
| BUILD_BACKUP_TASK_2026-10-07.md | Approved off-vendor backup spec, not started (no backup code on main); still a queued build. |
| BUILD_QUEUE_PLAN.md | Active build queue order; builds 3 and 4 not started. |
| BUILD_QUEUE_STATUS_PLUMBING.md | Build 2 plumbing status still open at loop 7; not on main. |
| BUILD_QUEUE_STATUS_PROPERTY.md | Build 2 property status; no clean reviewer loop yet; not on main. |
| CODE_REVIEW_BACKEND_2026-10-03.md | Unbuilt efficiency and correctness backlog with proposed SQL; index, outreach and migration-21 fixes are not on main, so it is still the plan. |
| CODE_REVIEW_COMBINED_2026-10-03.md | Only record of open review findings and nine owner decisions. |
| CODE_REVIEW_DESKTOP_2026-10-03.md | Combined desktop efficiency review; unbuilt slices remain and the answer-provider setting was never checked. |
| CODE_REVIEW_DONOVAN_2026-10-03.md | Combined Donovan answer-path efficiency review; slices not built, and the rollups write and mapReduce zero-token accounting are still on main. |
| CODE_REVIEW_PHONE_WEBSITE_2026-10-03.md | Combined phone and website efficiency review; navigationPreload, Clerk version pin and searchText removal are still absent from main, so the backlog is live. |
| CODE_REVIEW_TESTS_BUILD_2026-10-03.md | Unbuilt test-gate, build and dependency backlog; gate repair and @vercel/node removal are not on main, so the plan is still live. |
| COMPANY_RECORD.md | Declared single source for legal facts; agents read it. |
| COMPETITIVE_LANDSCAPE_2026-09-28.md | Market research cited by the add-on strategy; the FSM connector decision is still open. |
| COORDINATOR_HANDOFF_2026-10-07.md | Coordinator state with unmerged patches, unapproved help wording and a suspected data defect; no other record. |
| DOCUMENT_HANDLING_AGREEMENT_DRAFT.md | Unfinished legal draft awaiting attorney review; open decisions block any customer use. |
| DONOVAN_ADDON_CATALOG.md | Open pricing and product decisions for 27 add-on candidates; nothing decided, none built. |
| DONOVAN_CAPABILITY_AB_REPORT.md | Round 3 is NOT-CLEAN; its open defect list exists only here and must feed the next fix round. |
| DONOVAN_CODE_LEARNING_LOOP.md | Standing nightly learning-loop rule, revised 10-05 and used as the default work of every round. |
| DONOVAN_DECLINE_ROOT_CAUSE_2026-10-08.md | Root-cause plan driving the unbuilt RECORDS-R3B run and the owner's 100% accuracy demand. |
| DONOVAN_FEATURE_QUEUE.md | Current build order for the five features and integrations; feature 1 marked NEXT. |
| DONOVAN_FEATURE_SPECS.md | Specs for the five queued Donovan features; none built (no featureOn helper on main). |
| DONOVAN_GROUNDING_PROMPT_2026-10-08.md | Round 4 grounding prompt and retrieval-track spec; not built on origin/main. |
| DONOVAN_LIVE_RETEST_2026-10-07.md | Latest live-site test; standing loop ranks LIVE_RETEST docs as top-priority input for fixes. |
| DONOVAN_MASTER_ENGINEERING_PROMPT.md | Standing coordinator rules and engineering charter that Donovan agents read first on every run. |
| DONOVAN_R3_DELIVERY_2026-10-08.md | R3 merged onto a local branch, not pushed; origin/main lacks the menu pick, so it is not live. |
| DONOVAN_RECORDS_FILING_GAPS.md | Gap list and re-read cost analysis; items not built; owner must decide before any re-read. |
| DONOVAN_RECORDS_REPORT_R3.md | R3 checkpoint, NOT-CLEAN; menu pick not on origin/main; R3 patch exists only as a chat file, not in project. |
| DONOVAN_RECORDS_ROUND3_DIRECTION.md | Spec for the round 3 menu pick; DONOVAN_MENU_PICK is absent from origin/main, so unbuilt. |
| DONOVAN_RESEARCH_EXPERIMENTS.md | Experiment specs E1-E8 for research recommendations; not run and scripts/research is not on main. |
| DONOVAN_RESEARCH_REPORT_2026-10-08.md | RESEARCH-R1 report cited by the synthesis as a source; recommendations 1-16 still open. |
| DONOVAN_RESEARCH_SYNTHESIS.md | Coordinator build list A-H with the 2026-11-30 Sonnet 4.5 deadline; cites the tracks; not built. |
| DONOVAN_ROADMAP.md | Living Donovan roadmap that nightly rounds read. |
| DONOVAN_ROADMAP_R41N_ADDENDUM.md | Roadmap addendum for R41n; R41n patch is not on origin/main (propertyPack lookups absent), so work is open. |
| DONOVAN_ROUND41_2026-10-08_NIGHTLY.md | Nightly round R41n: patch undelivered and not in product; reviewer gave conditional GO. |
| DONOVAN_ROUNDS_STANDING_ORDER.md | Standing order chaining Donovan rounds 2 to 4; governs the next runs. |
| DONOVAN_SELF_LEARNING_2026-09-22.md | Learner shipped on main (sweep.js, verify-learning.mjs, migration 26); doc is still the runbook for the weekly manual export step. |
| DONOVAN_STANDING_LOOP.md | Standing brief Forge follows for every fix and feature round. |
| EMAIL_TO_FILE_PLAN.md | Design and cost spec for email-to-file, not built on main; owner setup steps live only here. |
| EMAIL_TO_FILE_REPORT.md | Email-to-file is built on a branch, not on main (inbound route absent); owner setup and review status still apply. |
| ENGINEERING_REQUIREMENTS_SPEC.md | Blueprint for unbuilt MUST, SHOULD and MAY items (Inngest, Textract, email and folder intake); partly stale. |
| FORGE_DEEPDIVE_2026-10-07_FORGE.md | Ranked upgrade plan for open Donovan defects and the unapproved help article; no other copy of the plan. |
| HANDOFF_2026-10-02.md | Current owner to-do list; Sentinel's 10-08 review says the security steps are still unconfirmed. |
| HISTORY_DIGEST_2026-10-07.md | Index of removed documents and the archive zip; the only pointer to archived history. |
| INGESTION_STRATEGY_AT_SCALE.md | Layers 2-4 (sampling audits, staged rollout gates, error budgets) not found on main; layer 1 autoverify is not in this repo. |
| LIMIT_TEST_DESKTOP_WEB_2026-10-03.md | Combined desktop and web limit report; D1, D2, D6 and D9 still reproduce in code, so it stays active. |
| LIMIT_TEST_PHONE_2026-10-03.md | Latest phone limit test with open defects; the owner's real-phone checklist exists only in this file. |
| LIMIT_TEST_WEBSITE_2026-10-03.md | Combined website limit report; its wording, chat and form items are still open on main, so it stays as the work list. |
| LOOP_BACKLOG.md | Coordinator rules and live backlog of security and engineering items. |
| LOOP_LOG.md | Active Donovan loop log; agents append each run. |
| MARKET_FIT_RESEARCH_2026-10-02.md | Cited by current Isaac and Atlas work; holds the HVAC-first industry ranking and the NOT-YET list, which are the only record. |
| OPS_WATCH_LOG.md | Active crew log with open LOW incident OPS-20261007-1 (/api/ask transaction drops). |
| OWNER_TODO_TEST_COPY.md | Owner's open to-do list for the isolated test copy before security round 2. |
| PACKS_COUPLING_AUDIT_2026-10-02.md | Coupling audit cited by Atlas, Isaac and packs work; the only map of what still needs the industry setter and fast-lane parity. |
| PATCH_DONOVAN_2026-10-08.manifest.txt | Manifest for the undelivered R41n patch; only useful with that patch. |
| PATCH_DONOVAN_2026-10-08.patch | Forge nightly from today, not yet reviewed |
| PATCH_DONOVAN_RESEARCH.patch | Research experiments, feeds round 4 |
| PATCH_EMAIL_TO_FILE.patch | Built, waiting for coordinator verification |
| PATCH_UX.patch | UX round 8 from today, not yet reviewed |
| R25_CLIENT_READINESS_AUDIT_2026-09-28.md | Readiness checklist still cited by Sentinel and Atlas; several must-haves remain open. |
| RESEARCH_TRACK_A_ANTHROPIC_1.md | Anthropic synthesis and repo study cited by the build list; migration tests not yet run. |
| RESEARCH_TRACK_A_ANTHROPIC_2.md | Anthropic appendix cited by synthesis; holds model, vision, PDF and citations findings used by the plan. |
| RESEARCH_TRACK_A_ANTHROPIC_3.md | Anthropic appendix cited by synthesis; holds prices, caching, batch and tool-use findings used by the migration plan. |
| RESEARCH_TRACK_B_OPENAI_1.md | OpenAI track report cited by the synthesis; recommendations R1-R17 and experiments E1-E9 not built. |
| RESEARCH_TRACK_B_OPENAI_2.md | OpenAI reading log cited by the research synthesis as evidence. |
| RESEARCH_TRACK_C_DOCUMENT_AI.md | Track C recommendations cited by synthesis; correction protection, verbatim check and duplicate guard not built. |
| RESEARCH_TRACK_C_DOCUMENT_AI_2.md | Track C reading log and repo map cited by synthesis; repo map records the correction-loss gap. |
| SENTRY_WATCH_LOG.md | Active crew watch log, appended on every run. |
| SITE_POLISH_2026-10-07.md | Partial website polish awaiting owner approval of listed button wording; no clean second review. |
| SITE_POLISH_DECISIONS_2026-10-06.md | Owner decisions driving the pending website polish round. |
| STORAGE_AND_RETRIEVAL_MODEL.md | Standing architecture rules (provenance, facets, no free-form chunks, no vector DB) still govern the product. |
| UPLOAD_SAFETY_RESEARCH_2026-10-03.md | Research and specs for virus scanning and safe downloads; no scanner or scan_status exists on main, so the plan is still needed. |
| UX_ROUND8_2026-10-08.md | UX round 8 patch not on origin/main ("Batches" heading and "Choose files" wording absent); undelivered. |
| WARRANTY_REMINDER_BUILD.md | Code is on main (warrantyRules.js, warranty-attention.js, verify-warranty.mjs); brand verification and reminder screen remain open. |
| crew/ATLAS_ENGINEERING_PLAN.md | Live engineering plan with open owner decisions and unbuilt roadmap items (batch, Drive, branch scoping). |
| crew/ATLAS_INDUSTRY_PACKS_SPEC.md | Spec for Industry tools; slice 1 and the Electrical tool are not built yet. |
| crew/ATLAS_INDUSTRY_TOOLS_SPEC.md | Spec for the Electrical tool, knowledge standard and rollout; nothing built yet, still cited by the crew. |
| crew/ATLAS_PLAN_DELTA_2026-10-06.md | Current engineering delta for unbuilt work (batch, Drive import, CI isolation test). |
| crew/ATLAS_PLAYBOOK.md | Atlas standing playbook read at every run; scorecard and run checklist still in use. |
| crew/BRANDY_FINANCE_BOOK.md | Standing finance book; sole cost and burn record. |
| crew/BRANDY_PLAYBOOK.md | Standing finance playbook with scorecard. |
| crew/CREW_CHARTERS.md | Source-of-truth charter for every scheduled agent; cited on each run. |
| crew/CURRENT_ASSIGNMENTS.md | Living coordination page read by every agent before work; holds the standing loop and the owner waiting list. |
| crew/GRANTS_AND_CREDITS_LOG.md | Grants agents must read before budget or grant reports; only record of the Neon $1,000 award. |
| crew/ISAAC_BUSINESS_BOOK.md | Standing business book read by agents and owner. |
| crew/ISAAC_FIRST_CUSTOMER_PLAN_2026-10-06.md | Standing first-customer plan used by agents and the business plan. |
| crew/ISAAC_GRANT_SEARCH_NM_2026-10-06.md | Current New Mexico grant plan with next actions; supersedes the Arizona search. |
| crew/ISAAC_PLAYBOOK.md | Isaac's standing operating playbook with scorecard. |
| crew/SENTINEL_PLAYBOOK.md | Security crew playbook with weekly run record and open watch items; still in use. |
| crew/SENTINEL_SECURITY_BOOK.md | Weekly security book with a live gap list and owner checklist; still in use. |
| deepwell-edge-cases-safeguards.md | Standing safeguards still apply (human review before warranty submission, full history shown); its test matrix is stale. |
