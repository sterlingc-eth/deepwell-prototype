/**
 * Unit checks for customer matching. No database, no network.
 *
 * What this guards: findOrCreateCustomer's whole job is deciding whether a
 * document is about a customer this tenant has already seen. Getting that
 * wrong in one direction (merge) shows one customer another's equipment and
 * warranty state — a privacy defect, not just an untidy table. Getting it
 * wrong in the other direction (never merge) just means duplicate rows a
 * human can tidy up later. These checks exist to keep the code on the safe
 * side of that asymmetry.
 *
 *   node scripts/verify-customer-link.mjs
 */
import { normalizeMatchText, selectCustomerMatch } from '../api/_lib/recordsStore.js';
import { compareNamesStrict } from '../api/_lib/integrity.js';

let failures = 0;
const check = (name, ok, detail = '') => {
  if (!ok) failures++;
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${ok || !detail ? '' : `\n      ${detail}`}`);
};
const eq = (name, got, want) =>
  check(name, JSON.stringify(got) === JSON.stringify(want), `got ${JSON.stringify(got)}, want ${JSON.stringify(want)}`);

/* ------------------------------------------------------- normalizeMatchText */

eq('plain name survives', normalizeMatchText('John Smith'), 'John Smith');
eq('internal whitespace collapsed', normalizeMatchText('John   Smith'), 'John Smith');
eq('leading/trailing whitespace trimmed', normalizeMatchText('  John Smith  '), 'John Smith');
eq('tabs and newlines collapsed', normalizeMatchText('John\t\nSmith'), 'John Smith');

// The adversarial cases the build brief calls out by name.
eq('whitespace-only name rejected', normalizeMatchText('   '), '');
eq('punctuation-only name rejected', normalizeMatchText('---'), '');
eq('em-dash-only name rejected', normalizeMatchText('—'), '');
eq('dots-only name rejected', normalizeMatchText('...'), '');
eq('null rejected', normalizeMatchText(null), '');
eq('undefined rejected', normalizeMatchText(undefined), '');
eq('empty string rejected', normalizeMatchText(''), '');

// A name with ANY letter or digit is accepted even if mostly punctuation —
// this function's job is refusing garbage, not judging plausibility.
eq('mostly punctuation but one letter survives', normalizeMatchText('--- A ---'), '--- A ---');
eq('"N/A" survives (has letters; a real value, arguably)', normalizeMatchText('N/A'), 'N/A');

{
  const long = 'A'.repeat(5000);
  const got = normalizeMatchText(long);
  check('5000-char name is not truncated or corrupted', got === long, `length ${got.length}`);
}

{
  // Two names differing only in whitespace/case must normalize to values that
  // compare equal case-insensitively — this is exactly what the SQL query
  // relies on (lower(data->>'customer_name') = lower($1)).
  const a = normalizeMatchText('  Jane   Doe ');
  const b = normalizeMatchText('Jane Doe');
  check('whitespace variants match case-insensitively', a.toLowerCase() === b.toLowerCase(), `"${a}" vs "${b}"`);
}

/* ------------------------------------------------------- selectCustomerMatch */

const smithA = { id: 'smith-a', data: { customer_name: 'John Smith', service_address: '123 Main St' } };
const smithB = { id: 'smith-b', data: { customer_name: 'John Smith', service_address: '456 Oak Ave' } };
const smithNoAddr = { id: 'smith-no-addr', data: { customer_name: 'John Smith' } };

eq('no candidates, no address -> null (create new)', selectCustomerMatch([], ''), null);
eq('no candidates, with address -> null (create new)', selectCustomerMatch([], '123 Main St'), null);

eq('one candidate, no incoming address -> matches it', selectCustomerMatch([smithA], ''), smithA);
eq('one candidate, matching address -> matches it', selectCustomerMatch([smithA], '123 Main St'), smithA);
eq('one candidate, matching address is case-insensitive', selectCustomerMatch([smithA], '123 MAIN ST'), smithA);
// A name-only row must NOT swallow the next person of the same name. The
// customer whose first document had no address gets a duplicate row instead —
// visible and mergeable, unlike a silent false merge.
eq('one candidate with no address on file, incoming HAS one -> null (no merge)', selectCustomerMatch([smithNoAddr], '123 Main St'), null);
eq('name-only row still matches when incoming also has no address', selectCustomerMatch([smithNoAddr], ''), smithNoAddr);
eq('one candidate, address disagrees -> null (create new, not a merge)', selectCustomerMatch([smithA], '456 Oak Ave'), null);

// The load-bearing case: two different Smiths must never merge.
eq(
  'two Smiths at different addresses, no incoming address -> ambiguous, refuse',
  selectCustomerMatch([smithA, smithB], ''),
  null
);
eq(
  'two Smiths at different addresses, incoming address picks the right one',
  selectCustomerMatch([smithA, smithB], '456 Oak Ave'),
  smithB
);
eq(
  'two Smiths, incoming address matches neither -> a third Smith, not a guess',
  selectCustomerMatch([smithA, smithB], '789 Elm St'),
  null
);
eq(
  'Smith-with-matching-address wins over a same-named row with no address',
  selectCustomerMatch([smithA, smithNoAddr], '123 Main St'),
  // Requiring a POSITIVE address match makes this unambiguous rather than
  // refusing: only smithA is eligible, and we have real evidence it is the
  // right one. The addressless row is no longer a wildcard that matches
  // everyone of that name.
  smithA
);

/* ---------------------------------------------------- selectCustomerMatch fuzzy */
// Bug A fix (2026-09-20, handoffs/DATA_INTEGRITY_2026-09-20.md): passing
// {name, address} (instead of a bare address string) opens a fuzzy path via
// integrity.js's customerMatchScore, on top of the strict-equality path
// above, which the string-argument tests already cover unchanged.

{
  const castillo = { id: 'castillo-1', customer_number: 'C-00003', data: { customer_name: 'Castillo', service_address: '1519 W Juniper' } };
  const got = selectCustomerMatch([castillo], { name: 'Ray & Linda Castillo', address: '1519 W Juniper Ave, Mesa AZ 85202' });
  // ENTITY SAFETY: a bare surname with a city-less address is a suggestion for a human, never an automatic link
  check('fuzzy: differently-worded name/address for the same household is NOT auto-linked', got === null, `got ${JSON.stringify(got)}`);
}
{
  const castillo = { id: 'castillo-1', data: { customer_name: 'Castillo', service_address: '1519 W Juniper' } };
  const got = selectCustomerMatch([castillo], { name: 'Someone Else', address: '1519 E Juniper' });
  check('fuzzy: different street direction never matches, even with no strict address hit', got === null, `got ${JSON.stringify(got)}`);
}
{
  // No `name` on the incoming side -> only the strict-equality path runs
  // (unchanged behavior), never the fuzzy one.
  const castillo = { id: 'castillo-1', data: { customer_name: 'Castillo', service_address: '1519 W Juniper' } };
  const got = selectCustomerMatch([castillo], { address: '1519 W Juniper Ave, Mesa AZ 85202' });
  check('fuzzy path skipped with no incoming name', got === null, `got ${JSON.stringify(got)}`);
}

/* ------------------------------------------ selectCustomerMatch, defect C/B */
// Limit-test defect C (2026-09-20): an exact address match must ALSO agree
// on name (at least surname-level) before it's eligible — otherwise a
// different business/family at the same address/suite gets silently
// absorbed into whoever was there first.

{
  const plazaDental = { id: 'plaza-1', data: { customer_name: 'Plaza Dental Group', service_address: '900 Suite 4' } };
  const got = selectCustomerMatch([plazaDental], { name: 'Desert Ridge Dental', address: '900 Suite 4' });
  eq('different name, same address -> null (never silently absorbed)', got, null);
  check('sanity: these two names really are "no-match"', compareNamesStrict('Desert Ridge Dental', 'Plaza Dental Group') === 'no-match');
}

// Limit-test defect B (2026-09-20): a likely-misspelled surname at the same
// address is suggest-tier evidence (see verify-integrity.mjs), never enough
// to auto-link — selectCustomerMatch's eligible set only allows
// equal/subset/surname, not surname-fuzzy.
{
  const paterson = { id: 'pat-1', data: { customer_name: 'Bob Paterson', service_address: '44 Cedar Ln' } };
  const got = selectCustomerMatch([paterson], { name: 'Bob Patterson', address: '44 Cedar Ln' });
  eq('misspelled-surname match at the same address -> null (never auto-linked)', got, null);
  check('sanity: these two surnames really are "surname-fuzzy"', compareNamesStrict('Bob Paterson', 'Bob Patterson') === 'surname-fuzzy');
}

console.log(`\n${failures === 0 ? 'All checks passed.' : `${failures} check(s) FAILED.`}`);
process.exit(failures === 0 ? 0 : 1);
