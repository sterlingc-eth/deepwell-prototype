/**
 * Checks for full-corpus content-count questions (api/_lib/contentCount.js, Team E 2026-09-24):
 * "how many jobs mention a capacitor", "which customers had a coil issue on file", jobs-vs-documents
 * scoping, the HVAC synonym map, tenant isolation, and the `count_documents_mentioning` agent tool.
 *
 * No network, no Anthropic key. The database is a REAL Postgres (PGlite, in process) loaded from the
 * actual M3-config/*.sql migrations, queried as the app's non-superuser NOBYPASSRLS role
 * (deepwell_rls) so row-level security is genuinely in force. Harness copied from
 * scripts/verify-agent.mjs.
 *
 *   node scripts/verify-content.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

let failures = 0;
let passes = 0;
const check = (name, ok, detail = '') => {
  if (ok) passes++; else failures++;
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${ok || !detail ? '' : `\n      ${detail}`}`);
};
const eq = (name, got, want) =>
  check(name, JSON.stringify(got) === JSON.stringify(want), `got ${JSON.stringify(got)}, want ${JSON.stringify(want)}`);

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
process.env.NEON_CONNECTION_STRING = 'postgres://harness:harness@localhost:5432/harness';
delete process.env.ANTHROPIC_API_KEY;

const realLog = console.log;
console.log = (...a) => { if (typeof a[0] === 'string' && a[0].startsWith('{"route"')) return; realLog(...a); };

const content = await import('../api/_lib/contentCount.js');
const {
  HVAC_TERM_SYNONYMS, expandTerms, buildTermPattern, extractKnownTerms, canonicalizeTerm, parseContentCountQuestion,
  buildTsPrefilterQuery,
} = content;
const jobSummaryMod = await import('../api/_lib/content/jobSummary.js');
const { parseJobSummaryQuestion, extractFindingSentences } = jobSummaryMod;

/* ================================================================== 1. pure: vocabulary + expansion */
{
  check('vocab: capacitor group includes cap and dual run cap', HVAC_TERM_SYNONYMS.capacitor.includes('cap') && HVAC_TERM_SYNONYMS.capacitor.includes('dual run cap'));
  check('vocab: noise group includes rattle/squeal/loud', ['rattle', 'squeal', 'loud'].every((w) => HVAC_TERM_SYNONYMS.noise.includes(w)));
  eq('canonicalizeTerm: a plural/variant spelling resolves to its group key', [canonicalizeTerm('capacitors'), canonicalizeTerm('loud'), canonicalizeTerm('leaking')], ['capacitor', 'noise', 'leak']);
  eq('canonicalizeTerm: an unrecognized word passes through unchanged', canonicalizeTerm('gizmo'), 'gizmo');
  check('expandTerms: a canonical key expands to its whole group', expandTerms(['capacitor']).includes('cap') && expandTerms(['capacitor']).includes('dual run cap'));
  eq('expandTerms: an unrecognized key is kept as a literal, single-word term', expandTerms(['gizmo']), ['gizmo']);
  const pattern = buildTermPattern(['cap', 'capacitor']);
  check('buildTermPattern: word-boundary anchored on both ends', pattern.startsWith('\\y(') && pattern.endsWith(')\\y'));
  const known = extractKnownTerms('replaced the cap and cleared a leak');
  check('extractKnownTerms: finds every group mentioned (capacitor via "cap", leak), none it is not', known.length === 2 && known.every((g) => ['capacitor', 'leak'].includes(g)), JSON.stringify(known));
  eq('extractKnownTerms: no known term -> empty', extractKnownTerms('what is the weather like today'), []);

  // Round 15: new HVAC synonym groups (breadth-content-030/031).
  check('vocab: txv group includes txv and expansion valve (singular + plural)', ['txv', 'txvs', 'expansion valve', 'expansion valves'].every((w) => HVAC_TERM_SYNONYMS.txv.includes(w)));
  check('vocab: heat exchanger group includes singular + plural', ['heat exchanger', 'heat exchangers'].every((w) => HVAC_TERM_SYNONYMS['heat exchanger'].includes(w)));
  eq('extractKnownTerms: "involved a TXV or expansion valve" finds txv', extractKnownTerms('how many jobs involved a txv or expansion valve'), ['txv']);
  eq('extractKnownTerms: "heat exchanger crack" finds heat exchanger', extractKnownTerms('how many jobs mention a heat exchanger crack'), ['heat exchanger']);
}

/* ================================================================== 1b. pure: tsv prefilter query (Round 16, F4, D2 #8) */
{
  const plain = buildTsPrefilterQuery(['loud noise']);
  check('buildTsPrefilterQuery: a plain phrase uses plainto_tsquery', plain?.sql === "plainto_tsquery('english', $1::text)" && plain.params[0] === 'loud noise', JSON.stringify(plain));
  const prefix = buildTsPrefilterQuery(['replac~']);
  check('buildTsPrefilterQuery: a "~"-suffixed stem uses to_tsquery with a prefix match', prefix?.sql === "to_tsquery('english', $1::text)" && prefix.params[0] === 'replac:*', JSON.stringify(prefix));
  const both = buildTsPrefilterQuery(['loud noise', 'replac~']);
  check('buildTsPrefilterQuery: several variants OR together, one placeholder each, in order', both?.sql === "plainto_tsquery('english', $1::text) || to_tsquery('english', $2::text)" && both.params.length === 2, JSON.stringify(both));
  const deduped = buildTsPrefilterQuery(['cap', 'cap', '', null, undefined]);
  check('buildTsPrefilterQuery: blank/duplicate variants are dropped, never produce an empty clause', deduped?.params.length === 1 && deduped.params[0] === 'cap', JSON.stringify(deduped));
  eq('buildTsPrefilterQuery: no usable variant at all -> null (caller must fall back to the plain query)', buildTsPrefilterQuery([]), null);
  eq('buildTsPrefilterQuery: a stem that is ONLY punctuation -> null, never an empty to_tsquery(\'\')', buildTsPrefilterQuery(['---~']), null);
}

/* ================================================================== 2. pure: question shape (never-hijack) */
{
  const cases = [
    ['how many jobs mention a capacitor', { scope: 'jobs', mode: 'count', groupBy: null, terms: ['capacitor'] }],
    ['How many jobs mention a refrigerant?', { scope: 'jobs', mode: 'count', groupBy: null, terms: ['refrigerant'] }],
    ['how many documents mention a coil', { scope: 'documents', mode: 'count', groupBy: null, terms: ['coil'] }],
    ['which customers had a capacitor issue or repair on file', { scope: 'documents', mode: 'list', groupBy: 'customer', terms: ['capacitor'] }],
    ['list jobs where we replaced the compressor', { scope: 'jobs', mode: 'list', groupBy: null, terms: ['compressor'] }],
    ['any complaints about noise', { scope: 'documents', mode: 'list', groupBy: null, terms: ['noise'] }],
    // Round 15 (breadth-content-030/031): new vocabulary, same pre-existing "how many jobs ..." shape.
    ['How many jobs involved a TXV or expansion valve?', { scope: 'jobs', mode: 'count', groupBy: null, terms: ['txv'] }],
    ['How many jobs mention a heat exchanger crack?', { scope: 'jobs', mode: 'count', groupBy: null, terms: ['heat exchanger'] }],
  ];
  for (const [q, want] of cases) {
    const got = parseContentCountQuestion(q);
    check(`parse: "${q}" -> scope/mode/groupBy`, got && got.scope === want.scope && got.mode === want.mode && got.groupBy === want.groupBy, JSON.stringify(got));
    check(`parse: "${q}" -> terms`, got && JSON.stringify([...got.terms].sort()) === JSON.stringify([...want.terms].sort()), JSON.stringify(got?.terms));
  }
  const neverHijack = [
    'how many invoices are unpaid',
    'how many invoices are overdue',
    'which customers have no email on file',
    'how many documents do we have',
    'how much have we billed year to date',
    'do we have any overdue invoices',
    'which customers are overdue for maintenance',
  ];
  for (const q of neverHijack) check(`parse: never hijacks "${q}"`, parseContentCountQuestion(q) === null);
  // still yields to a structured, time-scoped or replacement question (round 5: the question-shape
  // fallback anchor must not swallow these — they need the agent/multi-hop path, not a bare mention scan).
  const stillFallsThrough = [
    'which customers had a compressor replaced this year',
    'how many trane customers had a capacitor replaced last year',
  ];
  for (const q of stillFallsThrough) check(`parse: still falls through (replaced/time-window) "${q}"`, parseContentCountQuestion(q) === null);

  // round 5 (R5_FAILS.md #2): all 15 semantic-paraphrase exam questions (test-docs/scorecard/breadth.mjs
  // SYMPTOMS) parse and pick a real HVAC term, even though none of them say "mention"/"issue"/"complaint".
  const semanticCases = [
    ['Which customers complained the unit is loud?', 'noise'],
    ['Who called about a rattling or humming outdoor unit?', 'noise'],
    ['How many jobs were for a noise complaint?', 'noise'],
    ['Which customers said their AC wasn\'t keeping up?', 'not cooling'],
    ['Who had a no-cooling call?', 'not cooling'],
    ['How many calls were for warm air coming out of the vents?', 'not cooling'],
    ['Which customers had water dripping from the unit?', 'leak'],
    ['Who called about a leak?', 'leak'],
    ['How many jobs mention a water leak?', 'leak'],
    ['Which customers had a unit that would not turn on?', 'no power'],
    ['Who had a tripped breaker on the AC?', 'no power'],
    ['How many calls were for a system that won\'t start?', 'no power'],
    ['Which customers reported a strange smell?', 'odor'],
    ['Who complained about a burning odor from the vents?', 'odor'],
    ['How many jobs mention an odor?', 'odor'],
  ];
  for (const [q, term] of semanticCases) {
    const got = parseContentCountQuestion(q);
    check(`semantic parse: "${q}" -> parses and finds "${term}"`, Boolean(got) && got.terms.includes(term), JSON.stringify(got));
  }
}

/* ================================================================== 2b. job-summary question shape (Round 15) */
{
  // The standalone module, called directly (not just through parseContentCountQuestion's delegation).
  eq('parseJobSummaryQuestion: direct call parses the shape', parseJobSummaryQuestion('What was found or done on the Mercer job?'), { mode: 'jobSummary', customerName: 'Mercer', question: 'What was found or done on the Mercer job?' });
  eq('parseJobSummaryQuestion: direct call rejects a non-matching question', parseJobSummaryQuestion('How many jobs mention a capacitor?'), null);

  const positives = [
    ['What was found or done on the Mercer job?', 'Mercer'],
    ['What was found or done on the Salazar job?', 'Salazar'],
    ['What was done or found on the Rios job?', 'Rios'], // order swapped
    ['What was found on the Holbrook job?', 'Holbrook'], // "or done" omitted
    ['What was found or done for the Thornton job?', 'Thornton'], // "for" instead of "on"
    ['What was found or done on Delgado job?', 'Delgado'], // no "the"
    ["What was found or done on the O'Malley job?", "O'Malley"],
  ];
  for (const [q, name] of positives) {
    const got = parseContentCountQuestion(q);
    check(`job-summary parse: "${q}" -> mode jobSummary, name "${name}"`, got?.mode === 'jobSummary' && got.customerName === name, JSON.stringify(got));
  }

  // Negative tests (R15_CONTRACT.md): every new family needs negation / two-values / dropped-condition /
  // ambiguous-name coverage. Ambiguous names are a DB-backed concern (ambiguity is resolved against real
  // rows) and are covered in the PGlite harness section below; the rest are pure shape exclusions.
  const negatives = [
    'What was NOT found on the Mercer job?', // negation: "not" breaks the was/were->found/done adjacency
    'What was found or done on the Mercer and Salazar jobs?', // two values for one dimension + plural "jobs"
    'What was found or done on the Mercer job last month?', // dropped/added condition: trailing time window
    'What was found or done on the Mercer job, other than the compressor?', // trailing qualifier
    'What is the Mercer job?', // no found/done verb at all
    'How many jobs mention a capacitor?', // a completely different content shape
  ];
  for (const q of negatives) check(`job-summary parse: does not hijack "${q}"`, parseContentCountQuestion(q) === null || parseContentCountQuestion(q)?.mode !== 'jobSummary');

  // extractFindingSentences: pure, extractive-only (never invents words).
  const sentences = extractFindingSentences('Found a refrigerant leak at the evaporator coil.\nRecommend replacing the contactor next visit.\nCustomer signature on file.', 5);
  check('extractFindingSentences: pulls only the finding-bearing lines, verbatim', sentences.length === 2 && sentences[0].startsWith('Found a refrigerant leak') && sentences[1].startsWith('Recommend replacing'), JSON.stringify(sentences));
  eq('extractFindingSentences: a page with no finding word -> empty', extractFindingSentences('Customer signature on file. Payment received.', 5), []);
}

/* ================================================================== harness: real Postgres via PGlite */
let PGlite;
let contrib = {};
try {
  ({ PGlite } = await import('@electric-sql/pglite'));
  for (const [key, mod] of [['uuid_ossp', 'uuid_ossp'], ['pgcrypto', 'pgcrypto'], ['pg_trgm', 'pg_trgm'], ['btree_gin', 'btree_gin']]) {
    contrib[key] = (await import(`@electric-sql/pglite/contrib/${mod}`))[key];
  }
} catch (err) {
  console.log(`SKIP  database-backed checks: PGlite is not installed (${err?.message}). Run npm ci.`);
  console.log('');
  if (failures) { console.log(`${failures} check(s) FAILED.`); process.exit(1); }
  console.log(`${passes} checks passed (database-backed checks skipped).`);
  process.exit(0);
}

const lite = new PGlite({ extensions: contrib });
const cfgDir = path.join(ROOT, 'M3-config');
const harnessNotes = [];
const migrations = fs.readdirSync(cfgDir).filter((f) => /^\d\d.*\.sql$/.test(f) && !f.startsWith('99')).sort();
for (const f of migrations) {
  try { await lite.exec(fs.readFileSync(path.join(cfgDir, f), 'utf8')); }
  catch (err) { harnessNotes.push(`${f}: ${String(err.message).slice(0, 90)}`); }
}
try { await lite.exec(fs.readFileSync(path.join(cfgDir, '01b-app-role.sql'), 'utf8')); harnessNotes.push('01b-app-role.sql: re-run after the rest (dependency order)'); }
catch (err) { harnessNotes.push(`01b re-run failed: ${err.message}`); }
for (const line of harnessNotes) console.log(`NOTE  migration harness: ${line}`);
const role = (await lite.query("SELECT rolname, rolsuper, rolbypassrls FROM pg_roles WHERE rolname = 'deepwell_rls'")).rows[0];
check('harness: the app role deepwell_rls exists, is not a superuser and does not bypass RLS', Boolean(role) && !role.rolsuper && !role.rolbypassrls, JSON.stringify(role));

const pgMod = (await import('pg')).default;
let tail = Promise.resolve();
const lock = () => { let release; const p = new Promise((r) => { release = r; }); const prev = tail; tail = tail.then(() => p); return prev.then(() => release); };
pgMod.Pool.prototype.connect = async function connect() {
  const release = await lock();
  await lite.exec('SET ROLE deepwell_rls');
  return { query: (sql, params) => lite.query(sql, params), release: () => { lite.exec('RESET ROLE').finally(release); } };
};
pgMod.Pool.prototype.query = async function query(sql, params) {
  const release = await lock();
  try { return await lite.query(sql, params); } finally { release(); }
};

const { withTenant, getTenantContext } = await import('../api/_lib/recordsStore.js');
const { runContentCount } = content;
const { createToolbox } = await import('../api/_lib/agent/tools.js');

const ctxA = { tenantKey: 'org_content_a', tenantName: 'Desert Peak HVAC' };
const ctxB = { tenantKey: 'org_content_b', tenantName: 'Other Shop' };
const tenA = (await getTenantContext(ctxA.tenantKey, ctxA.tenantName)).id;
const tenB = (await getTenantContext(ctxB.tenantKey, ctxB.tenantName)).id;
const uid = (t, k, n) => `${t}${k}000000-0000-4000-8000-${String(n).padStart(12, '0')}`;

async function seedTenant(t, tenantId, world) {
  const ent = (id, type, data, extra = {}) => lite.query(
    'INSERT INTO entities (id, tenant_id, entity_type, data, customer_id, customer_number) VALUES ($1,$2,$3,$4::jsonb,$5,$6)',
    [id, tenantId, type, JSON.stringify(data), extra.customerId ?? null, extra.number ?? null]);
  for (const c of world.customers) await ent(uid(t, 'c', c.n), 'customer', { customer_name: c.name, service_address: c.address }, { number: `C-0000${c.n}` });
  for (const e of world.equipment ?? []) await ent(uid(t, 'e', e.n), 'equipment', { manufacturer: e.mfr ?? 'Trane', equipment_type: 'condenser' }, { customerId: uid(t, 'c', e.customer) });
  for (const d of world.docs) {
    if (d.date) {
      await lite.query('INSERT INTO documents (id, tenant_id, original_filename, document_type, sha256_hash, stage, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7)',
        [uid(t, 'd', d.n), tenantId, d.file, d.type, `${t}-hash-${d.n}`, 'verified', d.date]);
    } else {
      await lite.query('INSERT INTO documents (id, tenant_id, original_filename, document_type, sha256_hash, stage) VALUES ($1,$2,$3,$4,$5,$6)',
        [uid(t, 'd', d.n), tenantId, d.file, d.type, `${t}-hash-${d.n}`, 'verified']);
    }
    for (const link of d.links ?? []) await lite.query('INSERT INTO document_entity_links (tenant_id, document_id, entity_id) VALUES ($1,$2,$3)', [tenantId, uid(t, 'd', d.n), link]);
    for (const [i, text] of (d.pages ?? []).entries()) await lite.query('INSERT INTO document_pages (document_id, tenant_id, page_no, text) VALUES ($1,$2,$3,$4)', [uid(t, 'd', d.n), tenantId, i + 1, text]);
    // Round 16 (F4): address-resolved job-summary fixtures read structured extractions
    // (work_performed/notes), not document_pages text - see runJobSummaryByAddress.
    for (const [key, value] of d.fields ?? []) {
      await lite.query('INSERT INTO extractions (tenant_id, document_id, field_key, value, confidence) VALUES ($1,$2,$3,$4,0.9)', [tenantId, uid(t, 'd', d.n), key, value]);
    }
  }
}

const worldA = {
  customers: [
    { n: 1, name: 'Karen Abernathy', address: '412 Elm St, Mesa, AZ 85201' },
    { n: 2, name: 'Bill Whitmore', address: '88 Whitmore Ave, Mesa, AZ 85201' },
    { n: 3, name: 'Donna Thornton', address: '17 Cactus Ln, Tucson, AZ 85701' },
    { n: 4, name: 'Plaza Dental Group', address: '2210 E Main St, Gilbert, AZ 85234' },
    { n: 5, name: 'Old Timer', address: '5 Oak Rd, Phoenix, AZ 85001' },
    // Round 15: job-summary fixtures.
    { n: 6, name: 'Elena Salazar', address: '61 Cinder Rd, Mesa, AZ 85204' },
    { n: 7, name: 'Marco Rios', address: '9 Palo Verde Dr, Mesa, AZ 85205' }, // ambiguous with #8 (both match "%Rios%")
    { n: 8, name: 'Rios Boulevard Apartments', address: '400 Rios Blvd, Mesa, AZ 85205' },
    { n: 9, name: 'Janet Holloway', address: '22 Holloway Dr, Mesa, AZ 85205' }, // on file, no finding text
    { n: 10, name: 'Greg Palmer', address: '5 Palmer Ct, Mesa, AZ 85201' }, // "filter change", no "replac" word at all
    // Round 16 (F4): address-resolved job-summary fixtures (field-phrasing g099-g101 shape).
    { n: 11, name: 'Nora Install', address: '55 Alpha Rd, Mesa, AZ 85201' }, // install (invoice) has no notes; a LATER service-ticket does
    { n: 12, name: 'Otto Fallback', address: '66 Beta Rd, Mesa, AZ 85202' }, // no literal work-order doc at all - falls back to the service-ticket
    { n: 13, name: 'Wendy Dispatch', address: '77 Gamma Rd, Mesa, AZ 85203' }, // has both a real work-order AND a later service-ticket
    { n: 14, name: 'Ambiguous Alpha', address: '88 Delta Rd, Mesa, AZ 85204' }, // shares house+street with #15 - address alone is ambiguous
    { n: 15, name: 'Ambiguous Beta', address: '88 Delta Rd, Gilbert, AZ 85234' },
  ],
  equipment: [{ n: 4, customer: 4, mfr: 'Carrier' }],
  docs: [
    { n: 1, file: 'karen-service.pdf', type: 'service-ticket', links: [uid('a', 'c', 1)], pages: ['Replaced the dual run capacitor on the condenser. Unit runs fine now.'] },
    { n: 2, file: 'whitmore-invoice.pdf', type: 'invoice', links: [uid('a', 'c', 2)], pages: ['Customer reports the unit is very loud and rattles at startup. Invoice total $180.'] },
    { n: 3, file: 'thornton-quote.pdf', type: 'proposal-quote', links: [uid('a', 'c', 3)], pages: ['Quote includes a new cap for the compressor. Not yet approved.'] },
    // linked only through its equipment, never a direct customer link — exercises the equipment->customer join.
    { n: 4, file: 'plaza-workorder.pdf', type: 'work-order', links: [uid('a', 'e', 4)], pages: ['Found a refrigerant leak at the evaporator coil, recharged with R-410A.'] },
    { n: 5, file: 'oldtimer-permit.pdf', type: 'permit', links: [uid('a', 'c', 5)], pages: ['City permit for a water heater replacement, nothing HVAC-related here.'] },
    { n: 6, file: 'salazar-workorder.pdf', type: 'work-order', links: [uid('a', 'c', 6)], pages: ['Found a cracked heat exchanger during inspection.\nRecommend replacement before next heating season.\nCustomer signature obtained.'] },
    { n: 7, file: 'rios-workorder.pdf', type: 'work-order', links: [uid('a', 'c', 7)], pages: ['Found a loose duct connection near the attic access. Resealed it and recommend a follow-up next season.'] },
    { n: 9, file: 'holloway-invoice.pdf', type: 'invoice', links: [uid('a', 'c', 9)], pages: ['Invoice total $220. Payment received in full.'] },
    { n: 10, file: 'palmer-service.pdf', type: 'service-ticket', links: [uid('a', 'c', 10)], pages: ['Performed a filter change during the visit. No other issues noted.'] },
    // Round 16 (F4): address-resolved job-summary fixtures.
    { n: 11, file: 'nora-invoice.pdf', type: 'invoice', links: [uid('a', 'c', 11)], date: '2026-01-01',
      fields: [['work_performed', 'Install 3 ton Goodman system, R-410A charge']] },
    { n: 12, file: 'nora-service.pdf', type: 'service-ticket', links: [uid('a', 'c', 11)], date: '2026-06-01',
      fields: [['work_performed', 'Annual PM: checked charge'], ['notes', 'System operating normally after visit']] },
    { n: 13, file: 'otto-service.pdf', type: 'service-ticket', links: [uid('a', 'c', 12)], date: '2026-02-01',
      fields: [['work_performed', 'No cooling - replaced run capacitor']] },
    { n: 14, file: 'wendy-workorder.pdf', type: 'work-order', links: [uid('a', 'c', 13)], date: '2026-01-15',
      fields: [['work_performed', 'No heat, dispatched for diagnosis']] },
    { n: 15, file: 'wendy-service.pdf', type: 'service-ticket', links: [uid('a', 'c', 13)], date: '2026-05-01',
      fields: [['work_performed', 'Replaced igniter']] },
  ],
};
const worldB = {
  customers: [{ n: 1, name: 'Zed Competitor', address: '1 Secret Way, Reno, NV 89501' }],
  docs: [{ n: 1, file: 'b-service.pdf', type: 'service-ticket', links: [uid('b', 'c', 1)], pages: ['Replaced capacitor and cleared a drain line at the secret location.'] }],
};
await seedTenant('a', tenA, worldA);
await seedTenant('b', tenB, worldB);

const run = (parsed) => withTenant(ctxA, (db) => runContentCount(db, parsed));

/* ================================================================== 3. document-scope counts + synonyms */
{
  const r = await run({ terms: ['capacitor'], scope: 'documents', groupBy: null });
  eq('documents scope: "capacitor" finds the literal word AND its "cap" synonym (2 documents: Karen + Thornton)', r.recordsTotal, 2);
  check('documents scope: text names the term and a real count, never "Found N matching records"', r.text.includes('capacitor') && !/^Found \d+ matching records/i.test(r.text));
  check('documents scope: basis states the rule (what was counted, by what field)', /mentions?\s+capacitor/i.test(r.basis) || /capacitor/i.test(r.basis));
  check('documents scope: at least one citation record carries a documentId and page', r.records.some((x) => x.documentId && x.page));

  const j = await run({ terms: ['capacitor'], scope: 'jobs', groupBy: null });
  eq('jobs scope excludes the proposal-quote (not a job) - only the service-ticket counts', j.recordsTotal, 1);
  check('jobs scope: basis states the jobs-vs-documents rule', /job/i.test(j.basis));
}

/* ================================================================== 4. multi-term groups (leak/refrigerant/coil on one doc) */
{
  const r = await run({ terms: ['leak', 'refrigerant', 'coil'], scope: 'documents', groupBy: null });
  eq('a document mentioning several requested groups is counted once, not three times', r.recordsTotal, 1);
  check('the matched document is Plaza\'s (linked only via its equipment)', r.records.some((x) => /plaza/i.test(x.group ?? '') || r.text.toLowerCase().includes('1 customer')));
}

/* ================================================================== 5. groupBy customer */
{
  const r = await run({ terms: ['noise'], scope: 'documents', groupBy: 'customer' });
  eq('groupBy customer: exactly one customer (Whitmore) had a noise mention', r.facts.length, 1);
  check('groupBy customer: names the customer in the text', r.text.includes('Whitmore'));
  // Whitmore's matching document is an invoice, so its record type is 'invoice' (documentRecord's own auto-detection
  // — see citations/records.js), not the generic 'document'; either is a valid document-shaped citation here.
  check('groupBy customer: a customer record and a document/invoice record are both present', r.records.some((x) => x.type === 'customer') && r.records.some((x) => x.type === 'document' || x.type === 'invoice'));
}

/* ================================================================== 6. honest zero */
{
  const r = await run({ terms: ['contactor'], scope: 'documents', groupBy: null });
  eq('no matches -> recordsTotal 0', r.recordsTotal, 0);
  eq('no matches -> recordsKind is "searched" (an honest zero, not a basis)', r.recordsKind, 'searched');
  check('no matches -> a real sentence, never blank', r.text.length > 10 && /contactor/i.test(r.text));
}

/* ================================================================== 7. tenant isolation */
{
  const rA = await run({ terms: ['capacitor'], scope: 'documents', groupBy: null });
  check("tenant A's count never includes tenant B's matching document", !rA.records.some((x) => /secret/i.test(x.sublabel ?? '')));
  const rB = await withTenant(ctxB, (db) => runContentCount(db, { terms: ['capacitor'], scope: 'documents', groupBy: null }));
  eq("tenant B sees its own single matching document", rB.recordsTotal, 1);
}

/* ================================================================== 8. the agent tool (count_documents_mentioning) */
{
  const toolbox = createToolbox({ withTenant, ctxArg: ctxA, today: '2026-09-24' });
  const r = await toolbox.execute('count_documents_mentioning', { terms: ['capacitors'], documentType: 'jobs' }); // plural, on purpose
  check('agent tool: ok, and a plural spelling still canonicalizes to the capacitor group', r.ok);
  const parsed = JSON.parse(r.content);
  eq('agent tool: jobs-scoped capacitor count matches the deterministic path (1)', parsed.recordsTotal, 1);
  check('agent tool: rowCount mirrors recordsTotal', r.rowCount === parsed.recordsTotal);

  const rZero = await toolbox.execute('count_documents_mentioning', { terms: ['blower motor'] });
  check('agent tool: an honest zero is still ok:true with rowCount 0', rZero.ok && rZero.rowCount === 0 && rZero.empty === true);

  const rBad = await toolbox.execute('count_documents_mentioning', { terms: [] });
  check('agent tool: no terms -> a clear error, not a crash', !rBad.ok && /terms/i.test(rBad.content));
}

/* ================================================================== 8b. new HVAC vocabulary, DB-backed (Round 15) */
{
  // The Salazar work-order (a job doc type) mentions "heat exchanger" - counted as a job mention.
  const r = await run({ terms: ['heat exchanger'], scope: 'jobs', groupBy: null });
  eq('jobs scope: "heat exchanger" finds the Salazar work-order', r.recordsTotal, 1);
  // Nothing in this corpus mentions a TXV/expansion valve at all - an honest zero, not an error.
  const rZero = await run({ terms: ['txv'], scope: 'documents', groupBy: null });
  eq('documents scope: "txv" - honest zero when nothing on file mentions it', rZero.recordsTotal, 0);
  check('documents scope: "txv" zero-answer names the term, never blank', /txv/i.test(rZero.text));
}

/* ================================================================== 8c. "filter change" standalone phrase (Round 15, breadth-content-028) */
{
  // Palmer's own document says "filter change" with NO "replac"/"repair"/etc. word anywhere on the page -
  // the verb-proximity pattern alone would miss it; the standalone-phrase addition must still count it.
  const r = await run({ terms: ['filter'], scope: 'documents', groupBy: null, replaceVerb: 'replac', replaceVerbWord: 'replaced' });
  check('replaceVerb "filter": a standalone "filter change" (no verb nearby at all) is still counted', r.records.some((x) => /palmer/i.test(x.sublabel ?? '') || /filter change/i.test(x.sublabel ?? '')), JSON.stringify(r.records));
  check('replaceVerb "filter": Karen\'s "replaced the dual run capacitor" (a different part) is NOT counted', !r.records.some((x) => /karen/i.test(x.sublabel ?? '')));

  // "oil change" is a different phrase entirely - must not be swept in by a loose match.
  const rNeg = await run({ terms: ['motor'], scope: 'documents', groupBy: null, replaceVerb: 'replac', replaceVerbWord: 'replaced' });
  eq('replaceVerb "motor": no standalone phrase configured for this term - behaves exactly as before', rNeg.recordsTotal, 0);
}

/* ================================================================== 9. job-summary (Round 15) */
{
  // End-to-end: parse the real question text, then run it through the real pre-router entry point
  // (runContentCount), exactly as api/ask.js's block 0.63 does.
  const parsed = parseContentCountQuestion('What was found or done on the Salazar job?');
  check('job-summary: parses as mode jobSummary', parsed?.mode === 'jobSummary' && parsed.customerName === 'Salazar', JSON.stringify(parsed));
  const r = await withTenant(ctxA, (db) => content.runContentCount(db, parsed));
  check('job-summary: answers (never null) for a single, unambiguous match', Boolean(r));
  check('job-summary: quotes the ACTUAL sentence from the source page, verbatim', r.text.includes('Found a cracked heat exchanger during inspection'), r.text);
  check('job-summary: a second real sentence from the same page is also surfaced, not invented', r.text.includes('Recommend replacement before next heating season'), r.text);
  check('job-summary: never includes the throwaway "Customer signature obtained" line (no finding word in it)', !r.text.includes('Customer signature obtained'));
  check('job-summary: cites the source document + page', r.records.some((x) => x.documentId && x.page === 1));
  check('job-summary: includes a customer record for Elena Salazar', r.records.some((x) => x.type === 'customer' && /Salazar/.test(x.label)));

  // Ambiguous name: "Rios" matches BOTH Marco Rios and Rios Boulevard Apartments - never silently merged
  // into one answer; each is reported separately, under its own name.
  const rAmbiguous = await withTenant(ctxA, (db) => content.runContentCount(db, { mode: 'jobSummary', customerName: 'Rios' }));
  check('job-summary: an ambiguous name names BOTH matching customers, never guesses one', /Marco Rios/.test(rAmbiguous.text) && /Rios Boulevard Apartments/.test(rAmbiguous.text), rAmbiguous.text);
  check('job-summary: both ambiguous customers get a customer record (never merged into one)', rAmbiguous.records.filter((x) => x.type === 'customer').length === 2, JSON.stringify(rAmbiguous.records));
  check('job-summary: Marco Rios\'s real finding is quoted, attributed to him, not to the other match', rAmbiguous.text.includes('Found a loose duct connection near the attic access'), rAmbiguous.text);
  check('job-summary: the OTHER matching customer (no docs) is named as having nothing on file, not silently dropped', /Nothing on file for Rios Boulevard Apartments/.test(rAmbiguous.text), rAmbiguous.text);

  // Customer on file, but no document contains a finding/work word - honest "nothing on file", never invented.
  const rNoFindings = await withTenant(ctxA, (db) => content.runContentCount(db, { mode: 'jobSummary', customerName: 'Holloway' }));
  check('job-summary: on file with no finding text -> honest zero, not a fabricated summary', rNoFindings.recordsKind === 'searched' && /no documents/i.test(rNoFindings.text), rNoFindings.text);

  // No customer at all on file by that name.
  const rNoCustomer = await withTenant(ctxA, (db) => content.runContentCount(db, { mode: 'jobSummary', customerName: 'Fictional Nobody' }));
  check('job-summary: no customer on file by that name -> honest "not on file", not a guess', rNoCustomer.recordsTotal === 0 && /not|no customer/i.test(rNoCustomer.text), rNoCustomer.text);

  // Tenant isolation: tenant B's own "Zed Competitor" is invisible to tenant A's job-summary lookup.
  const rCrossTenant = await withTenant(ctxA, (db) => content.runContentCount(db, { mode: 'jobSummary', customerName: 'Zed Competitor' }));
  check('job-summary: tenant isolation - another tenant\'s customer is invisible', rCrossTenant.recordsTotal === 0);
}

/* ================================================================== 10. address-resolved job summary
 * (Round 16, F4, D2 #5 / field-phrasing g099-g101): "what was found on the job at <address>",
 * "any notes on the install at <address>", "whats the work order say for <address>" - resolved via
 * the SAME fast-path address resolution the rest of the app uses, then answered extractively from that
 * one customer's own structured work_performed/notes extractions - never a page-text guess, never a
 * later document's note borrowed to answer about an earlier one. */
{
  const runQ = (q) => withTenant(ctxA, (db) => content.runContentCount(db, parseContentCountQuestion(q)));

  // "the job" (generic): every document with a work_performed/notes value, each attributed to its own
  // document - the install invoice AND the later service-ticket both show up, never merged into one quote.
  const rJob = await runQ('what was found on the job at 55 alpha rd');
  check('address job-summary: parses as an address-anchored jobSummary', parseContentCountQuestion('what was found on the job at 55 alpha rd')?.addressKind === 'job');
  check('address job-summary (generic): includes the install invoice\'s own work_performed', rJob.text.includes('Install 3 ton Goodman system'), rJob.text);
  check('address job-summary (generic): also includes the later service-ticket\'s own notes', rJob.text.includes('System operating normally after visit'), rJob.text);
  check('address job-summary (generic): cites both documents', rJob.records.filter((x) => x.documentId).length === 2, JSON.stringify(rJob.records));

  // "the install" specifically: the invoice has work_performed but NO notes field on IT - the answer must
  // say so plainly and must NEVER borrow the later service-ticket's "System operating normally" note.
  const rInstall = await runQ('any notes on the install at 55 alpha rd');
  check('address job-summary (install): states the install document has no notes field', /no notes field/i.test(rInstall.text), rInstall.text);
  check('address job-summary (install): never borrows the LATER service-ticket\'s note', !rInstall.text.includes('System operating normally'), rInstall.text);
  check('address job-summary (install): still gives the install\'s own work_performed extractively', rInstall.text.includes('Install 3 ton Goodman system'), rInstall.text);
  check('address job-summary (install): cites only the install document, not the later one', rInstall.records.filter((x) => x.documentId).length === 1, JSON.stringify(rInstall.records));

  // "the work order", no literal work-order document on file at all: falls back to whichever document
  // covers the address (the one service-ticket), rather than an honest-but-useless decline.
  const rWoFallback = await runQ('whats the work order say for 66 beta rd');
  check('address job-summary (work order, no literal work-order doc): falls back to the service-ticket on file', rWoFallback.text.includes('replaced run capacitor'), rWoFallback.text);

  // "the work order", a real work-order document DOES exist (plus a later, unrelated service-ticket):
  // the real work-order is used, not the later visit.
  const rWoReal = await runQ('whats the work order say for 77 gamma rd');
  check('address job-summary (work order, real work-order on file): quotes the work order itself', rWoReal.text.includes('dispatched for diagnosis'), rWoReal.text);
  check('address job-summary (work order, real work-order on file): never the later, unrelated service-ticket', !rWoReal.text.includes('Replaced igniter'), rWoReal.text);

  // Address ambiguity: two customers share the same house number + street name (different city) - asks
  // which, never guesses one.
  const rAmbig = await runQ('what was found on the job at 88 delta rd');
  check('address job-summary: an address matching 2+ customers asks which, never guesses', /which one/i.test(rAmbig.text), rAmbig.text);

  // No address on file at all.
  const rNoAddr = await runQ('what was found on the job at 999 nowhere ln');
  check('address job-summary: no address on file -> honest decline, not a guess', rNoAddr.recordsTotal === 0 && /no job or customer/i.test(rNoAddr.text), rNoAddr.text);
}

console.log('');
if (failures) { console.log(`${failures} check(s) FAILED, ${passes} passed.`); process.exit(1); }
console.log(`${passes} checks passed.`);
