---
id: troubleshooting
title: Quick fixes for common problems
audience: app
surface: both
keywords: troubleshooting, problem, error, not working, help, fix, issue, bug, broken, cant, cannot
updated: 2026-09-29
---
Most problems have a short fix. If yours isn't here, I can pass it to the team.

### I can't sign in
~ cant sign in, cannot sign in, cant login, cannot log in, login not working, sign in not working, wont let me in, login failed, session expired, invalid session, sign in error, login error
Check that you're signing in with the email your invite went to, and use the password option on the sign-in page. If a phone home-screen app asks you to sign in again, sign in once inside the app, since it keeps its own sign-in. Still stuck: email support@deepwelltechnology.com. Never send a password.
!handoff:sign-in-help

### My invite email didn't arrive
~ my tech never got the invite email, tech never got the invite, never got the invite, invite never came, never received the invite, invite not arriving, invite email, did not get invite, invitation not received, didnt receive invite, tech didnt get invite, invite expired, resend invite, invite spam, invite link, invitation email, my team member never got the invite email, team member never got the invite, team member didnt get invite
Ask the person to check spam or junk. Confirm the address is right in **Team**, and re-send the invite if needed. Invites count toward your plan's login limit, and if you're at the limit the invite is blocked with a message that says so.

### An upload failed
~ upload failed, upload error, cant upload, cannot upload, upload not working, upload wont work, file wont upload, upload stuck, failed to upload, upload fails, error uploading, upload problem, file too large, monthly page limit reached, subscription required, daily ai budget, couldnt reach deepwell, waiting for the servers rate limit, upload error message, pdfs and photos have to be under, already on file
!covers:A-UPLOAD-ERR
Check the file type (PDF, JPG, PNG, GIF, WEBP, TXT, MD, CSV, TSV, JSON, DOCX or XLSX; a ZIP only in Inbox bulk import) and size (PDFs and photos under 24 MB, text, CSV, Word and Excel under 20 MB). Old .doc and .xls files, macro files and password-protected files aren't read: re-save them as .docx or .xlsx. "Choose a plan to get started", "Subscription required" or "Monthly page limit reached" mean uploads are paused for billing reasons (**See plans**). "Daily AI budget reached" resumes tomorrow. "Couldn't reach DeepWell" means check your connection and retry. "Already on file" means that exact file is already in. Otherwise email support@deepwelltechnology.com with the file name and time.

### Donovan gave a wrong or missing answer
~ wrong answer, donovan wrong, incorrect answer, answer is wrong, bad answer, not right, missing answer, thumbs down, report a wrong answer, donovan mistake, no answer
Open the cited source and check it. The document may still be processing, or a field may be flagged or misread. Correct it in Records, then ask again. If it still looks wrong, tell us at support@deepwelltechnology.com with the question. Don't paste customer details you don't need to.
!handoff:wrong-answer

### I can't see the Dashboard or Team screen
~ cant see team, no team screen, cant see billing, no dashboard, missing screen, cant find team, permission denied, requires admin, admin role, not authorized, forbidden, access denied, why cant i
!covers:A-TEAM-MEMBER
Some screens and actions are for admins. Team is hidden from members, and if a member reaches it they see a read-only list of members. Billing, invites, exports and deletions need an admin. A member sees those buttons disabled with "Ask an admin" beside them (Export CSV, customer merge, Billing actions, API keys), and Empty documents and Delete document are hidden. Ask your company's admin. On a phone the app only has Ask, Scan and Docs, so use the desktop app for the rest.

### I get "API access is included on the Fleet plan"
~ api access error, api access is included on the fleet plan, cant create api key, api key error, create api key, api keys not working, 403 api, api forbidden
!covers:A-APIKEYS-GATE
API keys are a Fleet-only feature, so other plans can't create them. Upgrade to Fleet from Billing, or email hello@deepwelltechnology.com.

### The page looks broken or won't load
~ page wont load, site not loading, blank page, white screen, loading forever, website broken, page broken, browser problem, not loading, error page, 404, cache, refresh, spinning forever
Refresh the page and try a different browser or a private window. Then check your connection. If DeepWell still won't load, email support@deepwelltechnology.com with your browser, device and what you see. I can send that to the team from here.
!handoff:site-problem
