import { useState } from 'react';
import { ChevronDown, ChevronUp, FileText, Image as ImageIcon, Table2, FileType2 } from 'lucide-react';
import type { Doc, SourceRef } from '../core/types';
import { useGraph } from '../core/entityGraph';
import { StagePill } from './StagePill';

const FILE_ICON: Record<Doc['fileType'], typeof FileText> = {
  pdf: FileText,
  image: ImageIcon,
  spreadsheet: Table2,
  text: FileType2,
};

/** How many documents show before the list folds behind "Show all". */
const DEFAULT_VISIBLE = 3;

export function locationLabel(loc: SourceRef['location']): string {
  const parts: string[] = [];
  if (loc.page) parts.push(`p. ${loc.page}`);
  if (loc.field) parts.push(loc.field);
  if (loc.region) parts.push(loc.region);
  return parts.join(' · ');
}

interface SourceListProps {
  sources: SourceRef[];
  onOpen: (ref: SourceRef) => void;
  /** Heading override, e.g. "Closest documents" */
  title?: string;
  emptyText?: string;
}

/**
 * Every document an answer drew from, with where on the page the fact came
 * from. One tap opens the original. The first three show by default; the
 * rest fold behind "Show all" so a long answer stays scannable on a phone.
 */
export function SourceList({ sources, onOpen, title = 'Sources', emptyText = 'No documents cited.' }: SourceListProps) {
  const docs = useGraph((s) => s.docs);
  const schema = useGraph((s) => s.schema);
  const [expanded, setExpanded] = useState(false);

  // Group refs by document, keep citation order
  const grouped = new Map<string, SourceRef[]>();
  for (const ref of sources) {
    const list = grouped.get(ref.documentId) ?? [];
    list.push(ref);
    grouped.set(ref.documentId, list);
  }
  const entries = Array.from(grouped.entries());
  const foldable = entries.length > DEFAULT_VISIBLE;
  const shown = foldable && !expanded ? entries.slice(0, DEFAULT_VISIBLE) : entries;
  const hiddenCount = entries.length - shown.length;

  return (
    <section aria-labelledby="sources-heading">
      <h3 id="sources-heading" className="dw-label mb-2">
        {title} <span className="text-ink-3 normal-case font-normal">· {grouped.size}</span>
      </h3>
      {grouped.size === 0 ? (
        <p className="text-ink-3">{emptyText}</p>
      ) : (
        <div className="border border-line rounded-lg bg-surface">
          <ol id="sources-list" className="divide-y divide-line">
            {shown.map(([docId, refs], i) => {
              const doc = docs[docId];
              if (!doc) return null;
              const Icon = FILE_ICON[doc.fileType];
              const typeLabel = schema.documentTypes.find((t) => t.id === doc.typeId)?.label ?? 'Document';
              const first = refs[0];
              const locations = refs
                .map((r) => locationLabel(r.location))
                .filter(Boolean)
                .filter((v, idx, arr) => arr.indexOf(v) === idx)
                .join(' · ');
              return (
                <li key={docId}>
                  <button
                    type="button"
                    onClick={() => first && onOpen(first)}
                    className="w-full text-left flex items-start gap-3 px-3 py-3 min-h-touch hover:bg-surface-2 transition-colors duration-quick rounded-lg"
                  >
                    <span className="mt-0.5 w-7 h-7 rounded-md bg-surface-2 grid place-items-center shrink-0 text-ink-2">
                      <Icon className="w-4 h-4" aria-hidden="true" />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="flex flex-wrap items-center gap-x-2 gap-y-1">
                        <span className="font-medium text-ink break-words">
                          <span className="text-ink-3 font-mono text-data mr-1.5">[{i + 1}]</span>
                          {typeLabel}
                        </span>
                        <StagePill stage={doc.stage} />
                      </span>
                      <span className="block text-body text-ink-3 break-all font-mono">{doc.filename}</span>
                      {locations && <span className="block text-body text-ink-2 mt-1 break-words">{locations}</span>}
                    </span>
                  </button>
                </li>
              );
            })}
          </ol>
          {foldable && (
            <button
              type="button"
              onClick={() => setExpanded((v) => !v)}
              aria-expanded={expanded}
              aria-controls="sources-list"
              className="w-full min-h-touch px-3 flex items-center justify-center gap-2 border-t border-line text-forest-700 dark:text-brass-300 font-medium hover:bg-surface-2 transition-colors duration-quick rounded-b-lg"
            >
              {expanded ? (
                <>
                  Show fewer sources <ChevronUp className="w-4 h-4" aria-hidden="true" />
                </>
              ) : (
                <>
                  Show all {entries.length} sources <ChevronDown className="w-4 h-4" aria-hidden="true" />
                </>
              )}
              {!expanded && <span className="sr-only">({hiddenCount} more)</span>}
            </button>
          )}
        </div>
      )}
    </section>
  );
}
